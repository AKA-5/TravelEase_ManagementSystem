﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;
using System.Collections.Generic;
using OfficeOpenXml;
using System.Linq;
using System.Diagnostics;

namespace Travel_Ease_App.Forms
{
    public partial class frmAdmin : Form
    {
        private DataGridView _dgvBookings;
        private DataGridView _dgvStats;
        private TabControl _tabControl;
        private DataGridView _dgvReviews;
        private DataGridView _dgvVouchers;

        public frmAdmin()
        {
            InitializeComponent();
            SetupAdminDashboard();
        }

        private void SetupAdminDashboard()
        {
            this.Text = "Admin Dashboard - TravelEase";
            this.WindowState = FormWindowState.Maximized;

            // Create tab control
            _tabControl = new TabControl { Dock = DockStyle.Fill };

            // Tab 1: Dashboard
            var tabDashboard = new TabPage("Dashboard");
            SetupDashboardTab(tabDashboard);

            // Tab 2: User Management
            var tabUsers = new TabPage("User Management");
            SetupUserManagementTab(tabUsers);

            // Tab 3: Review Moderation
            var tabReviews = new TabPage("Review Moderation");
            SetupReviewModerationTab(tabReviews);

            var tabVouchers = new TabPage("Vouchers");
            SetupVoucherManagementTab(tabVouchers);

            _tabControl.TabPages.AddRange(new TabPage[] { tabDashboard, tabUsers, tabReviews, tabVouchers });

            this.Controls.Add(_tabControl);

            RefreshDashboard();
        }

        private void SetupDashboardTab(TabPage tab)
        {
            // Clear existing controls
            tab.Controls.Clear();

            // Main container panel
            var mainPanel = new Panel { Dock = DockStyle.Fill };

            // 1. Top Button Panel for View Reports (New Section)
            var topButtonPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 40,
                BackColor = SystemColors.Control,
                Padding = new Padding(5)
            };

            var btnReports = new Button
            {
                Text = "View Reports",
                Location = new Point(5, 5),
                Size = new Size(100, 30),
                Font = new Font("Segoe UI", 9),
                BackColor = SystemColors.ButtonFace,
                FlatStyle = FlatStyle.Standard
            };
            btnReports.Click += (s, e) =>
            {
                var reportsForm = new frmReports();
                reportsForm.ShowDialog();
            };

            var btnExport = new Button
            {
                Text = "Export to Excel",
                Location = new Point(115, 5), // Positioned right after btnReports with a small gap
                Size = new Size(100, 30),     // Matching size with btnReports
                Font = new Font("Segoe UI", 9),
                BackColor = SystemColors.ButtonFace,
                FlatStyle = FlatStyle.Standard
            };
            btnExport.Click += (s, e) => ExportToExcel();

            topButtonPanel.Controls.Add(btnReports);
            topButtonPanel.Controls.Add(btnExport);

            // 2. Stats Panel (Below Top Button Panel)
            var statsPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 120,
                Padding = new Padding(5),
                BackColor = SystemColors.Control
            };

            _dgvStats = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                BackgroundColor = SystemColors.Window
            };

            // 2. Bookings Panel (Middle Section)
            var bookingsPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(5, 0, 5, 5)
            };

            _dgvBookings = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                BackgroundColor = SystemColors.Window,
                ScrollBars = ScrollBars.Vertical
            };

            // Add controls to containers
            statsPanel.Controls.Add(_dgvStats);
            bookingsPanel.Controls.Add(_dgvBookings);

            // Add panels to main panel in correct order
            mainPanel.Controls.Add(bookingsPanel);
            mainPanel.Controls.Add(statsPanel);
            mainPanel.Controls.Add(topButtonPanel);

            // Add main panel to tab
            tab.Controls.Add(mainPanel);

            // Safe event handler for DataBindingComplete
            _dgvBookings.DataBindingComplete += BookingsGrid_DataBindingComplete;
        }

        private void BookingsGrid_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            // Ensure the grid has rows and is properly initialized
            if (_dgvBookings.Rows.Count > 0 && _dgvBookings.DisplayedRowCount(false) > 0)
            {
                try
                {
                    // Suspend layout to prevent flickering
                    _dgvBookings.SuspendLayout();

                    // Select and scroll to first row safely
                    _dgvBookings.ClearSelection();
                    _dgvBookings.Rows[0].Selected = true;
                    _dgvBookings.FirstDisplayedScrollingRowIndex = 0;

                    // Ensure columns are properly sized
                    _dgvBookings.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                }
                catch (Exception ex)
                {
                    // Log error if needed
                    Debug.WriteLine($"Error in DataBindingComplete: {ex.Message}");
                }
                finally
                {
                    _dgvBookings.ResumeLayout();
                }
            }
        }

        private void ConfigureBookingsGrid()
        {
            _dgvBookings.AutoGenerateColumns = true;
            _dgvBookings.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            _dgvBookings.EnableHeadersVisualStyles = false;
            _dgvBookings.DefaultCellStyle.WrapMode = DataGridViewTriState.False;
            _dgvBookings.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

            // Scroll to top after data loads
            _dgvBookings.DataBindingComplete += (s, e) =>
            {
                if (_dgvBookings.Rows.Count > 0)
                {
                    _dgvBookings.FirstDisplayedScrollingRowIndex = 0;
                }
            };
        }

        private void SetupUserManagementTab(TabPage tab)
        {
            var dgvUsers = new DataGridView { Dock = DockStyle.Fill };

            // User type filter
            var cmbUserType = new ComboBox
            {
                Dock = DockStyle.Top,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Items = { "All", "Travelers", "Operators", "Service Providers", "Admins" }
            };
            cmbUserType.SelectedIndexChanged += (s, e) => FilterUsers(dgvUsers, cmbUserType.Text);

            // Action buttons
            var panelButtons = new Panel { Dock = DockStyle.Bottom, Height = 40 };
            var btnApprove = new Button { Text = "Approve", Width = 100, Top = 5, Left = 5 };
            var btnReject = new Button { Text = "Reject", Width = 100, Top = 5, Left = 110 };

            btnApprove.Click += (s, e) => ProcessUserAction(dgvUsers, "Approve");
            btnReject.Click += (s, e) => ProcessUserAction(dgvUsers, "Reject");

            panelButtons.Controls.AddRange(new Control[] { btnApprove, btnReject });
            tab.Controls.AddRange(new Control[] { dgvUsers, cmbUserType, panelButtons });

            FilterUsers(dgvUsers, "All");
        }

        private void SetupReviewModerationTab(TabPage tab)
        {
            // Clear existing controls
            tab.Controls.Clear();

            // Main container panel
            var mainPanel = new Panel { Dock = DockStyle.Fill };

            /* ====================== */
            /*  FILTER PANEL (TOP)   */
            /* ====================== */
            var filterPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = SystemColors.Control
            };

            // Filter dropdown
            var cmbFilter = new ComboBox
            {
                Name = "cmbReviewFilter",
                Dock = DockStyle.Left,
                Width = 200,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 9)
            };
            cmbFilter.Items.AddRange(new[] { "All Reviews", "Flagged Reviews", "Low Ratings (1-2 stars)" });
            cmbFilter.SelectedIndex = 0;
            cmbFilter.SelectedIndexChanged += (s, e) => LoadReviews(cmbFilter.Text);

            // Refresh button
            var btnRefresh = new Button
            {
                Text = "Refresh",
                Dock = DockStyle.Left,
                Width = 80,
                Margin = new Padding(5, 0, 0, 0),
                Font = new Font("Segoe UI", 9)
            };
            btnRefresh.Click += (s, e) => LoadReviews(cmbFilter.Text);

            filterPanel.Controls.Add(cmbFilter);
            filterPanel.Controls.Add(btnRefresh);

            /* ====================== */
            /*  REVIEWS GRID (MIDDLE) */
            /* ====================== */
            _dgvReviews = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                BackgroundColor = SystemColors.Window,
                BorderStyle = BorderStyle.FixedSingle,

                // Selection configuration
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    SelectionBackColor = Color.LightSteelBlue,
                    SelectionForeColor = SystemColors.ControlText
                }
            };

            /* ====================== */
            /*  ACTION PANEL (BOTTOM) */
            /* ====================== */
            var actionPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                BackColor = SystemColors.Control
            };

            // Selection info label
            var lblSelection = new Label
            {
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                Text = "  No review selected",
                ForeColor = SystemColors.HotTrack
            };

            // Flag button
            var btnFlag = new Button
            {
                Text = "🚩 Flag",
                Dock = DockStyle.Right,
                Width = 90,
                Margin = new Padding(0, 0, 5, 0),
                Font = new Font("Segoe UI", 9),
                BackColor = Color.LightCoral
            };
            btnFlag.Click += (s, e) => FlagSelectedReview(true);

            // Unflag button
            var btnUnflag = new Button
            {
                Text = "✅ Unflag",
                Dock = DockStyle.Right,
                Width = 90,
                Margin = new Padding(0, 0, 5, 0),
                Font = new Font("Segoe UI", 9),
                BackColor = Color.LightGreen
            };
            btnUnflag.Click += (s, e) => FlagSelectedReview(false);

            // Delete button
            var btnDelete = new Button
            {
                Text = "🗑️ Delete",
                Dock = DockStyle.Left,
                Width = 90,
                Margin = new Padding(5, 0, 0, 0),
                Font = new Font("Segoe UI", 9),
                BackColor = Color.LightSalmon
            };
            btnDelete.Click += (s, e) => DeleteSelectedReview();

            // Selection changed handler
            _dgvReviews.SelectionChanged += (s, e) =>
            {
                if (_dgvReviews.SelectedRows.Count > 0)
                {
                    var row = _dgvReviews.SelectedRows[0];
                    lblSelection.Text = $"  Selected: {row.Cells["TripTitle"].Value} (Rating: {row.Cells["Rating"].Value})";
                }
                else
                {
                    lblSelection.Text = "  No review selected";
                }
            };

            // Add controls to action panel
            actionPanel.Controls.Add(btnDelete);
            actionPanel.Controls.Add(lblSelection);
            actionPanel.Controls.Add(btnUnflag);
            actionPanel.Controls.Add(btnFlag);

            /* ====================== */
            /*  ASSEMBLE ALL CONTROLS */
            /* ====================== */
            mainPanel.Controls.Add(_dgvReviews);
            mainPanel.Controls.Add(actionPanel);
            mainPanel.Controls.Add(filterPanel);

            tab.Controls.Add(mainPanel);

            // Load initial data
            LoadReviews("All Reviews");
        }

        private void SetupVoucherManagementTab(TabPage tab)
        {
            tab.Controls.Clear();
            var mainPanel = new Panel { Dock = DockStyle.Fill };

            var filterPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = SystemColors.Control
            };

            var cmbFilter = new ComboBox
            {
                Dock = DockStyle.Left,
                Width = 200,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 9)
            };
            cmbFilter.Items.AddRange(new[] { "All Vouchers", "Active Vouchers", "Used Vouchers", "Expired Vouchers" });
            cmbFilter.SelectedIndex = 0;
            cmbFilter.SelectedIndexChanged += (s, e) => LoadVouchers(cmbFilter.Text);

            var btnRefresh = new Button
            {
                Text = "Refresh",
                Dock = DockStyle.Left,
                Width = 80,
                Margin = new Padding(5, 0, 0, 0),
                Font = new Font("Segoe UI", 9)
            };
            btnRefresh.Click += (s, e) => LoadVouchers(cmbFilter.Text);

            filterPanel.Controls.Add(cmbFilter);
            filterPanel.Controls.Add(btnRefresh);

            _dgvVouchers = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                BackgroundColor = SystemColors.Window,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect
            };

            var actionPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                BackColor = SystemColors.Control
            };

            var btnDelete = new Button
            {
                Text = "Delete Voucher",
                Dock = DockStyle.Left,
                Width = 120,
                Margin = new Padding(5, 0, 0, 0),
                Font = new Font("Segoe UI", 9),
                BackColor = Color.LightSalmon
            };
            btnDelete.Click += (s, e) => DeleteVoucher();

            actionPanel.Controls.Add(btnDelete);

            mainPanel.Controls.Add(_dgvVouchers);
            mainPanel.Controls.Add(actionPanel);
            mainPanel.Controls.Add(filterPanel);

            tab.Controls.Add(mainPanel);
            LoadVouchers("All Vouchers");
        }

        private void LoadVouchers(string filterType)
        {
            try
            {
                _dgvVouchers.DataSource = null;
                _dgvVouchers.Columns.Clear();

                string query = @"
                    SELECT v.VoucherID, v.TravelerID, v.VoucherCode, v.DiscountAmount, 
                           v.IssueDate, v.ExpiryDate, v.VStatus
                    FROM Voucher v";
                var parameters = new Dictionary<string, object>();

                if (filterType == "Active Vouchers")
                    query += " WHERE v.VStatus = 'Active'";
                else if (filterType == "Used Vouchers")
                    query += " WHERE v.VStatus = 'Used'";
                else if (filterType == "Expired Vouchers")
                    query += " WHERE v.VStatus = 'Expired'";

                query += " ORDER BY v.IssueDate DESC";
                DataTable vouchersData = DatabaseHelper.ExecuteQuery(query, parameters);

                _dgvVouchers.AutoGenerateColumns = false;
                _dgvVouchers.Columns.AddRange(
                    new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "VoucherID",
                        HeaderText = "Voucher ID",
                        Width = 80
                    },
                    new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "TravelerID",
                        HeaderText = "Traveler ID",
                        Width = 80
                    },
                    new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "VoucherCode",
                        HeaderText = "Voucher Code",
                        Width = 120
                    },
                    new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "DiscountAmount",
                        HeaderText = "Discount",
                        Width = 80,
                        DefaultCellStyle = new DataGridViewCellStyle { Format = "C2" }
                    },
                    new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "IssueDate",
                        HeaderText = "Issue Date",
                        Width = 100,
                        DefaultCellStyle = new DataGridViewCellStyle { Format = "d" }
                    },
                    new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "ExpiryDate",
                        HeaderText = "Expiry Date",
                        Width = 100,
                        DefaultCellStyle = new DataGridViewCellStyle { Format = "d" }
                    },
                    new DataGridViewTextBoxColumn
                    {
                        DataPropertyName = "VStatus",
                        HeaderText = "Status",
                        Width = 80
                    });

                _dgvVouchers.DataSource = vouchersData;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading vouchers: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DeleteVoucher()
        {
            if (_dgvVouchers.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a voucher to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string voucherId = _dgvVouchers.SelectedRows[0].Cells["VoucherID"].Value.ToString();
            string voucherCode = _dgvVouchers.SelectedRows[0].Cells["VoucherCode"].Value.ToString();

            try
            {
                string checkQuery = "SELECT COUNT(*) FROM Booking WHERE VoucherID = @VoucherID";
                var checkParams = new Dictionary<string, object> { { "@VoucherID", voucherId } };
                int bookingCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(checkQuery, checkParams));

                if (bookingCount > 0)
                {
                    MessageBox.Show("Cannot delete voucher: It is used in one or more bookings.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                if (MessageBox.Show($"Are you sure you want to delete voucher '{voucherCode}'?", "Confirm Delete", MessageBoxButtons.YesNo) != DialogResult.Yes)
                    return;

                string deleteQuery = "DELETE FROM Voucher WHERE VoucherID = @VoucherID";
                var deleteParams = new Dictionary<string, object> { { "@VoucherID", voucherId } };
                DatabaseHelper.ExecuteNonQuery(deleteQuery, deleteParams);

                MessageBox.Show("Voucher deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LoadVouchers(GetCurrentVoucherFilter());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting voucher: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string GetCurrentVoucherFilter()
        {
            foreach (Control control in _dgvVouchers.Parent.Controls)
            {
                if (control is Panel panel)
                {
                    foreach (Control panelControl in panel.Controls)
                    {
                        if (panelControl is ComboBox comboBox)
                            return comboBox.Text;
                    }
                }
            }
            return "All Vouchers";
        }

        private void LoadReviews(string filterType)
        {
            try
            {
                // Clear previous data
                _dgvReviews.DataSource = null;
                _dgvReviews.Columns.Clear();

                string filterParam;
                if (filterType == "Flagged Reviews")
                {
                    filterParam = "Flagged";
                }
                else if (filterType == "Low Ratings (1-2 stars)")
                {
                    filterParam = "LowRatings";
                }
                else
                {
                    filterParam = "All";
                }

                var parameters = new Dictionary<string, object>
                {
                    { "@FilterType", filterParam }
                };

                // Get data from database
                DataTable reviewsData = DatabaseHelper.ExecuteQuery(
                    "EXEC sp_GetReviewsForModeration @FilterType",
                    parameters);

                // Configure grid
                _dgvReviews.AutoGenerateColumns = false;

                // Add columns
                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "TravelerName",
                    HeaderText = "Traveler",
                    Name = "TravelerName",
                    Width = 120
                });

                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "TripTitle",
                    HeaderText = "Trip",
                    Name = "TripTitle",
                    Width = 150
                });

                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "ProviderName",
                    HeaderText = "Service Provider",
                    Name = "ProviderName",
                    Width = 150
                });

                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "Rating",
                    HeaderText = "Rating",
                    Name = "Rating",
                    Width = 60
                });

                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "Comment",
                    HeaderText = "Comment",
                    Name = "Comment",
                    Width = 200,
                    DefaultCellStyle = new DataGridViewCellStyle { WrapMode = DataGridViewTriState.True }
                });

                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "ReviewDate",
                    HeaderText = "Date",
                    Name = "ReviewDate",
                    Width = 120
                });

                // Make IsFlagged column visible
                _dgvReviews.Columns.Add(new DataGridViewCheckBoxColumn()
                {
                    DataPropertyName = "IsFlagged",
                    HeaderText = "Flagged",
                    Name = "IsFlagged",
                    Width = 60,
                    ReadOnly = true
                });

                // Hidden column for ReviewID
                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "ReviewID",
                    HeaderText = "ReviewID",
                    Name = "ReviewID",
                    Visible = false
                });

                // Bind data
                _dgvReviews.DataSource = reviewsData;

                // Highlight flagged reviews
                foreach (DataGridViewRow row in _dgvReviews.Rows)
                {
                    if (row.Cells["IsFlagged"].Value != DBNull.Value &&
                        Convert.ToBoolean(row.Cells["IsFlagged"].Value))
                    {
                        row.DefaultCellStyle.BackColor = Color.LightPink;
                    }
                    else
                    {
                        row.DefaultCellStyle.BackColor = _dgvReviews.DefaultCellStyle.BackColor;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading reviews: {ex.Message}");
            }
        }

        private void FlagSelectedReview(bool isFlagged)
        {
            if (_dgvReviews.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a review first by clicking on a row");
                return;
            }

            var reviewId = _dgvReviews.SelectedRows[0].Cells["ReviewID"].Value.ToString();
            var reviewTitle = _dgvReviews.SelectedRows[0].Cells["TripTitle"].Value.ToString();

            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@ReviewID", reviewId },
                    { "@IsFlagged", isFlagged }
                };

                DatabaseHelper.ExecuteNonQuery(
                    "EXEC sp_FlagReview @ReviewID, @IsFlagged",
                    parameters);

                MessageBox.Show($"Review '{reviewTitle}' has been {(isFlagged ? "flagged" : "unflagged")}");

                // Update the UI immediately
                _dgvReviews.SelectedRows[0].Cells["IsFlagged"].Value = isFlagged;
                _dgvReviews.SelectedRows[0].DefaultCellStyle.BackColor = isFlagged ? Color.LightPink : _dgvReviews.DefaultCellStyle.BackColor;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating review: {ex.Message}");
            }
        }

        private void DeleteSelectedReview()
        {
            if (_dgvReviews.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a review first by clicking on a row");
                return;
            }

            var reviewId = _dgvReviews.SelectedRows[0].Cells["ReviewID"].Value.ToString();
            var reviewTitle = _dgvReviews.SelectedRows[0].Cells["TripTitle"].Value.ToString();

            if (MessageBox.Show($"Are you sure you want to delete the review for '{reviewTitle}'?",
                "Confirm Delete", MessageBoxButtons.YesNo) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                var parameters = new Dictionary<string, object>
                {
                    { "@ReviewID", reviewId }
                };

                DatabaseHelper.ExecuteNonQuery(
                    "EXEC sp_DeleteReview @ReviewID",
                    parameters);

                MessageBox.Show("Review deleted successfully");
                LoadReviews(GetCurrentFilter());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting review: {ex.Message}");
            }
        }

        private string GetCurrentFilter()
        {
            foreach (Control control in _dgvReviews.Parent.Controls)
            {
                if (control is Panel panel)
                {
                    foreach (Control panelControl in panel.Controls)
                    {
                        if (panelControl is ComboBox comboBox && comboBox.Name == "cmbReviewFilter")
                        {
                            return comboBox.Text;
                        }
                    }
                }
            }
            return "All Reviews";
        }

        private void RefreshDashboard()
        {
            try
            {
                // Load stats
                _dgvStats.DataSource = DatabaseHelper.ExecuteQuery(
                    @"SELECT 'Total Travelers' as Category, COUNT(*) as Count FROM Traveler WHERE AccountStatus = 'Active'
                      UNION ALL
                      SELECT 'Total Operators', COUNT(*) FROM TourOperator WHERE AccountStatus = 'Active'
                      UNION ALL
                      SELECT 'Active Trips', COUNT(*) FROM Trip WHERE TStatus = 'Open'
                      UNION ALL
                      SELECT 'Pending Approvals', COUNT(*) FROM (
                          SELECT TravelerID FROM Traveler WHERE AccountStatus = 'Pending'
                          UNION ALL SELECT OperatorID FROM TourOperator WHERE AccountStatus = 'Pending'
                          UNION ALL SELECT ProviderID FROM ServiceProvider WHERE AccountStatus = 'Pending'
                      ) as PendingUsers
                      UNION ALL
                      SELECT 'Active Vouchers', COUNT(*) FROM Voucher WHERE VStatus = 'Active'");

                // Load bookings
                var bookingsData = DatabaseHelper.ExecuteQuery(
                    @"SELECT 
                        b.TravelerID, b.TripID, 
                        FORMAT(b.BookingDate, 'dd/MM/yyyy') as BookingDate,
                        b.BStatus as Status,
                        b.AbandonmentReason,
                        b.PaymentID,
                        b.VoucherID,
                        v.VoucherCode,
                        v.DiscountAmount
                      FROM Booking b
                      LEFT JOIN Voucher v ON b.VoucherID = v.VoucherID
                      ORDER BY b.BookingDate DESC");

                // Bind data safely
                _dgvBookings.DataSource = null;
                _dgvBookings.DataSource = bookingsData;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading dashboard data: {ex.Message}");
            }
        }

        private void FilterUsers(DataGridView dgv, string userType)
        {
            string query;

            if (userType == "Travelers")
            {
                query = "SELECT TravelerID as UserID, Email, 'Traveler' as Role, AccountStatus FROM Traveler";
            }
            else if (userType == "Operators")
            {
                query = "SELECT OperatorID as UserID, Email, 'Operator' as Role, AccountStatus FROM TourOperator";
            }
            else if (userType == "Service Providers")
            {
                query = "SELECT ProviderID as UserID, Email, 'Service Provider' as Role, AccountStatus FROM ServiceProvider";
            }
            else if (userType == "Admins")
            {
                query = "SELECT AdminID as UserID, Email, 'Admin' as Role, AccountStatus FROM Admin";
            }
            else
            {
                query = @"SELECT TravelerID as UserID, Email, 'Traveler' as Role, AccountStatus FROM Traveler
                          UNION ALL SELECT OperatorID, Email, 'Operator', AccountStatus FROM TourOperator
                          UNION ALL SELECT ProviderID, Email, 'Service Provider', AccountStatus FROM ServiceProvider
                          UNION ALL SELECT AdminID, Email, 'Admin', AccountStatus FROM Admin";
            }

            dgv.DataSource = DatabaseHelper.ExecuteQuery(query);
        }

        private void ProcessUserAction(DataGridView dgv, string action)
        {
            if (dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a user first");
                return;
            }

            DataGridViewRow selectedRow = dgv.SelectedRows[0];
            var userId = selectedRow.Cells["UserID"].Value?.ToString();
            var role = selectedRow.Cells["Role"].Value?.ToString();

            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(role))
            {
                MessageBox.Show("Invalid user selection");
                return;
            }

            string statusValue = action == "Approve" ? "Active" : "Inactive";
            string tableName;
            string idColumn;

            if (role == "Traveler")
            {
                tableName = "Traveler";
                idColumn = "TravelerID";
            }
            else if (role == "Operator")
            {
                tableName = "TourOperator";
                idColumn = "OperatorID";
            }
            else if (role == "Service Provider")
            {
                tableName = "ServiceProvider";
                idColumn = "ProviderID";
            }
            else
            {
                tableName = "Admin";
                idColumn = "AdminID";
            }

            try
            {
                string query = $"UPDATE {tableName} SET AccountStatus = @Status WHERE {idColumn} = @UserId";
                var parameters = new Dictionary<string, object>
                {
                    { "@Status", statusValue },
                    { "@UserId", userId }
                };

                int rowsAffected = DatabaseHelper.ExecuteNonQuery(query, parameters);

                if (rowsAffected > 0)
                {
                    MessageBox.Show($"User {userId} status updated to {statusValue}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    if (dgv.Parent is TabPage tabPage && tabPage.Parent is TabControl tabControl)
                    {
                        if (tabControl.SelectedTab == tabPage)
                        {
                            var cmbUserType = tabPage.Controls.OfType<ComboBox>().FirstOrDefault();
                            if (cmbUserType != null)
                            {
                                FilterUsers(dgv, cmbUserType.Text);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No changes were made. User not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating user status: {ex.Message}");
            }
        }

        private void ExportToExcel()
        {
            var saveFile = new SaveFileDialog { Filter = "Excel|*.xlsx" };
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;
                    ExcelExporter.Export((DataTable)_dgvBookings.DataSource, saveFile.FileName);
                    MessageBox.Show("Exported successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Export failed: {ex.Message}");
                }
            }
        }

        private void frmAdmin_Load(object sender, EventArgs e)
        {
        }
    }
}