﻿using OfficeOpenXml;
using System.Data;
using System.IO;

namespace Travel_Ease_App.Data
{
    public static class ExcelExporter
    {
        public static void Export(DataTable data, string filePath)
        {
            // Add this license context setting
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add("Export");
                worksheet.Cells["A1"].LoadFromDataTable(data, true);
                package.SaveAs(new FileInfo(filePath));
            }
        }
    }
}