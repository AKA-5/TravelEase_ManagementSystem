﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.IO;

namespace Travel_Ease_App.Forms
{
    public partial class frmSplash : Form
    {
        public frmSplash()
        {
            InitializeComponent();
            SetupSplashScreen();
        }

        private void SetupSplashScreen()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Size = new Size(800, 500);
            this.BackColor = Color.FromArgb(44, 62, 80);

            // Background image
            var pbBackground = new PictureBox
            {
                Dock = DockStyle.Fill,
                SizeMode = PictureBoxSizeMode.StretchImage
            };
            try
            {
                string imagePath = "C:\\Users\\Fatik\\source\\repos\\Travel Ease App\\Data\\travel_background.png";
                if (File.Exists(imagePath))
                {
                    pbBackground.Image = Image.FromFile(imagePath);
                    pbBackground.Invalidate(); // Force redraw
                }
                else
                {
                    MessageBox.Show($"Background image not found at: {imagePath}.");
                    pbBackground.BackColor = Color.Black;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading background image: {ex.Message}");
                pbBackground.BackColor = Color.Black;
            }

            // Main container
            var mainPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.Transparent
            };

            // Logo/Title
            var lblTitle = new Label
            {
                Text = "TravelEase",
                Font = new Font("Segoe UI", 36, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 150,
                Padding = new Padding(0, 50, 0, 0)
            };

            // Tagline
            var lblTagline = new Label
            {
                Text = "Your Journey Begins Here",
                Font = new Font("Segoe UI", 14),
                ForeColor = Color.FromArgb(189, 195, 199),
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 50
            };

            // Loading progress
            var progressBar = new ProgressBar
            {
                Style = ProgressBarStyle.Marquee,
                MarqueeAnimationSpeed = 30,
                Height = 10,
                Dock = DockStyle.Bottom,
                ForeColor = Color.FromArgb(52, 152, 219)
            };

            // Add controls
            mainPanel.Controls.Add(progressBar);
            mainPanel.Controls.Add(lblTagline);
            mainPanel.Controls.Add(lblTitle);
            this.Controls.Add(pbBackground); // Add PictureBox first
            this.Controls.Add(mainPanel);    // Add mainPanel on top
            mainPanel.BringToFront();       // Ensure panel is above PictureBox

            // Ensure form is shown before closing
            this.Shown += (s, e) => {
                this.Refresh(); // Force form and controls to render
            };

            // Close after delay
            Task.Delay(3000).ContinueWith(t => {
                this.Invoke((MethodInvoker)delegate {
                    this.Close();
                });
            });
        }
    }
}