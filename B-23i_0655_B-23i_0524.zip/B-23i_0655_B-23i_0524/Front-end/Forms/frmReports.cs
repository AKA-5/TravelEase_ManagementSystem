﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Collections.Generic;
using System.IO;
using System.Drawing;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmReports : Form
    {
        private DataGridView _dgvReport;
        private ComboBox _cmbReports;
        private ComboBox _cmbGroupBy;
        private Button _btnExport;

        public frmReports()
        {
            InitializeComponent();
            SetupReportForm();
        }

        private void SetupReportForm()
        {
            this.Text = "TravelEase Reports";
            this.WindowState = FormWindowState.Maximized;

            // Main container panel
            var mainPanel = new Panel { Dock = DockStyle.Fill };

            // Filter panel (top)
            var filterPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = SystemColors.Control
            };

            // Report selection dropdown
            _cmbReports = new ComboBox
            {
                Dock = DockStyle.Left,
                Width = 300,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10)
            };

            // Populate report types
            _cmbReports.Items.AddRange(new[] {
                "Trip Booking and Revenue",
                "Traveler Demographics",
                "Tour Operator Performance",
                "Service Provider Efficiency",
                "Destination Popularity",
                "Abandoned Bookings",
                "Platform Growth",
                "Payment Transactions"
            });
            _cmbReports.SelectedIndex = 0;
            _cmbReports.SelectedIndexChanged += (s, e) => {
                UpdateGroupByVisibility();
                LoadSelectedReport();
            };

            // Group By dropdown
            _cmbGroupBy = new ComboBox
            {
                Dock = DockStyle.Left,
                Width = 150,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10),
                Visible = false
            };
            _cmbGroupBy.Items.AddRange(new[] { "TripType", "Capacity", "DurationInDays", "BookingMonth" });
            _cmbGroupBy.SelectedIndex = 0;
            _cmbGroupBy.SelectedIndexChanged += (s, e) => LoadSelectedReport();

            // Export button
            _btnExport = new Button
            {
                Text = "Export to CSV",
                Dock = DockStyle.Right,
                Width = 120,
                Font = new Font("Segoe UI", 10)
            };
            _btnExport.Click += (s, e) => ExportToCsv();

            // Add controls to filter panel
            filterPanel.Controls.Add(_cmbGroupBy);
            filterPanel.Controls.Add(_cmbReports);
            filterPanel.Controls.Add(_btnExport);

            // Data grid view for report display
            _dgvReport = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                BackgroundColor = SystemColors.Window,
                BorderStyle = BorderStyle.FixedSingle
            };

            // Add panels to main container
            mainPanel.Controls.Add(_dgvReport);
            mainPanel.Controls.Add(filterPanel);

            // Add main panel to form
            this.Controls.Add(mainPanel);

            // Load initial report
            LoadSelectedReport();
        }

        private void UpdateGroupByVisibility()
        {
            _cmbGroupBy.Visible = _cmbReports.SelectedItem.ToString() == "Trip Booking and Revenue";
        }

        private void frmReports_Load(object sender, EventArgs e)
        {
        }

        private void LoadSelectedReport()
        {
            try
            {
                string reportName = _cmbReports.SelectedItem.ToString();
                string query = GetReportQuery(reportName);

                DataTable reportData = DatabaseHelper.ExecuteQuery(query);
                _dgvReport.DataSource = reportData;

                // Format columns based on report type
                FormatReportColumns(reportName);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading report: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string GetReportQuery(string reportName)
        {
            switch (reportName)
            {
                case "Trip Booking and Revenue":
                    string groupByField = _cmbGroupBy.SelectedItem != null ? _cmbGroupBy.SelectedItem.ToString() : "TripType";
                    string groupByClause;
                    string selectClause;

                    switch (groupByField)
                    {
                        case "TripType":
                            groupByClause = "t.TripType";
                            selectClause = "t.TripType";
                            break;
                        case "Capacity":
                            groupByClause = "t.Capacity";
                            selectClause = "t.Capacity";
                            break;
                        case "DurationInDays":
                            groupByClause = "t.DurationInDays";
                            selectClause = "t.DurationInDays";
                            break;
                        case "BookingMonth":
                            groupByClause = "MONTH(t.StartDate)";
                            selectClause = "MONTH(t.StartDate) as BookingMonth";
                            break;
                        default:
                            groupByClause = "t.TripType";
                            selectClause = "t.TripType";
                            break;
                    }

                    return @"SELECT 
                                " + selectClause + @",
                                COUNT(b.TripID) as TotalBookings,
                                SUM(t.PricePerPersonInDollars) as RevenueInDollars,
                                SUM(CASE WHEN b.BStatus = 'Cancelled' THEN 1 ELSE 0 END) as Cancellations,
                                CASE 
                                    WHEN COUNT(b.TripID) = 0 THEN 0
                                    ELSE (SUM(CASE WHEN b.BStatus = 'Cancelled' THEN 1 ELSE 0 END) * 100.0 / COUNT(b.TripID))
                                END as CancellationRate,
                                AVG(t.PricePerPersonInDollars) as AverageBookingValueInDollars
                            FROM Trip t 
                            LEFT JOIN Booking b ON t.TripID = b.TripID
                            GROUP BY " + groupByClause;

                case "Traveler Demographics":
                    return @"SELECT 
                            t.Nationality,
                            COUNT(DISTINCT t.TravelerID) as TravelerCount,
                            AVG(t.Age) as AverageAge,
                            MIN(t.Age) as MinAge,
                            MAX(t.Age) as MaxAge,
                            (
                                SELECT TOP 1 p.Preference
                                FROM Preferences p
                                WHERE p.TravelerID IN (
                                    SELECT t2.TravelerID 
                                    FROM Traveler t2 
                                    WHERE t2.Nationality = t.Nationality
                                )
                                GROUP BY p.Preference
                                ORDER BY COUNT(*) DESC
                            ) as MostCommonPreference,
                            AVG(b.AvgSpending) as AvgSpendingPerTraveler
                        FROM Traveler t
                        LEFT JOIN (
                            SELECT 
                                b.TravelerID,
                                AVG(t.PricePerPersonInDollars) as AvgSpending
                            FROM Booking b
                            JOIN Trip t ON b.TripID = t.TripID
                            WHERE b.BStatus = 'Confirmed'
                            GROUP BY b.TravelerID
                        ) b ON t.TravelerID = b.TravelerID
                        GROUP BY t.Nationality
                        ORDER BY TravelerCount DESC";

                case "Tour Operator Performance":
                    return @"SELECT 
                                o.CompanyName,
                                AVG(r.Rating) as AverageOperatorRating,
                                SUM(t.PricePerPersonInDollars) as RevenuePerOperatorInDollars,
                                AVG(CASE 
                                    WHEN st.RespondedAt IS NOT NULL 
                                    THEN DATEDIFF(HOUR, st.CreatedAt, st.RespondedAt) 
                                    ELSE NULL 
                                END) as AverageResponseTime
                            FROM TourOperator o
                            LEFT JOIN Trip t ON o.OperatorID = t.OperatorID
                            LEFT JOIN Booking b ON t.TripID = b.TripID AND b.BStatus = 'Confirmed'
                            LEFT JOIN Review r ON t.TripID = r.TripID
                            LEFT JOIN SupportTicket st ON o.OperatorID = st.OperatorID
                            GROUP BY o.CompanyName";

                case "Service Provider Efficiency":
                    return @"SELECT 
                                p.SPName,
                                p.SPType,
                                AVG(r.Rating) as AverageRating,
                                COUNT(r.ReviewID) as NumberOfReviews,
                                AVG(p.OnTimePerformance) as TransportOnTimePerformance,
                                COUNT(sa.TripID) as Assignments,
                                AVG(CASE 
                                    WHEN s.MaxCapacity > 0 
                                    THEN (s.MaxCapacity - s.AvailableCapacity) * 100.0 / s.MaxCapacity 
                                    ELSE NULL 
                                END) as HotelOccupancyRate
                            FROM ServiceProvider p
                            LEFT JOIN ServiceAssignment sa ON p.ProviderID = sa.ProviderID
                            LEFT JOIN [Service] s ON sa.ServiceID = s.ServiceID AND sa.ProviderID = s.ProviderID
                            LEFT JOIN Review r ON p.ProviderID = r.ProviderID
                            GROUP BY p.SPName, p.SPType";

                case "Destination Popularity":
                    return @"SELECT 
                                d.Country,
                                d.City,
                                COUNT(DISTINCT b.TripID) as TotalBookings,
                                AVG(r.Rating) as AverageRating,
                                COUNT(DISTINCT CASE 
                                    WHEN t.StartDate BETWEEN DATEADD(month, -3, GETDATE()) AND GETDATE() 
                                    THEN b.TripID 
                                END) as RecentBookings,
                                CASE 
                                    WHEN COUNT(DISTINCT b.TripID) = 0 THEN 0
                                    ELSE (COUNT(DISTINCT CASE 
                                        WHEN t.StartDate BETWEEN DATEADD(month, -3, GETDATE()) AND GETDATE() 
                                        THEN b.TripID 
                                    END) * 100.0 / COUNT(DISTINCT b.TripID))
                                END as GrowthPercentage,
                                DATEPART(quarter, t.StartDate) as BookingQuarter,
                                YEAR(t.StartDate) as BookingYear
                            FROM Destination d
                            JOIN Trip t ON d.TripID = t.TripID
                            LEFT JOIN Booking b ON t.TripID = b.TripID AND b.BStatus = 'Confirmed'
                            LEFT JOIN Review r ON t.TripID = r.TripID
                            GROUP BY d.Country, d.City, DATEPART(quarter, t.StartDate), YEAR(t.StartDate)
                            ORDER BY 
                                Country, 
                                City, 
                                BookingYear DESC, 
                                BookingQuarter DESC,
                                TotalBookings DESC";

                case "Abandoned Bookings":
                    return @"SELECT t.Title,
                        COUNT(CASE WHEN b.BStatus = 'Abandoned' THEN 1 END) as Abandoned,
                        (COUNT(CASE WHEN b.BStatus = 'Abandoned' THEN 1 END) * 100.0 / 
                         NULLIF((SELECT COUNT(*) FROM Booking b2 WHERE b2.TripID = t.TripID), 0)) as AbandonmentRate,
                        STUFF((
                            SELECT ', ' + b2.AbandonmentReason
                            FROM Booking b2
                            WHERE b2.TripID = t.TripID AND b2.BStatus = 'Abandoned' AND b2.AbandonmentReason IS NOT NULL
                            FOR XML PATH('')
                        ), 1, 2, '') as CommonReasons,
                        COUNT(CASE WHEN b.BStatus = 'Recovered' THEN 1 END) as Recovered,
                        CASE 
                            WHEN COUNT(CASE WHEN b.BStatus = 'Abandoned' THEN 1 END) = 0 THEN 0
                            ELSE (COUNT(CASE WHEN b.BStatus = 'Recovered' THEN 1 END) * 100.0 / 
                                  NULLIF(COUNT(CASE WHEN b.BStatus = 'Abandoned' THEN 1 END), 0))
                        END as RecoveryRate,
                        SUM(CASE WHEN b.BStatus = 'Abandoned' THEN t.PricePerPersonInDollars ELSE 0 END) as PotentialRevenueLossInDollars
                    FROM Trip t
                    JOIN Booking b ON t.TripID = b.TripID
                    WHERE b.BStatus IN ('Abandoned', 'Recovered')
                    GROUP BY t.Title, t.TripID";

                case "Platform Growth":
                    return @"SELECT 
                                YEAR(RegistrationDate) AS Year,
                                MONTH(RegistrationDate) AS Month,
                                COUNT(CASE WHEN TravelerID IS NOT NULL THEN 1 END) AS NewTravelers,
                                COUNT(CASE WHEN OperatorID IS NOT NULL THEN 1 END) AS NewOperators,
                                COUNT(CASE WHEN ProviderID IS NOT NULL THEN 1 END) AS NewServiceProviders,
                                -- Active users (logged in within last 30 days)
                                COUNT(CASE WHEN TravelerID IS NOT NULL AND DATEDIFF(DAY, LastLogin, GETDATE()) <= 30 THEN 1 END) AS ActiveTravelers,
                                COUNT(CASE WHEN OperatorID IS NOT NULL AND DATEDIFF(DAY, LastLogin, GETDATE()) <= 30 THEN 1 END) AS ActiveOperators,
                                COUNT(CASE WHEN ProviderID IS NOT NULL AND DATEDIFF(DAY, LastLogin, GETDATE()) <= 30 THEN 1 END) AS ActiveServiceProviders,
                                -- Regional expansion (new destinations added that month)
                                (SELECT COUNT(DISTINCT Country) 
                                    FROM Destination d 
                                    JOIN Trip t ON d.TripID = t.TripID
                                    WHERE YEAR(t.CreatedAt) = YEAR(u.RegistrationDate)
                                    AND MONTH(t.CreatedAt) = MONTH(u.RegistrationDate)) AS NewDestinations,
                                -- Service provider registration date analysis
                                AVG(CASE WHEN ProviderID IS NOT NULL THEN DATEDIFF(DAY, RegistrationDate, GETDATE()) END) AS AvgProviderTenureDays
                            FROM (
                                SELECT TravelerID, NULL AS OperatorID, NULL AS ProviderID, RegistrationDate, LastLogin FROM Traveler
                                UNION ALL 
                                SELECT NULL, OperatorID, NULL, RegistrationDate, LastLogin FROM TourOperator
                                UNION ALL 
                                SELECT NULL, NULL, ProviderID, RegistrationDate, LastLogin FROM ServiceProvider
                            ) AS u
                            GROUP BY YEAR(RegistrationDate), MONTH(RegistrationDate), DATENAME(MONTH, RegistrationDate)
                            ORDER BY Year DESC, Month DESC";

                case "Payment Transactions":
                    return @"SELECT 
                                PaymentMethod,
                                COUNT(*) as TotalTransactions,
                                SUM(CASE WHEN PStatus = 'Success' THEN 1 ELSE 0 END) as SuccessCount,
                                SUM(CASE WHEN PStatus = 'Failed' THEN 1 ELSE 0 END) as FailedCount,
                                SUM(CASE WHEN PStatus = 'Pending' THEN 1 ELSE 0 END) as PendingCount,
                                SUM(CASE WHEN PStatus = 'Chargedback' THEN 1 ELSE 0 END) as ChargebackCount,
                                (SUM(CASE WHEN PStatus = 'Success' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)) as SuccessRate,
                                (SUM(CASE WHEN PStatus = 'Failed' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)) as FailureRate,    
                                (SUM(CASE WHEN PStatus = 'Pending' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)) as PendingRate,
                                (SUM(CASE WHEN PStatus = 'Chargedback' THEN 1 ELSE 0 END) * 100.0 / COUNT(*)) as ChargebackRate                                

                            FROM Payment
                            GROUP BY PaymentMethod";

                default:
                    return "SELECT 'No report selected' as Message";
            }
        }

        private void FormatReportColumns(string reportName)
        {
            if (_dgvReport.Columns.Count == 0) return;

            // Format currency columns
            if (reportName == "Trip Booking and Revenue" ||
                reportName == "Tour Operator Performance" ||
                reportName == "Abandoned Bookings")
            {
                foreach (DataGridViewColumn column in _dgvReport.Columns)
                {
                    if (column.Name.Contains("Revenue") || column.Name.Contains("Price") ||
                        column.Name.Contains("Loss") || column.Name.Contains("Total"))
                    {
                        column.DefaultCellStyle.Format = "N2";
                        column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    }
                    if (column.Name == "AverageResponseTime")
                    {
                        column.DefaultCellStyle.Format = "N2";
                        column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                        column.HeaderText = "Avg Response Time (Hours)";
                    }
                }
            }

            // Format columns for Service Provider Efficiency
            if (reportName == "Service Provider Efficiency")
            {
                foreach (DataGridViewColumn column in _dgvReport.Columns)
                {
                    if (column.Name == "AverageRating")
                    {
                        column.DefaultCellStyle.Format = "N1";
                        column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                        column.HeaderText = "Average Rating";
                    }
                    if (column.Name == "NumberOfReviews")
                    {
                        column.DefaultCellStyle.Format = "N0";
                        column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                        column.HeaderText = "Number of Reviews";
                    }
                    if (column.Name == "TransportOnTimePerformance" || column.Name == "HotelOccupancyRate")
                    {
                        column.DefaultCellStyle.Format = "N2";
                        column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    }
                }
            }

            // Format percentage columns
            foreach (DataGridViewColumn column in _dgvReport.Columns)
            {
                if (column.Name.Contains("Rate") && column.Name != "AverageRating")
                {
                    column.DefaultCellStyle.Format = "0.00\\%";
                    column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                }
            }

            // Auto-resize columns after formatting
            _dgvReport.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        private void ExportToCsv()
        {
            if (_dgvReport.Rows.Count == 0)
            {
                MessageBox.Show("No data to export", "Information",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv",
                Title = "Save Report As",
                FileName = $"TravelEase_Report_{_cmbReports.SelectedItem.ToString().Replace(" ", "_")}_{DateTime.Now:yyyyMMdd}.csv"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (StreamWriter writer = new StreamWriter(saveFileDialog.FileName))
                    {
                        // Write headers
                        for (int i = 0; i < _dgvReport.Columns.Count; i++)
                        {
                            writer.Write(_dgvReport.Columns[i].HeaderText);
                            if (i < _dgvReport.Columns.Count - 1)
                                writer.Write(",");
                        }
                        writer.WriteLine();

                        // Write rows
                        foreach (DataGridViewRow row in _dgvReport.Rows)
                        {
                            for (int i = 0; i < _dgvReport.Columns.Count; i++)
                            {
                                if (row.Cells[i].Value != null)
                                {
                                    string value = row.Cells[i].Value.ToString();
                                    // Escape commas and quotes
                                    if (value.Contains(",") || value.Contains("\""))
                                    {
                                        value = $"\"{value.Replace("\"", "\"\"")}\"";
                                    }
                                    writer.Write(value);
                                }
                                if (i < _dgvReport.Columns.Count - 1)
                                    writer.Write(",");
                            }
                            writer.WriteLine();
                        }
                    }

                    MessageBox.Show("Report exported successfully!", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error exporting report: {ex.Message}", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}