﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmServiceProvider : Form
    {
        private readonly string _providerId;
        private DataGridView _dgvServices;
        private DataGridView _dgvAssignments;
        private DataGridView _dgvReviews;
        private DataGridView _dgvReports;
        private Label _lblProviderInfo;
        private TextBox _txtSearch;
        private string _providerSPType;
        private readonly string[] _validSPTypes = { "Hotel", "Transport", "Guide", "Other" };

        public frmServiceProvider(string providerId)
        {
            _providerId = providerId;
            InitializeComponent();
            SetupServiceProviderForm();
            LoadProviderInfo();
            CheckDatabaseConnection();
        }

        private void SetupServiceProviderForm()
        {
            this.Text = "Service Provider Portal - ID: " + _providerId;
            this.WindowState = FormWindowState.Maximized;
            this.Font = new Font("Segoe UI", 9);

            _lblProviderInfo = new Label
            {
                Dock = DockStyle.Top,
                Height = 60,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                BackColor = Color.LightBlue
            };

            _txtSearch = new TextBox
            {
                Dock = DockStyle.Top,
                Height = 30,
                Text = "Search services, assignments, reviews, or reports...",
                ForeColor = Color.Gray
            };
            _txtSearch.GotFocus += (s, e) =>
            {
                if (_txtSearch.Text == "Search services, assignments, reviews, or reports...")
                {
                    _txtSearch.Text = "";
                    _txtSearch.ForeColor = SystemColors.WindowText;
                }
            };
            _txtSearch.LostFocus += (s, e) =>
            {
                if (string.IsNullOrWhiteSpace(_txtSearch.Text))
                {
                    _txtSearch.Text = "Search services, assignments, reviews, or reports...";
                    _txtSearch.ForeColor = Color.Gray;
                }
            };
            _txtSearch.TextChanged += (s, e) => FilterData();

            TabControl tabControl = new TabControl { Dock = DockStyle.Fill };
            tabControl.TabPages.Add(CreateServicesTab());
            tabControl.TabPages.Add(CreateAssignmentsTab());
            tabControl.TabPages.Add(CreateReviewsTab());
            tabControl.TabPages.Add(CreateReportsTab());

            this.Controls.AddRange(new Control[] { tabControl, _txtSearch, _lblProviderInfo });
            _txtSearch.TabIndex = 0;
            tabControl.TabIndex = 1;
        }

        private void CheckDatabaseConnection()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(DatabaseHelper.GetConnectionString()))
                {
                    connection.Open();
                    Console.WriteLine("Database connection successful");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Database connection failed: " + ex.Message);
                MessageBox.Show("Database connection failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadProviderInfo()
        {
            try
            {
                // Get basic provider info
                string query = "SELECT SPName, SPType, OnTimePerformance FROM ServiceProvider WHERE ProviderID = @ProviderID";
                var parameters = new Dictionary<string, object> { { "@ProviderID", _providerId } };
                DataTable provider = DatabaseHelper.ExecuteQuery(query, parameters);
                if (provider.Rows.Count > 0)
                {
                    DataRow row = provider.Rows[0];
                    _providerSPType = row["SPType"].ToString();

                    // Calculate average rating from reviews
                    string avgRatingQuery = "SELECT AVG(CAST(Rating AS DECIMAL(3,1))) AS AvgRating FROM Review WHERE ProviderID = @ProviderID";
                    DataTable avgRatingResult = DatabaseHelper.ExecuteQuery(avgRatingQuery, parameters);

                    decimal avgRating = 0;
                    if (avgRatingResult.Rows.Count > 0 && avgRatingResult.Rows[0]["AvgRating"] != DBNull.Value)
                    {
                        avgRating = Convert.ToDecimal(avgRatingResult.Rows[0]["AvgRating"]);
                    }

                    // Update the label with both on-time performance and calculated average rating
                    _lblProviderInfo.Text = row["SPName"] + " (" + _providerSPType + ")\n" +
                                           "Rating: " + avgRating.ToString("F1") + " ★ | On-Time: " +
                                           (row["OnTimePerformance"] == DBNull.Value ? "N/A" : row["OnTimePerformance"] + "%");
                    Console.WriteLine("Provider info loaded for ID: " + _providerId);
                }
                else
                {
                    Console.WriteLine("No provider info found for ID: " + _providerId);
                    MessageBox.Show("No provider info found.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error loading provider info: " + ex.Message);
                MessageBox.Show("Error loading provider info: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FilterData()
        {
            string searchText = _txtSearch.Text.Trim();
            Console.WriteLine("Filtering data with search text: " + searchText);

            if (string.IsNullOrEmpty(searchText) || searchText == "Search services, assignments, reviews, or reports...")
            {
                ApplyFilter(_dgvServices, "");
                ApplyFilter(_dgvAssignments, "");
                ApplyFilter(_dgvReviews, "");
                ApplyFilter(_dgvReports, "");
            }
            else
            {
                // Services Tab
                ApplyFilter(_dgvServices,
                    "ServiceID LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "SType LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "SPTypeCategory LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "Convert(ServiceCostInDollars, 'System.String') LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "Convert(MaxCapacity, 'System.String') LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "Convert(AvailableCapacity, 'System.String') LIKE '%" + searchText.Replace("'", "''") + "%'");

                // Assignments Tab
                ApplyFilter(_dgvAssignments,
                    "TripID LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "ServiceID LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "OperatorName LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "SAStatus LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "Convert(MaxCapacity, 'System.String') LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "Convert(AvailableCapacity, 'System.String') LIKE '%" + searchText.Replace("'", "''") + "%'");

                // Reviews Tab
                ApplyFilter(_dgvReviews,
                    "TravelerID LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "TripID LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "Comment LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "Convert(Rating, 'System.String') LIKE '%" + searchText.Replace("'", "''") + "%'");

                // Reports Tab
                ApplyFilter(_dgvReports,
                    "ServiceID LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "Convert(OccupancyRate, 'System.String') LIKE '%" + searchText.Replace("'", "''") + "%' OR " +
                    "Convert(TotalRevenue, 'System.String') LIKE '%" + searchText.Replace("'", "''") + "%'");
            }
        }

        private void ApplyFilter(DataGridView dgv, string filterExpression)
        {
            if (dgv != null && dgv.DataSource != null)
            {
                if (dgv.DataSource is DataTable dataTable)
                {
                    try
                    {
                        dataTable.DefaultView.RowFilter = filterExpression;
                        Console.WriteLine("Applied filter '" + filterExpression + "' to " + dgv.Name);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error applying filter to " + dgv.Name + ": " + ex.Message);
                        MessageBox.Show("Error filtering data in " + dgv.Name + ": " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        dataTable.DefaultView.RowFilter = ""; // Reset filter on error
                    }
                }
                else
                {
                    Console.WriteLine("DataSource for " + dgv.Name + " is not a DataTable, skipping filter.");
                }
            }
            else
            {
                Console.WriteLine("DataGridView or DataSource is null for " + (dgv?.Name ?? "unknown") + ", skipping filter.");
            }
        }

        #region Service Listing
        private TabPage CreateServicesTab()
        {
            TabPage tab = new TabPage("My Services");

            _dgvServices = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                BackgroundColor = SystemColors.Window,
                BorderStyle = BorderStyle.None
            };

            _dgvServices.Columns.AddRange(new DataGridViewColumn[]
            {
                new DataGridViewTextBoxColumn { Name = "ServiceID", HeaderText = "ID", DataPropertyName = "ServiceID", ReadOnly = true, Width = 80 },
                new DataGridViewTextBoxColumn { Name = "SType", HeaderText = "Service Type", DataPropertyName = "SType", Width = 150 },
                new DataGridViewComboBoxColumn
                {
                    Name = "SPTypeCategory",
                    HeaderText = "Category",
                    DataPropertyName = "SPTypeCategory",
                    DataSource = _validSPTypes,
                    FlatStyle = FlatStyle.Flat,
                    Width = 100
                },
                new DataGridViewTextBoxColumn { Name = "ServiceCostInDollars", HeaderText = "Cost ($)", DataPropertyName = "ServiceCostInDollars", Width = 80 },
                new DataGridViewTextBoxColumn { Name = "MaxCapacity", HeaderText = "Max Cap.", DataPropertyName = "MaxCapacity", Width = 80 },
                new DataGridViewTextBoxColumn { Name = "AvailableCapacity", HeaderText = "Available", DataPropertyName = "AvailableCapacity", Width = 80 }
            });

            Panel topButtonPanelServices = new Panel { Dock = DockStyle.Top, Height = 50, Padding = new Padding(5), Width = 670 };
            Button btnAdd = new Button { Text = "Add Service", Width = 120, Top = 10, Left = 10, Font = new Font("Segoe UI", 9), BackColor = SystemColors.ButtonFace, FlatStyle = FlatStyle.Standard };
            Button btnSave = new Button { Text = "Save Changes", Width = 120, Top = 10, Left = 140, Font = new Font("Segoe UI", 9), BackColor = SystemColors.ButtonFace, FlatStyle = FlatStyle.Standard };
            Button btnDelete = new Button { Text = "Delete Service", Width = 120, Top = 10, Left = 270, Font = new Font("Segoe UI", 9), BackColor = SystemColors.ButtonFace, FlatStyle = FlatStyle.Standard };
            Button btnRefresh = new Button { Text = "Refresh", Width = 120, Top = 10, Left = 400, Font = new Font("Segoe UI", 9), BackColor = SystemColors.ButtonFace, FlatStyle = FlatStyle.Standard };
            Button btnViewReports = new Button { Text = "View Reports", Width = 120, Top = 10, Left = 530, Font = new Font("Segoe UI", 9), BackColor = SystemColors.ButtonFace, FlatStyle = FlatStyle.Standard };

            btnAdd.Click += (s, e) => AddNewService();
            btnSave.Click += (s, e) => SaveServiceChanges();
            btnDelete.Click += (s, e) => DeleteService();
            btnRefresh.Click += (s, e) => LoadServices();
            btnViewReports.Click += (s, e) =>
            {
                var reportsForm = new frmReports();
                reportsForm.ShowDialog();
            };

            topButtonPanelServices.Controls.AddRange(new Control[] { btnAdd, btnSave, btnDelete, btnRefresh, btnViewReports });
            tab.Controls.AddRange(new Control[] { _dgvServices, topButtonPanelServices });

            _dgvServices.DataError += (s, e) =>
            {
                e.Cancel = true;
                Console.WriteLine("DataGridView error in Services: " + e.Exception.Message);
                MessageBox.Show("Invalid data entered: " + e.Exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            LoadServices();
            return tab;
        }

        private void LoadServices()
        {
            try
            {
                string query = "SELECT s.ServiceID, s.SType, sp.SPType AS SPTypeCategory, s.ServiceCostInDollars, s.MaxCapacity, s.AvailableCapacity " +
                               "FROM [Service] s JOIN ServiceProvider sp ON s.ProviderID = sp.ProviderID WHERE s.ProviderID = @ProviderID ORDER BY s.ServiceID";
                var parameters = new Dictionary<string, object> { { "@ProviderID", _providerId } };
                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                if (dt.Rows.Count == 0)
                {
                    dt = CreateEmptyServicesTable();
                    MessageBox.Show("No services found. Please add a service.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                _dgvServices.DataSource = dt;
                _dgvServices.ClearSelection();
                Console.WriteLine("Loaded " + dt.Rows.Count + " services for ProviderID: " + _providerId);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error loading services: " + ex.Message);
                _dgvServices.DataSource = CreateEmptyServicesTable();
                MessageBox.Show("Error loading services: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private DataTable CreateEmptyServicesTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ServiceID", typeof(string));
            dt.Columns.Add("SType", typeof(string));
            dt.Columns.Add("SPTypeCategory", typeof(string));
            dt.Columns.Add("ServiceCostInDollars", typeof(int));
            dt.Columns.Add("MaxCapacity", typeof(int));
            dt.Columns.Add("AvailableCapacity", typeof(int));
            return dt;
        }

        private void AddNewService()
        {
            try
            {
                string query = "SELECT TOP 1 ServiceID FROM [Service] WHERE ProviderID = @ProviderID AND ServiceID LIKE 'SV[0-9][0-9][0-9]' ORDER BY ServiceID DESC";
                var parameters = new Dictionary<string, object> { { "@ProviderID", _providerId } };
                DataTable result = DatabaseHelper.ExecuteQuery(query, parameters);

                string serviceId;
                if (result.Rows.Count == 0)
                    serviceId = "SV001";
                else
                {
                    string lastServiceId = result.Rows[0]["ServiceID"].ToString();
                    string numericPart = lastServiceId.Substring(2);
                    if (int.TryParse(numericPart, out int number))
                    {
                        number++;
                        if (number > 999) throw new Exception("Service ID limit reached (SV999).");
                        serviceId = $"SV{number:D3}";
                    }
                    else throw new Exception("Invalid ServiceID format: " + lastServiceId);
                }

                string defaultSType = _providerSPType + " Service";
                Form inputForm = new Form { Text = "Add New Service", Size = new Size(300, 200), StartPosition = FormStartPosition.CenterParent, FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false };
                Label lblSType = new Label { Text = "Service Type:", Top = 20, Left = 20, Width = 100 };
                TextBox txtSType = new TextBox { Text = defaultSType, Top = 20, Left = 120, Width = 150 };
                Label lblCost = new Label { Text = "Cost ($):", Top = 50, Left = 20, Width = 100 };
                NumericUpDown numCost = new NumericUpDown { Minimum = 0, Maximum = 10000, Top = 50, Left = 120, Width = 150 };
                Label lblMaxCap = new Label { Text = "Max Capacity:", Top = 80, Left = 20, Width = 100 };
                NumericUpDown numMaxCap = new NumericUpDown { Minimum = 1, Maximum = 1000, Value = 1, Top = 80, Left = 120, Width = 150 };
                Label lblAvailCap = new Label { Text = "Available Capacity:", Top = 110, Left = 20, Width = 100 };
                NumericUpDown numAvailCap = new NumericUpDown { Minimum = 0, Maximum = 1000, Value = 1, Top = 110, Left = 120, Width = 150 };
                Button btnOk = new Button { Text = "OK", Top = 140, Left = 120, Width = 70, DialogResult = DialogResult.OK };
                Button btnCancel = new Button { Text = "Cancel", Top = 140, Left = 200, Width = 70, DialogResult = DialogResult.Cancel };

                inputForm.Controls.AddRange(new Control[] { lblSType, txtSType, lblCost, numCost, lblMaxCap, numMaxCap, lblAvailCap, numAvailCap, btnOk, btnCancel });
                inputForm.AcceptButton = btnOk;
                inputForm.CancelButton = btnCancel;

                if (inputForm.ShowDialog() == DialogResult.OK)
                {
                    string sType = txtSType.Text.Trim();
                    if (string.IsNullOrEmpty(sType))
                    {
                        MessageBox.Show("Service type is required.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    int cost = (int)numCost.Value;
                    int maxCap = (int)numMaxCap.Value;
                    int availCap = (int)numAvailCap.Value;

                    if (availCap > maxCap)
                    {
                        MessageBox.Show("Available capacity cannot exceed max capacity.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    string insertQuery = "INSERT INTO [Service] (ServiceID, ProviderID, SType, ServiceCostInDollars, MaxCapacity, AvailableCapacity) VALUES (@ServiceID, @ProviderID, @SType, @Cost, @MaxCap, @AvailCap)";
                    var insertParams = new Dictionary<string, object>
                    {
                        { "@ServiceID", serviceId },
                        { "@ProviderID", _providerId },
                        { "@SType", sType },
                        { "@Cost", cost },
                        { "@MaxCap", maxCap },
                        { "@AvailCap", availCap }
                    };
                    int insertResult = DatabaseHelper.ExecuteNonQuery(insertQuery, insertParams);
                    if (insertResult > 0)
                    {
                        LoadServices();
                        Console.WriteLine("Service added: " + serviceId);
                        MessageBox.Show("Service added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error adding service: " + ex.Message);
                MessageBox.Show("Error adding service: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveServiceChanges()
        {
            if (_dgvServices.DataSource == null) return;

            try
            {
                DataTable dt = (DataTable)_dgvServices.DataSource;
                DataTable changes = dt.GetChanges();
                if (changes == null || changes.Rows.Count == 0)
                {
                    MessageBox.Show("No changes to save.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                using (SqlConnection connection = new SqlConnection(DatabaseHelper.GetConnectionString()))
                {
                    connection.Open();
                    SqlTransaction transaction = connection.BeginTransaction();
                    try
                    {
                        foreach (DataRow row in changes.Rows)
                        {
                            if (!ValidateServiceRow(row, out string errorMessage))
                                throw new Exception("Validation failed: " + errorMessage);

                            string query = "UPDATE [Service] SET SType = @SType, ServiceCostInDollars = @Cost, MaxCapacity = @MaxCap, AvailableCapacity = @AvailCap WHERE ServiceID = @ServiceID AND ProviderID = @ProviderID";
                            var parameters = new Dictionary<string, object>
                            {
                                { "@SType", row["SType"] },
                                { "@Cost", Convert.ToInt32(row["ServiceCostInDollars"]) },
                                { "@MaxCap", Convert.ToInt32(row["MaxCapacity"]) },
                                { "@AvailCap", Convert.ToInt32(row["AvailableCapacity"]) },
                                { "@ServiceID", row["ServiceID"] },
                                { "@ProviderID", _providerId }
                            };
                            using (SqlCommand command = new SqlCommand(query, connection, transaction))
                            {
                                foreach (var param in parameters)
                                    command.Parameters.AddWithValue(param.Key, param.Value);
                                command.ExecuteNonQuery();
                            }
                        }
                        transaction.Commit();
                        dt.AcceptChanges();
                        Console.WriteLine("Saved " + changes.Rows.Count + " service changes");
                        MessageBox.Show("Changes saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        dt.RejectChanges();
                        _dgvServices.Refresh();
                        Console.WriteLine("Error saving changes: " + ex.Message);
                        MessageBox.Show("Error saving changes: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Critical error during save: " + ex.Message);
                MessageBox.Show("Critical error during save: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateServiceRow(DataRow row, out string errorMessage)
        {
            errorMessage = "";
            if (row["SType"] == DBNull.Value || string.IsNullOrWhiteSpace(row["SType"].ToString()))
            {
                errorMessage = "Service type is required";
                return false;
            }
            string spTypeCategory = row["SPTypeCategory"].ToString();
            if (spTypeCategory != _providerSPType)
            {
                errorMessage = "Service category must match provider type";
                return false;
            }
            int cost;
            if (!int.TryParse(row["ServiceCostInDollars"].ToString(), out cost) || cost < 0)
            {
                errorMessage = "Cost must be a positive number";
                return false;
            }
            int maxCap;
            if (!int.TryParse(row["MaxCapacity"].ToString(), out maxCap) || maxCap < 1)
            {
                errorMessage = "Max capacity must be at least 1";
                return false;
            }
            int availCap;
            if (!int.TryParse(row["AvailableCapacity"].ToString(), out availCap) || availCap < 0 || availCap > maxCap)
            {
                errorMessage = "Available capacity must be between 0 and max capacity";
                return false;
            }
            return true;
        }

        private void DeleteService()
        {
            if (_dgvServices.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select a service to delete.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string serviceId = _dgvServices.SelectedRows[0].Cells["ServiceID"].Value.ToString();
                string query = "DELETE FROM [Service] WHERE ServiceID = @ServiceID AND ProviderID = @ProviderID";
                var parameters = new Dictionary<string, object> { { "@ServiceID", serviceId }, { "@ProviderID", _providerId } };
                int result = DatabaseHelper.ExecuteNonQuery(query, parameters);
                if (result > 0)
                {
                    LoadServices();
                    Console.WriteLine("Service deleted: " + serviceId);
                    MessageBox.Show("Service deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error deleting service: " + ex.Message);
                MessageBox.Show("Error deleting service: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Service Integration
        private TabPage CreateAssignmentsTab()
        {
            TabPage tab = new TabPage("Service Assignments");

            _dgvAssignments = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                ReadOnly = true,
                BackgroundColor = SystemColors.Window,
                BorderStyle = BorderStyle.None
            };

            _dgvAssignments.Columns.AddRange(new DataGridViewColumn[]
            {
        new DataGridViewTextBoxColumn { Name = "TripID", HeaderText = "Trip ID", DataPropertyName = "TripID", Width = 100 },
        new DataGridViewTextBoxColumn { Name = "ServiceID", HeaderText = "Service ID", DataPropertyName = "ServiceID", Width = 100 },
        new DataGridViewTextBoxColumn { Name = "OperatorName", HeaderText = "Operator", DataPropertyName = "OperatorName", Width = 150 },
        new DataGridViewTextBoxColumn { Name = "MaxCapacity", HeaderText = "Max Capacity", DataPropertyName = "MaxCapacity", Width = 100 },
        new DataGridViewTextBoxColumn { Name = "AvailableCapacity", HeaderText = "Available Capacity", DataPropertyName = "AvailableCapacity", Width = 120 },
        new DataGridViewTextBoxColumn { Name = "SAStatus", HeaderText = "Status", DataPropertyName = "SAStatus", Width = 80 }
            });

            _dgvAssignments.RowPrePaint += (sender, e) =>
            {
                if (e.RowIndex < 0 || e.RowIndex >= _dgvAssignments.Rows.Count) return;
                var row = _dgvAssignments.Rows[e.RowIndex];
                if (row.IsNewRow) return;

                string status = row.Cells["SAStatus"].Value?.ToString();
                int availableCapacity = Convert.ToInt32(row.Cells["AvailableCapacity"].Value);

                // Status coloring
                if (status == "Pending")
                    row.DefaultCellStyle.BackColor = Color.LightYellow;
                else if (status == "Accepted")
                    row.DefaultCellStyle.BackColor = Color.LightGreen;
                else
                    row.DefaultCellStyle.BackColor = Color.LightPink;

                // Capacity warning
                if (availableCapacity <= 0)
                {
                    row.Cells["AvailableCapacity"].Style.ForeColor = Color.Red;
                    row.Cells["AvailableCapacity"].Style.Font = new Font(_dgvAssignments.Font, FontStyle.Bold);
                }
            };

            Panel panel = new Panel { Dock = DockStyle.Top, Height = 50, Padding = new Padding(5) };
            Button btnAccept = new Button { Text = "Accept", Width = 100, Top = 10, Left = 10, BackColor = Color.LightGreen };
            Button btnReject = new Button { Text = "Reject", Width = 100, Top = 10, Left = 120, BackColor = Color.LightPink };
            Button btnRefresh = new Button { Text = "Refresh", Width = 100, Top = 10, Left = 230 };

            btnAccept.Click += (s, e) => UpdateAssignmentStatus("Accepted");
            btnReject.Click += (s, e) => UpdateAssignmentStatus("Rejected");
            btnRefresh.Click += (s, e) => LoadAssignments();

            panel.Controls.AddRange(new Control[] { btnAccept, btnReject, btnRefresh });
            tab.Controls.AddRange(new Control[] { _dgvAssignments, panel });

            LoadAssignments();
            return tab;
        }

        private void LoadAssignments()
        {
            try
            {
                string query = @"
            SELECT 
                sa.TripID, 
                sa.ServiceID, 
                COALESCE(op.CompanyName, 'Unknown Operator') AS OperatorName,
                s.MaxCapacity,
                s.AvailableCapacity,
                sa.SAStatus
            FROM ServiceAssignment sa
            INNER JOIN [Service] s ON sa.ServiceID = s.ServiceID AND sa.ProviderID = s.ProviderID
            LEFT JOIN TourOperator op ON sa.OperatorID = op.OperatorID
            WHERE sa.ProviderID = @ProviderID
            ORDER BY 
                CASE sa.SAStatus
                    WHEN 'Pending' THEN 1
                    WHEN 'Accepted' THEN 2
                    ELSE 3
                END,
                sa.TripID";

                var parameters = new Dictionary<string, object> { { "@ProviderID", _providerId } };
                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);

                if (dt.Rows.Count == 0)
                {
                    dt = CreateEmptyAssignmentsTable();
                    MessageBox.Show("No assignments found.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                _dgvAssignments.DataSource = dt;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error loading assignments: " + ex.Message);
                _dgvAssignments.DataSource = CreateEmptyAssignmentsTable();
                MessageBox.Show("Error loading assignments: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private DataTable CreateEmptyAssignmentsTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("TripID", typeof(string));
            dt.Columns.Add("ServiceID", typeof(string));
            dt.Columns.Add("OperatorName", typeof(string));
            dt.Columns.Add("MaxCapacity", typeof(int));
            dt.Columns.Add("AvailableCapacity", typeof(int));
            dt.Columns.Add("SAStatus", typeof(string));
            return dt;
        }

        private void UpdateAssignmentStatus(string newStatus)
        {
            if (_dgvAssignments.SelectedRows.Count == 0)
            {
                MessageBox.Show("Select an assignment to update.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow selectedRow = _dgvAssignments.SelectedRows[0];
            string tripId = selectedRow.Cells["TripID"].Value.ToString();
            string serviceId = selectedRow.Cells["ServiceID"].Value.ToString();
            string currentStatus = selectedRow.Cells["SAStatus"].Value.ToString();

            using (SqlConnection connection = new SqlConnection(DatabaseHelper.GetConnectionString()))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    // Get traveler count for the trip
                    string travelerCountQuery = @"
                SELECT COUNT(*) AS TravelerCount 
                FROM Booking b 
                WHERE b.TripID = @TripID 
                AND b.BStatus = 'Confirmed'";

                    int travelerCount = 0;
                    using (SqlCommand cmd = new SqlCommand(travelerCountQuery, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("@TripID", tripId);
                        travelerCount = Convert.ToInt32(cmd.ExecuteScalar());
                        Console.WriteLine($"Traveler count for Trip {tripId}: {travelerCount}");
                    }

                    // Handle capacity changes based on status transitions
                    if (currentStatus != newStatus)
                    {
                        if (newStatus == "Accepted" && currentStatus != "Accepted")
                        {
                            // Only decrease capacity when accepting a non-accepted assignment
                            string updateCapacityQuery = @"
                        UPDATE [Service] 
                        SET AvailableCapacity = AvailableCapacity - @TravelerCount 
                        WHERE ServiceID = @ServiceID 
                        AND ProviderID = @ProviderID 
                        AND AvailableCapacity >= @TravelerCount";

                            using (SqlCommand cmd = new SqlCommand(updateCapacityQuery, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@ServiceID", serviceId);
                                cmd.Parameters.AddWithValue("@ProviderID", _providerId);
                                cmd.Parameters.AddWithValue("@TravelerCount", travelerCount);

                                int rowsAffected = cmd.ExecuteNonQuery();
                                if (rowsAffected == 0)
                                {
                                    transaction.Rollback();
                                    MessageBox.Show("Not enough available capacity for this assignment.",
                                                  "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                                }
                            }
                        }
                        else if (newStatus == "Rejected" && currentStatus == "Accepted")
                        {
                            // Only increase capacity when rejecting a previously accepted assignment
                            string updateCapacityQuery = @"
                        UPDATE [Service] 
                        SET AvailableCapacity = AvailableCapacity + @TravelerCount 
                        WHERE ServiceID = @ServiceID 
                        AND ProviderID = @ProviderID";

                            using (SqlCommand cmd = new SqlCommand(updateCapacityQuery, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@ServiceID", serviceId);
                                cmd.Parameters.AddWithValue("@ProviderID", _providerId);
                                cmd.Parameters.AddWithValue("@TravelerCount", travelerCount);
                                cmd.ExecuteNonQuery();
                            }
                        }
                    }

                    // Update assignment status
                    string updateStatusQuery = @"
                UPDATE ServiceAssignment 
                SET SAStatus = @NewStatus 
                WHERE TripID = @TripID 
                AND ServiceID = @ServiceID 
                AND ProviderID = @ProviderID";

                    using (SqlCommand cmd = new SqlCommand(updateStatusQuery, connection, transaction))
                    {
                        cmd.Parameters.AddWithValue("@NewStatus", newStatus);
                        cmd.Parameters.AddWithValue("@TripID", tripId);
                        cmd.Parameters.AddWithValue("@ServiceID", serviceId);
                        cmd.Parameters.AddWithValue("@ProviderID", _providerId);
                        cmd.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    LoadAssignments(); // Refresh the view
                    MessageBox.Show($"Assignment status updated to {newStatus}",
                                  "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    Console.WriteLine("Error updating assignment: " + ex.Message);
                    MessageBox.Show("Error updating assignment: " + ex.Message,
                                  "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        #endregion

        #region Reviews
        private TabPage CreateReviewsTab()
        {
            TabPage tab = new TabPage("Reviews");

            _dgvReviews = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                ReadOnly = true,
                BackgroundColor = SystemColors.Window,
                BorderStyle = BorderStyle.None
            };

            _dgvReviews.Columns.AddRange(new DataGridViewColumn[]
            {
                new DataGridViewTextBoxColumn { Name = "TravelerID", HeaderText = "Traveler ID", DataPropertyName = "TravelerID", Width = 100 },
                new DataGridViewTextBoxColumn { Name = "TripID", HeaderText = "Trip ID", DataPropertyName = "TripID", Width = 100 },
                new DataGridViewTextBoxColumn { Name = "Rating", HeaderText = "Rating", DataPropertyName = "Rating", Width = 80 },
                new DataGridViewTextBoxColumn { Name = "Comment", HeaderText = "Comment", DataPropertyName = "Comment", Width = 300 }
            });

            Panel panel = new Panel { Dock = DockStyle.Top, Height = 50, Padding = new Padding(5) };
            Button btnRefresh = new Button { Text = "Refresh", Width = 120, Top = 10, Left = 10 };
            Button btnExportCSV = new Button { Text = "Export to CSV", Width = 120, Top = 10, Left = 140 };

            btnRefresh.Click += (s, e) => LoadReviews();
            btnExportCSV.Click += (s, e) => ExportReviewsToCSV();

            panel.Controls.AddRange(new Control[] { btnRefresh, btnExportCSV });
            tab.Controls.AddRange(new Control[] { _dgvReviews, panel });

            LoadReviews();
            return tab;
        }

        private void LoadReviews()
        {
            try
            {
                string query = "SELECT r.TravelerID, r.TripID, r.Rating, r.Comment FROM Review r WHERE r.ProviderID = @ProviderID";
                var parameters = new Dictionary<string, object> { { "@ProviderID", _providerId } };
                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                if (dt.Rows.Count == 0)
                {
                    dt = CreateEmptyReviewsTable();
                    MessageBox.Show("No reviews found.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                _dgvReviews.DataSource = dt;
                Console.WriteLine("Loaded " + dt.Rows.Count + " reviews for ProviderID: " + _providerId);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error loading reviews: " + ex.Message);
                _dgvReviews.DataSource = CreateEmptyReviewsTable();
                MessageBox.Show("Error loading reviews: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private DataTable CreateEmptyReviewsTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("TravelerID", typeof(string));
            dt.Columns.Add("TripID", typeof(string));
            dt.Columns.Add("Rating", typeof(int));
            dt.Columns.Add("Comment", typeof(string));
            return dt;
        }

        private void ExportReviewsToCSV()
        {
            if (_dgvReviews.Rows.Count == 0)
            {
                MessageBox.Show("No data to export.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv",
                Title = "Export Reviews to CSV",
                FileName = "Reviews_" + _providerId + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (System.IO.StreamWriter sw = new System.IO.StreamWriter(saveFileDialog.FileName))
                    {
                        string header = string.Join(",", _dgvReviews.Columns.Cast<DataGridViewColumn>().Select(column => "\"" + column.HeaderText.Replace("\"", "\"\"") + "\""));
                        sw.WriteLine(header);

                        foreach (DataGridViewRow row in _dgvReviews.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                string data = string.Join(",", row.Cells.Cast<DataGridViewCell>().Select(cell => "\"" + (cell.Value?.ToString() ?? "").Replace("\"", "\"\"") + "\""));
                                sw.WriteLine(data);
                            }
                        }

                        Console.WriteLine("Reviews exported to: " + saveFileDialog.FileName);
                        MessageBox.Show("Reviews exported successfully to " + saveFileDialog.FileName, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error exporting to CSV: " + ex.Message);
                    MessageBox.Show("Error exporting to CSV: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        #endregion

        #region Performance Reports
        private TabPage CreateReportsTab()
        {
            TabPage tab = new TabPage("Performance Reports");

            _dgvReports = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                ReadOnly = true,
                BackgroundColor = SystemColors.Window,
                BorderStyle = BorderStyle.None
            };

            _dgvReports.Columns.AddRange(new DataGridViewColumn[]
            {
        new DataGridViewTextBoxColumn { Name = "ServiceID", HeaderText = "Service ID", DataPropertyName = "ServiceID", Width = 100, ReadOnly = true },
        new DataGridViewTextBoxColumn { Name = "OccupancyRate", HeaderText = "Occupancy Rate (%)", DataPropertyName = "OccupancyRate", Width = 120, ReadOnly = true },
        new DataGridViewTextBoxColumn { Name = "TotalRevenue", HeaderText = "Total Revenue ($)", DataPropertyName = "TotalRevenue", Width = 120, ReadOnly = true }
            });

            _dgvReports.DataError += (s, e) =>
            {
                e.Cancel = true;
                Console.WriteLine("DataGridView error in Reports: " + e.Exception.Message + " at row " + e.RowIndex + ", column " + e.ColumnIndex);
                MessageBox.Show("Data error in Performance Reports: " + e.Exception.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            };

            Panel panel = new Panel { Dock = DockStyle.Top, Height = 50, Padding = new Padding(5) };
            Button btnRefresh = new Button { Text = "Refresh", Width = 120, Top = 10, Left = 10 };
            Button btnExportCSV = new Button { Text = "Export to CSV", Width = 120, Top = 10, Left = 140 };

            btnRefresh.Click += (s, e) => LoadReports();
            btnExportCSV.Click += (s, e) => ExportReportsToCSV();

            panel.Controls.AddRange(new Control[] { btnRefresh, btnExportCSV });
            tab.Controls.AddRange(new Control[] { _dgvReports, panel });

            LoadReports();
            return tab;
        }

        private void ExportReportsToCSV()
        {
            if (_dgvReports.Rows.Count == 0)
            {
                MessageBox.Show("No data to export.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "CSV files (*.csv)|*.csv",
                Title = "Export Performance Reports to CSV",
                FileName = "PerformanceReports_" + _providerId + "_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".csv"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (System.IO.StreamWriter sw = new System.IO.StreamWriter(saveFileDialog.FileName))
                    {
                        string header = string.Join(",", _dgvReports.Columns.Cast<DataGridViewColumn>().Select(column => "\"" + column.HeaderText.Replace("\"", "\"\"") + "\""));
                        sw.WriteLine(header);

                        foreach (DataGridViewRow row in _dgvReports.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                string data = string.Join(",", row.Cells.Cast<DataGridViewCell>().Select(cell => "\"" + (cell.Value?.ToString() ?? "").Replace("\"", "\"\"") + "\""));
                                sw.WriteLine(data);
                            }
                        }

                        Console.WriteLine("Performance reports exported to: " + saveFileDialog.FileName);
                        MessageBox.Show("Performance reports exported successfully to " + saveFileDialog.FileName, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error exporting performance reports to CSV: " + ex.Message);
                    MessageBox.Show("Error exporting performance reports to CSV: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void LoadReports()
        {
            try
            {
                Console.WriteLine("Starting to load reports for ProviderID: " + _providerId);
                string query = @"
            SELECT 
                s.ServiceID,
                CAST(CASE WHEN s.MaxCapacity > 0 THEN ((s.MaxCapacity - s.AvailableCapacity) * 100.0 / s.MaxCapacity) ELSE 0 END AS DECIMAL(5,2)) AS OccupancyRate,
                (s.ServiceCostInDollars * (s.MaxCapacity - s.AvailableCapacity)) AS TotalRevenue 
            FROM [Service] s 
            WHERE s.ProviderID = @ProviderID";

                var parameters = new Dictionary<string, object> { { "@ProviderID", _providerId } };
                DataTable sourceDt = DatabaseHelper.ExecuteQuery(query, parameters);
                Console.WriteLine("Retrieved DataTable with " + sourceDt.Rows.Count + " rows from database");

                // Create a new DataTable to hold formatted data
                DataTable dt = CreateEmptyReportsTable();
                Console.WriteLine("Created new DataTable for formatted data");

                if (sourceDt.Rows.Count == 0)
                {
                    Console.WriteLine("No data found, using empty DataTable");
                    MessageBox.Show("No performance data available.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    Console.WriteLine("Processing " + sourceDt.Rows.Count + " rows for formatting");
                    foreach (DataRow sourceRow in sourceDt.Rows)
                    {
                        DataRow newRow = dt.NewRow();
                        Console.WriteLine("Processing row: ServiceID = " + sourceRow["ServiceID"]);

                        newRow["ServiceID"] = sourceRow["ServiceID"].ToString();
                        newRow["OccupancyRate"] = sourceRow["OccupancyRate"] == DBNull.Value ? "0.00" : Convert.ToDecimal(sourceRow["OccupancyRate"]).ToString("F2");
                        Console.WriteLine("Set OccupancyRate to: " + newRow["OccupancyRate"]);
                        newRow["TotalRevenue"] = sourceRow["TotalRevenue"] == DBNull.Value ? "0.00" : Convert.ToDecimal(sourceRow["TotalRevenue"]).ToString("F2");
                        Console.WriteLine("Set TotalRevenue to: " + newRow["TotalRevenue"]);

                        dt.Rows.Add(newRow);
                    }
                }
                _dgvReports.DataSource = dt;
                Console.WriteLine("Assigned DataTable to DataGridView with " + dt.Rows.Count + " rows");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error loading reports: " + ex.Message + " at StackTrace: " + ex.StackTrace);
                _dgvReports.DataSource = CreateEmptyReportsTable();
                MessageBox.Show("Error loading reports: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private DataTable CreateEmptyReportsTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ServiceID", typeof(string));
            dt.Columns.Add("OccupancyRate", typeof(string));
            dt.Columns.Add("TotalRevenue", typeof(string));

            Console.WriteLine("Created empty DataTable with columns: ServiceID, OccupancyRate, TotalRevenue");
            return dt;
        }
        #endregion
        private void frmServiceProvider_Load(object sender, EventArgs e)
        {

        }
    }
}