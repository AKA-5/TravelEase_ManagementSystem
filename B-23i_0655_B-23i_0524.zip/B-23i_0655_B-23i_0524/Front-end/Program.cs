﻿using System;
using System.Threading;
using System.Windows.Forms;
using Travel_Ease_App.Forms;

namespace Travel_Ease_App
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Ensure single instance and proper cleanup
            bool createdNew;
            var mutex = new Mutex(true, "TravelEaseAppMutex", out createdNew);

            if (!createdNew)
            {
                MessageBox.Show("Application is already running!");
                return;
            }

            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                // Show splash screen as a modal dialog
                using (var splashForm = new frmSplash())
                {
                    splashForm.ShowDialog();
                }

                // Update trip statuses at startup
                string updateStatusQuery = "EXEC sp_UpdateTripStatus";
                Travel_Ease_App.Data.DatabaseHelper.ExecuteNonQuery(updateStatusQuery);

                // Update voucher statuses at startup
                string updateVoucherStatusQuery = "EXEC sp_UpdateVoucherStatus";
                Travel_Ease_App.Data.DatabaseHelper.ExecuteNonQuery(updateVoucherStatusQuery);

                // Start the application with frmLogin as the main form
                Application.Run(new frmLogin());
            }
            finally
            {
                mutex?.Close();
                mutex?.Dispose();
                Application.Exit();
            }
        }

    }
}