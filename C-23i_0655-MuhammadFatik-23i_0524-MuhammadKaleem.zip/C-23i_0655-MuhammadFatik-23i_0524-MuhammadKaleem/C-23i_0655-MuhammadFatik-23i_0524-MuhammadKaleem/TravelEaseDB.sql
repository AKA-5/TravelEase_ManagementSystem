-- To Create The Database with all Insertions, simply follow the 5 steps below (one-by-one):

-- STEP 1: Creating the Database
Create Database TravelEase;

-- STEP 2: Using the Database
Use TravelEase;

/*
	STEP 3: CREATING TABLES:
*/

CREATE TABLE Traveler 
(
    TravelerID VARCHAR(10) PRIMARY KEY,

    FullName VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    TPassword VARCHAR(255) NOT NULL,
    
	PhoneNumber VARCHAR(20),
    Nationality VARCHAR(50),
    
	Age INT CHECK (Age >= 5 AND Age <= 120),
    
	AccountStatus VARCHAR(10) CHECK (AccountStatus IN ('Active', 'Inactive')) NOT NULL DEFAULT 'Active',
    
	RegistrationDate DATETIME NOT NULL DEFAULT GETDATE(),
    LastLogin DATETIME NOT NULL DEFAULT GETDATE()
);


CREATE TABLE Preferences (
    TravelerID VARCHAR(10) NOT NULL,

    Preference VARCHAR(50) NOT NULL CHECK (
        Preference IN ('Adventure', 'Cultural', 'Leisure', 'Historical', 'Luxury', 'Solo', 'Group')
    ),
    FOREIGN KEY (TravelerID) REFERENCES Traveler(TravelerID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    
	PRIMARY KEY (TravelerID, Preference)
);


CREATE Table TourOperator (
    OperatorID Varchar (10) PRIMARY KEY,

    CompanyName VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    TOPassword VARCHAR(255) NOT NULL,

    Phone VARCHAR(20),
    Rating DECIMAL(2,1) CHECK (Rating >= 1 AND Rating <= 5),

    RegistrationDate DATETIME NOT NULL DEFAULT GETDATE(),
    LastLogin DATETIME NOT NULL DEFAULT GETDATE(),
	AccountStatus VARCHAR(10) CHECK (AccountStatus IN ('Active', 'Inactive')) NOT NULL DEFAULT 'Active'
);



CREATE TABLE Trip (
    TripID VARCHAR(10) PRIMARY KEY,

    Title VARCHAR(100) NOT NULL,
    TDescription TEXT,

    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    
	PricePerPersonInDollars DECIMAL(10, 2) NOT NULL CHECK (PricePerPersonInDollars >= 0),
    TripType VARCHAR(20) NOT NULL CHECK (
        TripType IN ('Adventure', 'Cultural', 'Leisure', 'Historical', 'Luxury', 'Solo', 'Group')
    ),

    Capacity INT NOT NULL CHECK (Capacity >= 1),
    DurationInDays INT NOT NULL CHECK (DurationInDays >= 1),

    TStatus VARCHAR(20) NOT NULL CHECK (TStatus IN ('Open To Register', 'Cancelled', 'Ongoing', 'Ended')) DEFAULT 'Open To Register',

    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
    OperatorID Varchar(10) NOT NULL,

    FOREIGN KEY (OperatorID) REFERENCES TourOperator(OperatorID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

Create Table ServiceProvider (
    ProviderID Varchar(10) PRIMARY KEY,
    
	SPName VARCHAR(100) NOT NULL,
    SPType VARCHAR(20) NOT NULL CHECK (
        SPType IN ('Hotel', 'Transport', 'Guide')
    ),
    
	Email VARCHAR(100) UNIQUE NOT NULL,
    SPPassword VARCHAR(255) NOT NULL,
    
	OnTimePerformance DECIMAL(5,2) CHECK (OnTimePerformance BETWEEN 0 AND 100),
    AverageRating DECIMAL(2,1) CHECK (AverageRating BETWEEN 1 AND 5),
    
	RegistrationDate DATETIME NOT NULL DEFAULT GETDATE(),
    LastLogin DATETIME NOT NULL DEFAULT GETDATE(),
    
	MaxCapacity INT CHECK (MaxCapacity >= 0),
    AvailableCapacity INT CHECK (AvailableCapacity >= 0),
	AccountStatus VARCHAR(10) CHECK (AccountStatus IN ('Active', 'Inactive')) NOT NULL DEFAULT 'Active'
);


CREATE TABLE Payment (
    PaymentID Varchar(10) PRIMARY KEY,

    AmountInDollars DECIMAL(10, 2) NOT NULL CHECK (AmountInDollars >= 0),
    PaymentDate DATETIME NOT NULL DEFAULT GETDATE(),
    
	PaymentMethod VARCHAR(30) NOT NULL CHECK (
        PaymentMethod IN ('Credit Card', 'Bank Transfer', 'Easypaisa', 'PayPal', 'Sadapay')
    ),

    PStatus VARCHAR(20) NOT NULL CHECK (
        PStatus IN ('Success', 'Failed', 'Lost', 'Chargedback')
    )
);


CREATE TABLE Booking (
    TravelerID Varchar(10) NOT NULL,
    TripID Varchar(10) NOT NULL,
	PRIMARY KEY(TravelerID, TripID),

    BookingDate DATE NOT NULL DEFAULT GETDATE(),

    BStatus VARCHAR(20) NOT NULL CHECK (
        BStatus IN ('Confirmed', 'Cancelled', 'Abandoned', 'Recovered')
    ),
    
	AbandonmentReason VARCHAR(255),
    
    FOREIGN KEY (TravelerID) REFERENCES Traveler(TravelerID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    FOREIGN KEY (TripID) REFERENCES Trip(TripID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

	PaymentID Varchar(10),
    FOREIGN KEY (PaymentID) REFERENCES Payment(PaymentID)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);



CREATE TABLE ServiceAssignment (
    TripID Varchar(10) NOT NULL,
    ProviderID Varchar(10) NOT NULL,

    Accepted BIT NOT NULL DEFAULT 0, -- 0 = Not accepted, 1 = Accepted

    PRIMARY KEY (TripID, ProviderID),

    FOREIGN KEY (TripID) REFERENCES Trip(TripID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    FOREIGN KEY (ProviderID) REFERENCES ServiceProvider(ProviderID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);



CREATE TABLE Review (
    ReviewID Varchar(10) PRIMARY KEY,

    TravelerID Varchar(10) NOT NULL,
    TripID Varchar(10),  
    ProviderID Varchar(10), 

    Rating INT NOT NULL CHECK (Rating BETWEEN 1 AND 5),
    Comment TEXT,
    ReviewDate DATETIME NOT NULL DEFAULT GETDATE(),

	IsFlagged BIT DEFAULT 0,

    FOREIGN KEY (TravelerID) REFERENCES Traveler(TravelerID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    FOREIGN KEY (TripID) REFERENCES Trip(TripID)
        ON DELETE SET NULL
        ON UPDATE CASCADE,

    FOREIGN KEY (ProviderID) REFERENCES ServiceProvider(ProviderID)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);


CREATE TABLE [Admin] (
    AdminID Varchar(10) PRIMARY KEY,

    Email VARCHAR(100) UNIQUE NOT NULL,
    APassword VARCHAR(255) NOT NULL,
    FullName VARCHAR(100),
    
    RegistrationDate DATETIME NOT NULL DEFAULT GETDATE(),
    LastLogin DATETIME NOT NULL DEFAULT GETDATE(),
	AccountStatus VARCHAR(10) CHECK (AccountStatus IN ('Active', 'Inactive')) NOT NULL DEFAULT 'Active'

);


CREATE TABLE SupportTicket (
    TicketID VARCHAR(10) PRIMARY KEY,

    TravelerID VARCHAR(10) NOT NULL,
    OperatorID VARCHAR(10) NOT NULL,
    
	STSubject VARCHAR(100),
    STMessage TEXT,

    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),

    RespondedAt DATETIME,
    ResponseMessage TEXT,
    
	STStatus VARCHAR(20) CHECK (STStatus IN ('Open', 'Pending', 'Closed')) NOT NULL DEFAULT 'Open',

    FOREIGN KEY (TravelerID) REFERENCES Traveler(TravelerID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,

    FOREIGN KEY (OperatorID) REFERENCES TourOperator(OperatorID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
);


CREATE TABLE Destination (
	TripID VARCHAR(10) NOT NULL,
	FOREIGN KEY (TripID) References Trip(TripID),

    DestinationID VARCHAR(10) NOT NULL,

	PRIMARY KEY(TripID, DestinationID),

    City VARCHAR(100) NOT NULL,
    Region VARCHAR(100),
    Country VARCHAR(100) NOT NULL,
    
	DDescription TEXT,
    AddedDate DATETIME NOT NULL DEFAULT GETDATE()
);

CREATE TABLE Wishlist (
    TravelerID VARCHAR (10) NOT NULL,
    TripID VARCHAR (10) NOT NULL,
    AddedDate DATETIME NOT NULL DEFAULT GETDATE(),

    PRIMARY KEY (TravelerID, TripID),

    FOREIGN KEY (TravelerID) REFERENCES Traveler(TravelerID)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (TripID) REFERENCES Trip(TripID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- STEP 4 and 5 Below




-- STEP 4: Before Running the following commands, change the absolute path of all files according to your system


/*
	STEP 5: BULK INSERTING INTO TABLES:
*/

BULK INSERT Traveler
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\Traveler.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);

BULK INSERT TourOperator
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\TourOperator.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);

BULK INSERT ServiceProvider
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\ServiceProvider.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);

BULK INSERT Trip
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\Trip.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);

BULK INSERT Preferences
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\Preferences.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);

BULK INSERT Booking
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\Booking.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    
    TABLOCK
);

BULK INSERT Payment
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\Payment.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    
    TABLOCK
);

BULK INSERT ServiceAssignment
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\ServiceAssignment.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    
    TABLOCK
);

BULK INSERT Review
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\Review.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);

BULK INSERT [Admin]
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\Admin.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    TABLOCK
);



BULK INSERT SupportTicket
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\SupportTicket.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    
    TABLOCK
);

BULK INSERT Destination
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\Destination.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',
    
    TABLOCK
);

BULK INSERT Wishlist
FROM 'C:\Users\Fatik\Desktop\CSVs (Datasets)\Wishlist.csv'
WITH (
    FIRSTROW = 2,
    FIELDTERMINATOR = ',',  
    ROWTERMINATOR = '\n',    
    TABLOCK
);


/*
	STEP 6: CREATE PROCEDURES (one-by-one):
*/

-- Procedure to get reviews with filtering
GO
CREATE PROCEDURE sp_GetReviewsForModeration
    @FilterType VARCHAR(50) = 'All'
AS
BEGIN
    IF @FilterType = 'Flagged'
        SELECT r.ReviewID, r.TravelerID, tr.FullName as TravelerName,
               r.TripID, t.Title as TripTitle,
               r.ProviderID, p.SPName as ProviderName,
               r.Rating, r.Comment, r.ReviewDate, r.IsFlagged
        FROM Review r
        LEFT JOIN Trip t ON r.TripID = t.TripID
        LEFT JOIN ServiceProvider p ON r.ProviderID = p.ProviderID
        LEFT JOIN Traveler tr ON r.TravelerID = tr.TravelerID
        WHERE r.IsFlagged = 1
    ELSE IF @FilterType = 'LowRatings'
        SELECT r.ReviewID, r.TravelerID, tr.FullName as TravelerName,
               r.TripID, t.Title as TripTitle,
               r.ProviderID, p.SPName as ProviderName,
               r.Rating, r.Comment, r.ReviewDate, r.IsFlagged
        FROM Review r
        LEFT JOIN Trip t ON r.TripID = t.TripID
        LEFT JOIN ServiceProvider p ON r.ProviderID = p.ProviderID
        LEFT JOIN Traveler tr ON r.TravelerID = tr.TravelerID
        WHERE r.Rating <= 2
    ELSE
        SELECT r.ReviewID, r.TravelerID, tr.FullName as TravelerName,
               r.TripID, t.Title as TripTitle,
               r.ProviderID, p.SPName as ProviderName,
               r.Rating, r.Comment, r.ReviewDate, r.IsFlagged
        FROM Review r
        LEFT JOIN Trip t ON r.TripID = t.TripID
        LEFT JOIN ServiceProvider p ON r.ProviderID = p.ProviderID
        LEFT JOIN Traveler tr ON r.TravelerID = tr.TravelerID
    ORDER BY r.ReviewDate DESC;
END;


GO
-- Procedure to flag/unflag a review
CREATE PROCEDURE sp_FlagReview
    @ReviewID VARCHAR(10),
    @IsFlagged BIT
AS
BEGIN
    UPDATE Review SET IsFlagged = @IsFlagged WHERE ReviewID = @ReviewID;
END;


GO
-- Procedure to delete a review
CREATE PROCEDURE sp_DeleteReview
    @ReviewID VARCHAR(10)
AS
BEGIN
    DELETE FROM Review WHERE ReviewID = @ReviewID;
END;







-- TESTING:
SELECT Trip.TripID, Title, Country, City FROM Trip JOIN Destination ON Trip.TripID = Destination.TripID

SELECT * FROM Admin
SELECT * FROM TourOperator
SELECT * FROM ServiceProvider
SELECT * FROM Traveler

SELECT * FROM Trip t Where t.OperatorID = 'TO001'
SELECT * FROM Trip t JOIN Booking b ON t.TripID = b.TripID WHERE b.TravelerID = 'TR002'

SELECT * FROM Booking
SELECT * FROM Review WHERE Review.IsFlagged = 1

SELECT * FROM Review