﻿using System;
using System.Data;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmAddEditTrip : Form
    {
        private readonly string _operatorId;
        private readonly string _tripId;
        private bool _isEditMode;
        private const int MAX_CAPACITY = 200; // Maximum allowed capacity

        public frmAddEditTrip(string operatorId, string tripId = null)
        {
            InitializeComponent();
            _operatorId = operatorId;
            _tripId = tripId;
            _isEditMode = !string.IsNullOrEmpty(tripId);
        }

        private void frmAddEditTrip_Load(object sender, EventArgs e)
        {
            // Set focus to first field
            this.ActiveControl = txtTitle;

            // Load trip types from enum or database
            cboTripType.Items.AddRange(new object[] {
                "Adventure", "Cultural", "Leisure",
                "Historical", "Luxury", "Group"
            });

            if (_isEditMode)
            {
                this.Text = "Edit Trip";
                LoadTripData();
            }
            else
            {
                this.Text = "Add New Trip";
                dtpStartDate.MinDate = DateTime.Today;
                dtpEndDate.MinDate = DateTime.Today.AddDays(1);
            }
        }

        private void LoadTripData()
        {
            string query = $"SELECT * FROM Trip WHERE TripID = '{_tripId}'";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);

            if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];
                txtTitle.Text = row["Title"].ToString();
                txtDescription.Text = row["TDescription"].ToString();
                dtpStartDate.Value = Convert.ToDateTime(row["StartDate"]);
                dtpEndDate.Value = Convert.ToDateTime(row["EndDate"]);
                txtPrice.Text = Convert.ToDecimal(row["PricePerPersonInDollars"]).ToString("0.00");
                cboTripType.SelectedItem = row["TripType"].ToString();
                txtCapacity.Text = row["Capacity"].ToString();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateForm())
                return;

            try
            {
                string title = txtTitle.Text.Trim();
                string description = txtDescription.Text.Trim();
                DateTime startDate = dtpStartDate.Value;
                DateTime endDate = dtpEndDate.Value;
                decimal price = decimal.Parse(txtPrice.Text);
                string tripType = cboTripType.SelectedItem.ToString();
                int capacity = int.Parse(txtCapacity.Text);
                int duration = (endDate - startDate).Days;

                if (_isEditMode)
                {
                    // Update existing trip
                    string query = $@"UPDATE Trip SET 
                                    Title = '{title}',
                                    TDescription = '{description}',
                                    StartDate = '{startDate:yyyy-MM-dd}',
                                    EndDate = '{endDate:yyyy-MM-dd}',
                                    PricePerPersonInDollars = {price},
                                    TripType = '{tripType}',
                                    Capacity = {capacity},
                                    DurationInDays = {duration}
                                    WHERE TripID = '{_tripId}'";

                    DatabaseHelper.ExecuteNonQuery(query);
                    MessageBox.Show("Trip updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    // Create new trip
                    string newTripId = GenerateNewTripId();
                    string query = $@"INSERT INTO Trip (TripID, Title, TDescription, StartDate, EndDate, 
                                    PricePerPersonInDollars, TripType, Capacity, DurationInDays, TStatus, OperatorID)
                                    VALUES ('{newTripId}', '{title}', '{description}', '{startDate:yyyy-MM-dd}', 
                                    '{endDate:yyyy-MM-dd}', {price}, '{tripType}', {capacity}, {duration}, 
                                    'Open To Register', '{_operatorId}')";

                    DatabaseHelper.ExecuteNonQuery(query);
                    MessageBox.Show("Trip created successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving trip: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateForm()
        {
            // Title validation
            if (string.IsNullOrWhiteSpace(txtTitle.Text))
            {
                MessageBox.Show("Please enter a title for the trip.", "Validation Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTitle.Focus();
                return false;
            }

            // Date validation
            if (dtpStartDate.Value >= dtpEndDate.Value)
            {
                MessageBox.Show("End date must be after start date.", "Validation Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dtpEndDate.Focus();
                return false;
            }

            // Price validation
            if (!decimal.TryParse(txtPrice.Text, out decimal price) || price <= 0)
            {
                MessageBox.Show("Please enter a valid positive price.", "Validation Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPrice.SelectAll();
                txtPrice.Focus();
                return false;
            }

            // Trip type validation
            if (cboTripType.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a trip type.", "Validation Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboTripType.Focus();
                return false;
            }

            // Capacity validation
            if (!int.TryParse(txtCapacity.Text, out int capacity) || capacity <= 0)
            {
                MessageBox.Show("Please enter a valid positive capacity.", "Validation Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCapacity.SelectAll();
                txtCapacity.Focus();
                return false;
            }
            else if (capacity > MAX_CAPACITY)
            {
                MessageBox.Show($"Capacity cannot exceed {MAX_CAPACITY}.", "Validation Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtCapacity.SelectAll();
                txtCapacity.Focus();
                return false;
            }

            return true;
        }

        private string GenerateNewTripId()
        {
            // Get the highest existing TripID and increment it
            string query = "SELECT MAX(TripID) FROM Trip";
            string maxId = DatabaseHelper.ExecuteScalar(query).ToString();

            if (string.IsNullOrEmpty(maxId))
                return "TP001";

            int num = int.Parse(maxId.Substring(2)) + 1;
            return $"TP{num:D3}";
        }

        private void dtpStartDate_ValueChanged(object sender, EventArgs e)
        {
            dtpEndDate.MinDate = dtpStartDate.Value.AddDays(1);
        }

        private void txtCapacity_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Only allow digits and control characters
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Only allow digits, decimal point, and control characters
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
            }

            // Only allow one decimal point
            if (e.KeyChar == '.' && ((TextBox)sender).Text.IndexOf('.') > -1)
            {
                e.Handled = true;
            }
        }

        private void txtPrice_Leave(object sender, EventArgs e)
        {
            // Format the price when leaving the field
            if (decimal.TryParse(txtPrice.Text, out decimal price))
            {
                txtPrice.Text = price.ToString("0.00");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}