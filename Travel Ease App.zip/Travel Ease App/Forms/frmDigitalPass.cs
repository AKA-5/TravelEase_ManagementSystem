﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmDigitalPass : Form
    {
        private readonly string _travelerId;
        private readonly string _tripId;

        public frmDigitalPass(string travelerId, string tripId)
        {
            _travelerId = travelerId;
            _tripId = tripId;
            InitializeComponent();
            this.Text = "Digital Travel Pass";
            LoadPassDetails();
        }

        private void LoadPassDetails()
        {
            try
            {
                // Fetch booking and trip details
                string query = @"
                    SELECT b.TravelerID, b.TripID, t.Title, d.City, d.Country, 
                           t.StartDate, t.EndDate, b.BookingDate, b.BStatus, 
                           t.PricePerPersonInDollars
                    FROM Booking b
                    JOIN Trip t ON b.TripID = t.TripID
                    JOIN Destination d ON t.TripID = d.TripID
                    WHERE b.TravelerID = @TravelerID AND b.TripID = @TripID
                    AND (b.BStatus = 'Confirmed' OR b.BStatus = 'Recovered')";
                var parameters = new Dictionary<string, object>
                {
                    { "@TravelerID", _travelerId },
                    { "@TripID", _tripId }
                };
                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("No valid booking found for this trip.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                    return;
                }

                var row = dt.Rows[0];
                lblTravelerID.Text = $"Traveler ID: {row["TravelerID"]}";
                lblTripID.Text = $"Trip ID: {row["TripID"]}";
                lblTitle.Text = $"Trip: {row["Title"]}";
                lblDestination.Text = $"Destination: {row["City"]}, {row["Country"]}";
                lblStartDate.Text = $"Start Date: {Convert.ToDateTime(row["StartDate"]).ToShortDateString()}";
                lblEndDate.Text = $"End Date: {Convert.ToDateTime(row["EndDate"]).ToShortDateString()}";
                lblBookingDate.Text = $"Booking Date: {Convert.ToDateTime(row["BookingDate"]).ToShortDateString()}";
                lblStatus.Text = $"Status: {row["BStatus"]}";
                lblPrice.Text = $"Price: {Convert.ToDecimal(row["PricePerPersonInDollars"]):C2}";

                // Fetch voucher details
                query = @"
                    SELECT v.VoucherCode, v.DiscountAmount
                    FROM Voucher v
                    JOIN Booking b ON v.VoucherID = b.VoucherID AND v.TravelerID = b.TravelerID
                    WHERE b.TravelerID = @TravelerID AND b.TripID = @TripID";
                dt = DatabaseHelper.ExecuteQuery(query, parameters);

                if (dt.Rows.Count > 0)
                {
                    lblVoucher.Text = $"Voucher: {dt.Rows[0]["VoucherCode"]} (Discount: {Convert.ToDecimal(dt.Rows[0]["DiscountAmount"]):C2})";
                }
                else
                {
                    lblVoucher.Text = "Voucher: None";
                }

                // Fetch service assignments
                query = @"
                    SELECT s.SType, sa.SAStatus
                    FROM Service s
                    JOIN ServiceAssignment sa ON s.ServiceID = sa.ServiceID
                    WHERE sa.TripID = @TripID";
                dt = DatabaseHelper.ExecuteQuery(query, parameters);

                dgvServices.DataSource = dt;
                if (dgvServices.Columns.Count > 0)
                {                    
                    dgvServices.Columns["SType"].HeaderText = "Service Type";
                    dgvServices.Columns["SAStatus"].HeaderText = "Status";
                    dgvServices.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading digital pass: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmDigitalPass_Load(object sender, EventArgs e)
        {

        }
    }
}