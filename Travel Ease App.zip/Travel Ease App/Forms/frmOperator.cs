﻿using System;
using System.Data;
using System.Windows.Forms;
using Travel_Ease_App.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace Travel_Ease_App.Forms
{
    public partial class frmOperator : Form
    {
        private readonly string _operatorId;

        public frmOperator(string operatorId)
        {
            _operatorId = operatorId;
            InitializeComponent();
        }

        private void frmOperator_Load(object sender, EventArgs e)
        {
            this.Text = $"Tour Operator Dashboard - ID: {_operatorId}";
            LoadTrips();
            LoadBookings();
            LoadServiceAssignments();
            LoadAnalytics();

            // Initialize booking status dropdown
            cboBookingStatus.Items.AddRange(new[] { "Confirmed", "Cancelled" });
            cboBookingStatus.SelectedIndex = -1;

            // Wire up event handlers
            btnAddTrip.Click += BtnAddTrip_Click;
            btnEditTrip.Click += BtnEditTrip_Click;
            btnDeleteTrip.Click += BtnDeleteTrip_Click;
            btnAssignService.Click += BtnAssignService_Click;
            btnDeleteService.Click += BtnDeleteService_Click;
            btnRefreshServices.Click += BtnRefreshServices_Click;
            btnUpdateStatus.Click += BtnUpdateStatus_Click;
            btnViewReports.Click += (s, ev) =>
            {
                var reportsForm = new frmReports();
                reportsForm.ShowDialog();
            };
        }
        private void LoadTrips()
        {
            string query = $"SELECT * FROM Trip WHERE OperatorID = '{_operatorId}'";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);

            foreach (DataRow row in dt.Rows)
            {
                string tripId = row["TripID"].ToString();
                DateTime startDate = Convert.ToDateTime(row["StartDate"]);
                DateTime endDate = Convert.ToDateTime(row["EndDate"]);
                string currentStatus = row["TStatus"].ToString();

                if (currentStatus == "Cancelled")
                    continue;

                string newStatus = startDate > DateTime.Today ? "Open To Register" :
                                 endDate < DateTime.Today ? "Ended" : "Ongoing";

                if (newStatus != currentStatus)
                {
                    string updateQuery = $@"UPDATE Trip SET TStatus = '{newStatus}' WHERE TripID = '{tripId}'";
                    DatabaseHelper.ExecuteNonQuery(updateQuery);
                }
            }

            dt = DatabaseHelper.ExecuteQuery(query);
            dgvTrips.DataSource = dt;

            if (dgvTrips.Columns.Contains("PricePerPersonInDollars"))
            {
                dgvTrips.Columns["PricePerPersonInDollars"].DefaultCellStyle.Format = "N2";
            }
        }

        private void LoadBookings()
        {
            string query = $@"SELECT b.TripID, t.Title, b.TravelerID, tr.FullName, b.BookingDate, 
                            b.BStatus, p.AmountInDollars, b.PaymentID
                            FROM Booking b
                            JOIN Trip t ON b.TripID = t.TripID
                            JOIN Traveler tr ON b.TravelerID = tr.TravelerID
                            LEFT JOIN Payment p ON b.PaymentID = p.PaymentID
                            WHERE t.OperatorID = '{_operatorId}'";

            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            dgvBookings.DataSource = dt;

            if (dgvBookings.Columns.Contains("AmountInDollars"))
            {
                dgvBookings.Columns["AmountInDollars"].DefaultCellStyle.Format = "N2";
            }
        }

        private void LoadServiceAssignments()
        {
            string query = $@"SELECT sa.TripID, t.Title, sa.ServiceID, s.SType, 
                             sp.SPName as ProviderName, sa.SAStatus
                             FROM ServiceAssignment sa
                             JOIN Trip t ON sa.TripID = t.TripID
                             JOIN Service s ON sa.ServiceID = s.ServiceID AND sa.ProviderID = s.ProviderID
                             JOIN ServiceProvider sp ON sa.ProviderID = sp.ProviderID
                             WHERE t.OperatorID = '{_operatorId}'";

            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            dgvServices.DataSource = dt;
        }

        private void LoadAnalytics()
        {
            string bookingsQuery = $@"SELECT COUNT(*) FROM Booking b JOIN Trip t ON b.TripID = t.TripID WHERE t.OperatorID = '{_operatorId}'";
            int totalBookings = Convert.ToInt32(DatabaseHelper.ExecuteScalar(bookingsQuery));
            lblTotalBookings.Text = $"Total Bookings: {totalBookings}";

            string revenueQuery = $@"SELECT ISNULL(SUM(p.AmountInDollars), 0) FROM Booking b
                                   JOIN Trip t ON b.TripID = t.TripID
                                   JOIN Payment p ON b.PaymentID = p.PaymentID
                                   WHERE t.OperatorID = '{_operatorId}' AND p.PStatus = 'Success'";
            decimal totalRevenue = Convert.ToDecimal(DatabaseHelper.ExecuteScalar(revenueQuery));
            lblTotalRevenue.Text = $"Total Revenue: {totalRevenue:N2}";

            string ratingQuery = $@"SELECT ISNULL(AVG(CAST(r.Rating AS DECIMAL(3,1))), 0.0)
                                  FROM Review r JOIN Trip t ON r.TripID = t.TripID
                                  WHERE t.OperatorID = '{_operatorId}'";
            try
            {
                object result = DatabaseHelper.ExecuteScalar(ratingQuery);
                decimal avgRating = Convert.ToDecimal(result);
                lblAvgRating.Text = $"Avg Rating: {avgRating:F1}";
            }
            catch (Exception ex)
            {
                lblAvgRating.Text = "Avg Rating: N/A";
                Console.WriteLine($"Error calculating average rating: {ex.Message}");
            }

            string reviewsQuery = $@"SELECT r.TripID, t.Title, r.TravelerID, tr.FullName, 
                                   r.Rating, r.Comment, r.ReviewDate
                                   FROM Review r
                                   JOIN Trip t ON r.TripID = t.TripID
                                   JOIN Traveler tr ON r.TravelerID = tr.TravelerID
                                   WHERE t.OperatorID = '{_operatorId}'";
            DataTable dt = DatabaseHelper.ExecuteQuery(reviewsQuery);
            dgvReviews.DataSource = dt;
        }

        private void BtnAddTrip_Click(object sender, EventArgs e)
        {
            frmAddEditTrip addForm = new frmAddEditTrip(_operatorId);
            addForm.ShowDialog();
            LoadTrips();
        }

        private void BtnEditTrip_Click(object sender, EventArgs e)
        {
            if (dgvTrips.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a trip to edit.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string tripId = dgvTrips.SelectedRows[0].Cells["TripID"].Value.ToString();
            frmAddEditTrip editForm = new frmAddEditTrip(_operatorId, tripId);
            editForm.ShowDialog();
            LoadTrips();
        }

        private void BtnDeleteTrip_Click(object sender, EventArgs e)
        {
            if (dgvTrips.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a trip to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string tripId = dgvTrips.SelectedRows[0].Cells["TripID"].Value.ToString();
            string tripTitle = dgvTrips.SelectedRows[0].Cells["Title"].Value.ToString();

            if (MessageBox.Show($"Are you sure you want to delete the trip '{tripTitle}'?",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string deleteAssignments = $"DELETE FROM ServiceAssignment WHERE TripID = '{tripId}'";
                    DatabaseHelper.ExecuteNonQuery(deleteAssignments);

                    string deleteBookings = $"DELETE FROM Booking WHERE TripID = '{tripId}'";
                    DatabaseHelper.ExecuteNonQuery(deleteBookings);

                    string deleteReviews = $"DELETE FROM Review WHERE TripID = '{tripId}'";
                    DatabaseHelper.ExecuteNonQuery(deleteReviews);

                    string deleteTrip = $"DELETE FROM Trip WHERE TripID = '{tripId}'";
                    int rowsAffected = DatabaseHelper.ExecuteNonQuery(deleteTrip);

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Trip deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadTrips();
                        LoadServiceAssignments();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting trip: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void BtnAssignService_Click(object sender, EventArgs e)
        {
            frmAssignServices assignForm = new frmAssignServices(_operatorId);
            assignForm.ShowDialog();
            LoadServiceAssignments();
        }

        private void BtnDeleteService_Click(object sender, EventArgs e)
        {
            if (dgvServices.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a service assignment to delete.", "No Selection",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string tripId = dgvServices.SelectedRows[0].Cells["TripID"].Value.ToString();
            string serviceId = dgvServices.SelectedRows[0].Cells["ServiceID"].Value.ToString();
            string serviceType = dgvServices.SelectedRows[0].Cells["SType"].Value.ToString();
            string providerName = dgvServices.SelectedRows[0].Cells["ProviderName"].Value.ToString();

            if (MessageBox.Show(
                $"Are you sure you want to delete the '{serviceType}' assignment for '{providerName}' from this trip?",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    string deleteQuery = $"DELETE FROM ServiceAssignment WHERE TripID = '{tripId}' AND ServiceID = '{serviceId}'";
                    int rowsAffected = DatabaseHelper.ExecuteNonQuery(deleteQuery);

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Service assignment deleted successfully.", "Success",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadServiceAssignments();
                    }
                    else
                    {
                        MessageBox.Show("No assignment was deleted. It may have already been removed.", "Warning",
                            MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting service assignment: {ex.Message}", "Error",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void BtnUpdateStatus_Click(object sender, EventArgs e)
        {
            if (dgvBookings.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a booking to update.", "No Selection",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cboBookingStatus.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a new status.", "No Status Selected",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DataGridViewRow row = dgvBookings.SelectedRows[0];
            string tripId = row.Cells["TripID"].Value.ToString();
            string travelerId = row.Cells["TravelerID"].Value.ToString();
            string currentStatus = row.Cells["BStatus"].Value.ToString();
            string newStatus = cboBookingStatus.SelectedItem.ToString();
            string paymentId = row.Cells["PaymentID"].Value == DBNull.Value ? null :
                              row.Cells["PaymentID"].Value.ToString();

            try
            {
                using (var connection = DatabaseHelper.GetConnection())
                {
                    connection.Open();
                    using (var transaction = connection.BeginTransaction())
                    {
                        try
                        {
                            // Handle payment status changes if payment exists
                            if (!string.IsNullOrEmpty(paymentId))
                            {
                                if (currentStatus == "Confirmed" && newStatus == "Cancelled")
                                {
                                    // For confirmed -> cancelled: set payment to chargedback
                                    UpdatePaymentStatus(connection, transaction, paymentId, "Chargedback");
                                }
                                else if (currentStatus == "Cancelled" && newStatus == "Confirmed")
                                {
                                    // For cancelled -> confirmed: if was chargedback, set to pending
                                    string currentPaymentStatus = GetPaymentStatus(connection, transaction, paymentId);
                                    if (currentPaymentStatus == "Chargedback")
                                    {
                                        UpdatePaymentStatus(connection, transaction, paymentId, "Pending");
                                    }
                                }
                            }

                            // Update booking status
                            string updateQuery = @"UPDATE Booking 
                                        SET BStatus = @NewStatus
                                        WHERE TripID = @TripID AND TravelerID = @TravelerID";

                            using (var cmd = new SqlCommand(updateQuery, connection, transaction))
                            {
                                cmd.Parameters.AddWithValue("@NewStatus", newStatus);
                                cmd.Parameters.AddWithValue("@TripID", tripId);
                                cmd.Parameters.AddWithValue("@TravelerID", travelerId);

                                if (cmd.ExecuteNonQuery() == 0)
                                {
                                    MessageBox.Show("Booking no longer exists.", "Warning",
                                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                    return;
                                }
                            }

                            transaction.Commit();
                            MessageBox.Show($"Booking status updated to {newStatus}.", "Success",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadBookings();
                            cboBookingStatus.SelectedIndex = -1;
                        }
                        catch (Exception ex)
                        {
                            transaction.Rollback();
                            MessageBox.Show($"Error updating booking: {ex.Message}", "Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Database error: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string GetPaymentStatus(SqlConnection connection, SqlTransaction transaction, string paymentId)
        {
            string query = "SELECT PStatus FROM Payment WHERE PaymentID = @PaymentID";
            using (var cmd = new SqlCommand(query, connection, transaction))
            {
                cmd.Parameters.AddWithValue("@PaymentID", paymentId);
                return cmd.ExecuteScalar()?.ToString();
            }
        }

        private void UpdatePaymentStatus(SqlConnection connection, SqlTransaction transaction,
                                        string paymentId, string newStatus)
        {
            string query = "UPDATE Payment SET PStatus = @Status WHERE PaymentID = @PaymentID";
            using (var cmd = new SqlCommand(query, connection, transaction))
            {
                cmd.Parameters.AddWithValue("@Status", newStatus);
                cmd.Parameters.AddWithValue("@PaymentID", paymentId);
                cmd.ExecuteNonQuery();
            }
        }

        private void BtnRefreshServices_Click(object sender, EventArgs e)
        {
            LoadServiceAssignments();
        }

        private void dgvServices_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string tripId = dgvServices.Rows[e.RowIndex].Cells["TripID"].Value.ToString();
                string serviceId = dgvServices.Rows[e.RowIndex].Cells["ServiceID"].Value.ToString();

                frmManageServiceAssignment manageForm = new frmManageServiceAssignment(tripId, serviceId);
                manageForm.ShowDialog();
                LoadServiceAssignments();
            }
        }

        private void dgvTrips_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}