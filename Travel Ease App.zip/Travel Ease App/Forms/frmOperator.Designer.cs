﻿using System.Windows.Forms;

namespace Travel_Ease_App.Forms
{
    partial class frmOperator
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabTrips = new System.Windows.Forms.TabPage();
            this.dgvTrips = new System.Windows.Forms.DataGridView();
            this.btnAddTrip = new System.Windows.Forms.Button();
            this.btnEditTrip = new System.Windows.Forms.Button();
            this.btnDeleteTrip = new System.Windows.Forms.Button();
            this.tabBookings = new System.Windows.Forms.TabPage();
            this.dgvBookings = new System.Windows.Forms.DataGridView();
            this.cboBookingStatus = new System.Windows.Forms.ComboBox(); // New dropdown
            this.btnUpdateStatus = new System.Windows.Forms.Button(); // New button
            this.tabServices = new System.Windows.Forms.TabPage();
            this.dgvServices = new System.Windows.Forms.DataGridView();
            this.btnAssignService = new System.Windows.Forms.Button();
            this.btnDeleteService = new System.Windows.Forms.Button();
            this.btnRefreshServices = new System.Windows.Forms.Button();
            this.tabAnalytics = new System.Windows.Forms.TabPage();
            this.dgvReviews = new System.Windows.Forms.DataGridView();
            this.lblAvgRating = new System.Windows.Forms.Label();
            this.lblTotalRevenue = new System.Windows.Forms.Label();
            this.lblTotalBookings = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabTrips.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTrips)).BeginInit();
            this.tabBookings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBookings)).BeginInit();
            this.tabServices.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvServices)).BeginInit();
            this.tabAnalytics.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReviews)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabTrips);
            this.tabControl1.Controls.Add(this.tabBookings);
            this.tabControl1.Controls.Add(this.tabServices);
            this.tabControl1.Controls.Add(this.tabAnalytics);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1143, 640);
            this.tabControl1.TabIndex = 0;
            // 
            // tabTrips
            // 
            this.tabTrips.Controls.Add(this.dgvTrips);
            this.tabTrips.Controls.Add(this.btnAddTrip);
            this.tabTrips.Controls.Add(this.btnEditTrip);
            this.tabTrips.Controls.Add(this.btnDeleteTrip);
            this.tabTrips.Location = new System.Drawing.Point(4, 25);
            this.tabTrips.Name = "tabTrips";
            this.tabTrips.Padding = new System.Windows.Forms.Padding(3);
            this.tabTrips.Size = new System.Drawing.Size(1135, 611);
            this.tabTrips.TabIndex = 0;
            this.tabTrips.Text = "My Trips";
            this.tabTrips.UseVisualStyleBackColor = true;
            // 
            // dgvTrips
            // 
            this.dgvTrips.AllowUserToAddRows = false;
            this.dgvTrips.AllowUserToDeleteRows = false;
            this.dgvTrips.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTrips.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTrips.Location = new System.Drawing.Point(7, 53);
            this.dgvTrips.Name = "dgvTrips";
            this.dgvTrips.ReadOnly = true;
            this.dgvTrips.RowHeadersWidth = 51;
            this.dgvTrips.RowTemplate.Height = 25;
            this.dgvTrips.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTrips.Size = new System.Drawing.Size(1120, 550);
            this.dgvTrips.TabIndex = 0;
            this.dgvTrips.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTrips_CellContentClick);
            // 
            // btnAddTrip
            // 
            this.btnAddTrip.Location = new System.Drawing.Point(7, 6);
            this.btnAddTrip.Name = "btnAddTrip";
            this.btnAddTrip.Size = new System.Drawing.Size(120, 40);
            this.btnAddTrip.TabIndex = 1;
            this.btnAddTrip.Text = "Add Trip";
            this.btnAddTrip.UseVisualStyleBackColor = true;
            // 
            // btnEditTrip
            // 
            this.btnEditTrip.Location = new System.Drawing.Point(140, 6);
            this.btnEditTrip.Name = "btnEditTrip";
            this.btnEditTrip.Size = new System.Drawing.Size(120, 40);
            this.btnEditTrip.TabIndex = 2;
            this.btnEditTrip.Text = "Edit Trip";
            this.btnEditTrip.UseVisualStyleBackColor = true;
            // 
            // btnDeleteTrip
            // 
            this.btnDeleteTrip.Location = new System.Drawing.Point(270, 6);
            this.btnDeleteTrip.Name = "btnDeleteTrip";
            this.btnDeleteTrip.Size = new System.Drawing.Size(120, 40);
            this.btnDeleteTrip.TabIndex = 3;
            this.btnDeleteTrip.Text = "Delete Trip";
            this.btnDeleteTrip.UseVisualStyleBackColor = true;
            // 
            // tabBookings
            // 
            this.tabBookings.Controls.Add(this.cboBookingStatus);
            this.tabBookings.Controls.Add(this.btnUpdateStatus);
            this.tabBookings.Controls.Add(this.dgvBookings);
            this.tabBookings.Location = new System.Drawing.Point(4, 25);
            this.tabBookings.Name = "tabBookings";
            this.tabBookings.Padding = new System.Windows.Forms.Padding(3);
            this.tabBookings.Size = new System.Drawing.Size(1135, 611);
            this.tabBookings.TabIndex = 1;
            this.tabBookings.Text = "Bookings";
            this.tabBookings.UseVisualStyleBackColor = true;
            // 
            // dgvBookings
            // 
            this.dgvBookings.AllowUserToAddRows = false;
            this.dgvBookings.AllowUserToDeleteRows = false;
            this.dgvBookings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBookings.Location = new System.Drawing.Point(3, 60);
            this.dgvBookings.Name = "dgvBookings";
            this.dgvBookings.ReadOnly = true;
            this.dgvBookings.RowHeadersWidth = 51;
            this.dgvBookings.RowTemplate.Height = 25;
            this.dgvBookings.Size = new System.Drawing.Size(1129, 548);
            this.dgvBookings.TabIndex = 0;
            // 
            // cboBookingStatus
            // 
            this.cboBookingStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboBookingStatus.Location = new System.Drawing.Point(10, 10);
            this.cboBookingStatus.Name = "cboBookingStatus";
            this.cboBookingStatus.Size = new System.Drawing.Size(120, 40);
            this.cboBookingStatus.TabIndex = 1;
            // 
            // btnUpdateStatus
            // 
            this.btnUpdateStatus.Location = new System.Drawing.Point(140, 10);
            this.btnUpdateStatus.Name = "btnUpdateStatus";
            this.btnUpdateStatus.Size = new System.Drawing.Size(120, 40);
            this.btnUpdateStatus.TabIndex = 2;
            this.btnUpdateStatus.Text = "Update Status";
            this.btnUpdateStatus.UseVisualStyleBackColor = true;
            this.btnUpdateStatus.Click += new System.EventHandler(this.BtnUpdateStatus_Click);
            // 
            // tabServices
            // 
            this.tabServices.Controls.Add(this.btnAssignService);
            this.tabServices.Controls.Add(this.btnDeleteService);
            this.tabServices.Controls.Add(this.btnRefreshServices);
            this.tabServices.Controls.Add(this.dgvServices);
            this.tabServices.Location = new System.Drawing.Point(4, 25);
            this.tabServices.Name = "tabServices";
            this.tabServices.Size = new System.Drawing.Size(1135, 611);
            this.tabServices.TabIndex = 2;
            this.tabServices.Text = "Service Assignments";
            this.tabServices.UseVisualStyleBackColor = true;
            // 
            // dgvServices
            // 
            this.dgvServices.AllowUserToAddRows = false;
            this.dgvServices.AllowUserToDeleteRows = false;
            this.dgvServices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvServices.Location = new System.Drawing.Point(0, 60);
            this.dgvServices.Name = "dgvServices";
            this.dgvServices.ReadOnly = true;
            this.dgvServices.RowHeadersWidth = 51;
            this.dgvServices.RowTemplate.Height = 25;
            this.dgvServices.Size = new System.Drawing.Size(1135, 551);
            this.dgvServices.TabIndex = 0;
            this.dgvServices.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvServices_CellDoubleClick);
            // 
            // btnAssignService
            // 
            this.btnAssignService.Location = new System.Drawing.Point(10, 10);
            this.btnAssignService.Name = "btnAssignService";
            this.btnAssignService.Size = new System.Drawing.Size(120, 40);
            this.btnAssignService.TabIndex = 1;
            this.btnAssignService.Text = "Assign Service";
            this.btnAssignService.UseVisualStyleBackColor = true;
            this.btnAssignService.Click += new System.EventHandler(this.BtnAssignService_Click);
            // 
            // btnDeleteService
            // 
            this.btnDeleteService.Location = new System.Drawing.Point(140, 10);
            this.btnDeleteService.Name = "btnDeleteService";
            this.btnDeleteService.Size = new System.Drawing.Size(120, 40);
            this.btnDeleteService.TabIndex = 2;
            this.btnDeleteService.Text = "Delete Service";
            this.btnDeleteService.UseVisualStyleBackColor = true;
            this.btnDeleteService.Click += new System.EventHandler(this.BtnDeleteService_Click);
            // 
            // btnRefreshServices
            // 
            this.btnRefreshServices.Location = new System.Drawing.Point(270, 10);
            this.btnRefreshServices.Name = "btnRefreshServices";
            this.btnRefreshServices.Size = new System.Drawing.Size(120, 40);
            this.btnRefreshServices.TabIndex = 3;
            this.btnRefreshServices.Text = "Refresh";
            this.btnRefreshServices.UseVisualStyleBackColor = true;
            this.btnRefreshServices.Click += new System.EventHandler(this.BtnRefreshServices_Click);
            // 
            // tabAnalytics
            // 
            this.tabAnalytics.Controls.Add(this.dgvReviews);
            this.tabAnalytics.Controls.Add(this.lblAvgRating);
            this.tabAnalytics.Controls.Add(this.lblTotalRevenue);
            this.tabAnalytics.Controls.Add(this.lblTotalBookings);
            this.tabAnalytics.Location = new System.Drawing.Point(4, 25);
            this.tabAnalytics.Name = "tabAnalytics";
            this.tabAnalytics.Size = new System.Drawing.Size(1135, 611);
            this.tabAnalytics.TabIndex = 3;
            this.tabAnalytics.Text = "Performance Analytics";
            this.tabAnalytics.UseVisualStyleBackColor = true;
            // 
            // dgvReviews
            // 
            this.dgvReviews.AllowUserToAddRows = false;
            this.dgvReviews.AllowUserToDeleteRows = false;
            this.dgvReviews.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvReviews.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvReviews.Location = new System.Drawing.Point(23, 149);
            this.dgvReviews.Name = "dgvReviews";
            this.dgvReviews.ReadOnly = true;
            this.dgvReviews.RowHeadersWidth = 51;
            this.dgvReviews.RowTemplate.Height = 25;
            this.dgvReviews.Size = new System.Drawing.Size(1086, 448);
            this.dgvReviews.TabIndex = 3;
            // 
            // lblAvgRating
            // 
            this.lblAvgRating.AutoSize = true;
            this.lblAvgRating.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblAvgRating.Location = new System.Drawing.Point(23, 107);
            this.lblAvgRating.Name = "lblAvgRating";
            this.lblAvgRating.Size = new System.Drawing.Size(122, 28);
            this.lblAvgRating.TabIndex = 2;
            this.lblAvgRating.Text = "Avg Rating:";
            // 
            // lblTotalRevenue
            // 
            this.lblTotalRevenue.AutoSize = true;
            this.lblTotalRevenue.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTotalRevenue.Location = new System.Drawing.Point(23, 64);
            this.lblTotalRevenue.Name = "lblTotalRevenue";
            this.lblTotalRevenue.Size = new System.Drawing.Size(151, 28);
            this.lblTotalRevenue.TabIndex = 1;
            this.lblTotalRevenue.Text = "Total Revenue:";
            // 
            // lblTotalBookings
            // 
            this.lblTotalBookings.AutoSize = true;
            this.lblTotalBookings.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblTotalBookings.Location = new System.Drawing.Point(23, 21);
            this.lblTotalBookings.Name = "lblTotalBookings";
            this.lblTotalBookings.Size = new System.Drawing.Size(157, 28);
            this.lblTotalBookings.TabIndex = 0;
            this.lblTotalBookings.Text = "Total Bookings:";
            // 
            // frmOperator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1143, 640);
            this.Controls.Add(this.tabControl1);
            this.Name = "frmOperator";
            this.Text = "Tour Operator Dashboard";
            this.Load += new System.EventHandler(this.frmOperator_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabTrips.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTrips)).EndInit();
            this.tabBookings.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBookings)).EndInit();
            this.tabServices.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvServices)).EndInit();
            this.tabAnalytics.ResumeLayout(false);
            this.tabAnalytics.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvReviews)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabTrips;
        private DataGridView dgvTrips;
        private Button btnAddTrip;
        private Button btnEditTrip;
        private Button btnDeleteTrip;
        private TabPage tabBookings;
        private DataGridView dgvBookings;
        private ComboBox cboBookingStatus; // New field
        private Button btnUpdateStatus; // New field
        private TabPage tabServices;
        private DataGridView dgvServices;
        private Button btnAssignService;
        private Button btnDeleteService;
        private Button btnRefreshServices;
        private TabPage tabAnalytics;
        private DataGridView dgvReviews;
        private Label lblAvgRating;
        private Label lblTotalRevenue;
        private Label lblTotalBookings;
    }
}