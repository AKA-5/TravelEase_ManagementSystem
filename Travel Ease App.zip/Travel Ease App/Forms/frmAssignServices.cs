﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmAssignServices : Form
    {
        private readonly string _operatorId;
        private ComboBox cboTrip;
        private CheckedListBox clbServices;
        private Button btnSave;
        private Button btnCancel;
        private Label lblTravelersCount;
        private bool _isFormInitialized = false;

        public frmAssignServices(string operatorId)
        {
            _operatorId = operatorId;
            InitializeComponent();
            SetupForm();
        }

        private void SetupForm()
        {
            this.Text = "Assign Services to Trip";
            this.Size = new Size(600, 500);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterParent;

            // Trip selection
            var lblTrip = new Label { Text = "Trip:", Location = new Point(20, 20), AutoSize = true };
            cboTrip = new ComboBox
            {
                Location = new Point(120, 17),
                Size = new Size(400, 23),
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            // Travelers count display
            lblTravelersCount = new Label
            {
                Location = new Point(20, 50),
                AutoSize = true,
                Font = new Font(Font, FontStyle.Bold)
            };

            // Services checklist
            var lblServices = new Label { Text = "Services:", Location = new Point(20, 80), AutoSize = true };
            clbServices = new CheckedListBox
            {
                Location = new Point(120, 80),
                Size = new Size(400, 280),
                CheckOnClick = true
            };

            // Buttons
            btnSave = new Button
            {
                Text = "Save Assignments",
                Location = new Point(120, 370),
                Size = new Size(120, 40)
            };
            btnSave.Click += BtnSave_Click;

            btnCancel = new Button
            {
                Text = "Cancel",
                Location = new Point(260, 370),
                Size = new Size(120, 40)
            };
            btnCancel.Click += BtnCancel_Click;

            this.Controls.AddRange(new Control[] { lblTrip, cboTrip, lblTravelersCount, lblServices, clbServices, btnSave, btnCancel });

            LoadTrips();
            cboTrip.SelectedIndexChanged += (s, e) =>
            {
                Console.WriteLine($"SelectedIndexChanged fired. SelectedIndex: {cboTrip.SelectedIndex}, SelectedValue: {cboTrip.SelectedValue?.ToString() ?? "null"}");
                if (_isFormInitialized)
                {
                    LoadServices();
                }
            };

            _isFormInitialized = true;
            if (cboTrip.Items.Count > 0)
            {
                cboTrip.SelectedIndex = 0; // Default to first trip
            }
        }

        private void LoadTrips()
        {
            string query = $@"SELECT TripID, Title 
                            FROM Trip 
                            WHERE OperatorID = '{_operatorId}' 
                            AND TStatus IN ('Ongoing', 'Open To Register')";
            try
            {
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("No trips available for this operator with status 'Ongoing' or 'Open To Register'.",
                        "No Trips", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    cboTrip.DataSource = null;
                    return;
                }

                string selectedTripId = cboTrip.SelectedValue?.ToString();
                cboTrip.DataSource = dt;
                cboTrip.DisplayMember = "Title";
                cboTrip.ValueMember = "TripID";

                if (!string.IsNullOrEmpty(selectedTripId) && dt.AsEnumerable().Any(row => row.Field<string>("TripID") == selectedTripId))
                {
                    cboTrip.SelectedValue = selectedTripId;
                }
                else if (cboTrip.Items.Count > 0)
                {
                    cboTrip.SelectedIndex = 0; // Default to first item
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading trips: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadServices()
        {
            clbServices.Items.Clear();
            Console.WriteLine($"LoadServices - cboTrip.SelectedIndex: {cboTrip.SelectedIndex}, cboTrip.SelectedValue: {cboTrip.SelectedValue?.ToString() ?? "null"}");

            if (cboTrip.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a trip to load available services.",
                    "No Trip Selected", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string tripId = cboTrip.SelectedValue.ToString();

            // Get confirmed travelers count
            string travelersQuery = $@"SELECT COUNT(*) FROM Booking 
                                    WHERE TripID = '{tripId}' AND BStatus = 'Confirmed'";
            int confirmedTravelers;
            try
            {
                object result = DatabaseHelper.ExecuteScalar(travelersQuery);
                confirmedTravelers = result == null ? 0 : Convert.ToInt32(result);
                lblTravelersCount.Text = $"Confirmed Travelers: {confirmedTravelers}";
                Console.WriteLine($"Confirmed Travelers for TripID '{tripId}': {confirmedTravelers}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error retrieving traveler count for TripID '{tripId}': {ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lblTravelersCount.Text = "Confirmed Travelers: N/A";
                return;
            }

            // Only load services with sufficient capacity
            string query = $@"SELECT s.ServiceID, s.ProviderID, 
                            sp.SPName + ' - ' + s.SType + ' (Capacity: ' + CAST(s.AvailableCapacity AS VARCHAR) + ')' AS ServiceDescription,
                            s.AvailableCapacity
                            FROM Service s
                            JOIN ServiceProvider sp ON s.ProviderID = sp.ProviderID
                            WHERE s.AvailableCapacity > 0 
                            AND s.AvailableCapacity >= {confirmedTravelers}";
            try
            {
                DataTable dt = DatabaseHelper.ExecuteQuery(query);
                if (dt == null || dt.Rows.Count == 0)
                {
                    MessageBox.Show("No services available with sufficient capacity for the number of confirmed travelers. " +
                                    "Please ensure services are added with available capacity.",
                        "No Services Available", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                Console.WriteLine($"Found {dt.Rows.Count} services with sufficient capacity for {confirmedTravelers} travelers.");

                foreach (DataRow row in dt.Rows)
                {
                    string serviceId = row["ServiceID"].ToString();
                    int capacity = Convert.ToInt32(row["AvailableCapacity"]);

                    var item = new ServiceItem
                    {
                        ServiceID = serviceId,
                        ProviderID = row["ProviderID"].ToString(),
                        DisplayText = row["ServiceDescription"].ToString(),
                        AvailableCapacity = capacity,
                        HasSufficientCapacity = true // Since we filtered in the query
                    };

                    clbServices.Items.Add(item, false); // Start unchecked
                }

                if (clbServices.Items.Count == 0)
                {
                    MessageBox.Show("No services could be loaded for the selected trip with sufficient capacity. " +
                                    "Please check the database for available services or try a different trip.",
                        "No Services Loaded", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading services: {ex.Message}. " +
                                "Please ensure the database is accessible and services are properly configured.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool IsAssigned(string tripId, string serviceId)
        {
            string query = $@"SELECT COUNT(*) 
                            FROM ServiceAssignment 
                            WHERE TripID = '{tripId}' AND ServiceID = '{serviceId}'";
            try
            {
                object result = DatabaseHelper.ExecuteScalar(query);
                return result != null && Convert.ToInt32(result) > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error checking if service '{serviceId}' is assigned to TripID '{tripId}': {ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateForm())
                return;

            string tripId = cboTrip.SelectedValue.ToString();

            // Re-check traveler count before saving
            string travelersQuery = $@"SELECT COUNT(*) FROM Booking 
                                    WHERE TripID = '{tripId}' AND BStatus = 'Confirmed'";
            int confirmedTravelers;
            try
            {
                object result = DatabaseHelper.ExecuteScalar(travelersQuery);
                confirmedTravelers = result == null ? 0 : Convert.ToInt32(result);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error retrieving traveler count for TripID '{tripId}': {ex.Message}",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate capacity (shouldn't be necessary since we filtered, but keeping for safety)
            foreach (ServiceItem item in clbServices.CheckedItems)
            {
                if (!item.HasSufficientCapacity || item.AvailableCapacity < confirmedTravelers)
                {
                    MessageBox.Show($"Cannot assign service '{item.DisplayText}' - insufficient capacity for {confirmedTravelers} travelers.",
                        "Capacity Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            try
            {
                // Clear existing assignments for the trip
                DatabaseHelper.ExecuteNonQuery(
                    $"DELETE FROM ServiceAssignment WHERE TripID = '{tripId}'");

                // Add new assignments
                foreach (ServiceItem item in clbServices.CheckedItems)
                {
                    DatabaseHelper.ExecuteNonQuery(
                        $@"INSERT INTO ServiceAssignment (TripID, ServiceID, OperatorID, ProviderID, SAStatus)
                        VALUES ('{tripId}', '{item.ServiceID}', '{_operatorId}', '{item.ProviderID}', 'Pending')");
                }

                MessageBox.Show("Services assigned successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error assigning services: {ex.Message}. " +
                                "Please try again or contact support if the issue persists.",
                    "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateForm()
        {
            Console.WriteLine($"ValidateForm - cboTrip.SelectedIndex: {cboTrip.SelectedIndex}, cboTrip.SelectedValue: {cboTrip.SelectedValue?.ToString() ?? "null"}");

            if (cboTrip.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a trip.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboTrip.Focus();
                return false;
            }

            if (clbServices.CheckedItems.Count == 0)
            {
                MessageBox.Show("Please select at least one service.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                clbServices.Focus();
                return false;
            }

            return true;
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        // implement frmAssignServices_Load
        private void frmAssignServices_Load(object sender, EventArgs e)
        {
         
        }

        private class ServiceItem
        {
            public string ServiceID { get; set; }
            public string ProviderID { get; set; }
            public string DisplayText { get; set; }
            public int AvailableCapacity { get; set; }
            public bool HasSufficientCapacity { get; set; }

            public override string ToString() => DisplayText;
        }

    }

}