﻿namespace Travel_Ease_App.Forms
{
    partial class frmTraveler
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabBrowseTrips = new System.Windows.Forms.TabPage();
            this.panelSearch = new System.Windows.Forms.Panel();
            this.chkDateFilter = new System.Windows.Forms.CheckBox();
            this.dtpStartDateTo = new System.Windows.Forms.DateTimePicker();
            this.dtpStartDateFrom = new System.Windows.Forms.DateTimePicker();
            this.lblStartDateTo = new System.Windows.Forms.Label();
            this.lblStartDateFrom = new System.Windows.Forms.Label();
            this.nudMinCapacity = new System.Windows.Forms.NumericUpDown();
            this.lblMinCapacity = new System.Windows.Forms.Label();
            this.nudMaxPrice = new System.Windows.Forms.NumericUpDown();
            this.lblMaxPrice = new System.Windows.Forms.Label();
            this.cboTripType = new System.Windows.Forms.ComboBox();
            this.lblTripType = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.btnWishlist = new System.Windows.Forms.Button();
            this.btnBook = new System.Windows.Forms.Button();
            this.dgvTrips = new System.Windows.Forms.DataGridView();
            this.tabBookings = new System.Windows.Forms.TabPage();
            this.btnCancelBooking = new System.Windows.Forms.Button();
            this.dgvBookings = new System.Windows.Forms.DataGridView();
            this.tabProfile = new System.Windows.Forms.TabPage();
            this.btnSavePreferences = new System.Windows.Forms.Button();
            this.clbPreferences = new System.Windows.Forms.CheckedListBox();
            this.lblPreferences = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.lblAge = new System.Windows.Forms.Label();
            this.txtNationality = new System.Windows.Forms.TextBox();
            this.lblNationality = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.lblPhone = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtFullName = new System.Windows.Forms.TextBox();
            this.lblFullName = new System.Windows.Forms.Label();
            this.tabReviews = new System.Windows.Forms.TabPage();
            this.btnSubmitReview = new System.Windows.Forms.Button();
            this.txtComment = new System.Windows.Forms.TextBox();
            this.lblComment = new System.Windows.Forms.Label();
            this.nudRating = new System.Windows.Forms.NumericUpDown();
            this.lblRating = new System.Windows.Forms.Label();
            this.cboReviewItem = new System.Windows.Forms.ComboBox();
            this.lblReviewItem = new System.Windows.Forms.Label();
            this.cboReviewTarget = new System.Windows.Forms.ComboBox();
            this.lblReviewTarget = new System.Windows.Forms.Label();
            this.btnLogout = new System.Windows.Forms.Button();
            this.tabControl.SuspendLayout();
            this.tabBrowseTrips.SuspendLayout();
            this.panelSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinCapacity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTrips)).BeginInit();
            this.tabBookings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBookings)).BeginInit();
            this.tabProfile.SuspendLayout();
            this.tabReviews.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudRating)).BeginInit();
            this.SuspendLayout();

            // tabControl
            this.tabControl.Controls.Add(this.tabBrowseTrips);
            this.tabControl.Controls.Add(this.tabBookings);
            this.tabControl.Controls.Add(this.tabProfile);
            this.tabControl.Controls.Add(this.tabReviews);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(800, 450);
            this.tabControl.TabIndex = 0;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);

            // tabBrowseTrips
            this.tabBrowseTrips.Controls.Add(this.panelSearch);
            this.tabBrowseTrips.Controls.Add(this.btnWishlist);
            this.tabBrowseTrips.Controls.Add(this.btnBook);
            this.tabBrowseTrips.Controls.Add(this.dgvTrips);
            this.tabBrowseTrips.Location = new System.Drawing.Point(4, 22);
            this.tabBrowseTrips.Name = "tabBrowseTrips";
            this.tabBrowseTrips.Padding = new System.Windows.Forms.Padding(3);
            this.tabBrowseTrips.Size = new System.Drawing.Size(792, 424);
            this.tabBrowseTrips.TabIndex = 0;
            this.tabBrowseTrips.Text = "Browse Trips";

            // panelSearch
            this.panelSearch.Controls.Add(this.chkDateFilter);
            this.panelSearch.Controls.Add(this.dtpStartDateTo);
            this.panelSearch.Controls.Add(this.dtpStartDateFrom);
            this.panelSearch.Controls.Add(this.lblStartDateTo);
            this.panelSearch.Controls.Add(this.lblStartDateFrom);
            this.panelSearch.Controls.Add(this.nudMinCapacity);
            this.panelSearch.Controls.Add(this.lblMinCapacity);
            this.panelSearch.Controls.Add(this.nudMaxPrice);
            this.panelSearch.Controls.Add(this.lblMaxPrice);
            this.panelSearch.Controls.Add(this.cboTripType);
            this.panelSearch.Controls.Add(this.lblTripType);
            this.panelSearch.Controls.Add(this.btnSearch);
            this.panelSearch.Controls.Add(this.txtSearch);
            this.panelSearch.Controls.Add(this.lblSearch);
            this.panelSearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSearch.Location = new System.Drawing.Point(3, 3);
            this.panelSearch.Name = "panelSearch";
            this.panelSearch.Size = new System.Drawing.Size(786, 120);
            this.panelSearch.TabIndex = 0;

            // chkDateFilter
            this.chkDateFilter.AutoSize = true;
            this.chkDateFilter.Location = new System.Drawing.Point(300, 90);
            this.chkDateFilter.Name = "chkDateFilter";
            this.chkDateFilter.Size = new System.Drawing.Size(100, 17);
            this.chkDateFilter.TabIndex = 12;
            this.chkDateFilter.Text = "Filter by Date";

            // dtpStartDateTo
            this.dtpStartDateTo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpStartDateTo.Location = new System.Drawing.Point(450, 85);
            this.dtpStartDateTo.Name = "dtpStartDateTo";
            this.dtpStartDateTo.Size = new System.Drawing.Size(100, 20);
            this.dtpStartDateTo.TabIndex = 11;

            // dtpStartDateFrom
            this.dtpStartDateFrom.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpStartDateFrom.Location = new System.Drawing.Point(350, 85);
            this.dtpStartDateFrom.Name = "dtpStartDateFrom";
            this.dtpStartDateFrom.Size = new System.Drawing.Size(100, 20);
            this.dtpStartDateFrom.TabIndex = 10;

            // lblStartDateTo
            this.lblStartDateTo.AutoSize = true;
            this.lblStartDateTo.Location = new System.Drawing.Point(450, 65);
            this.lblStartDateTo.Name = "lblStartDateTo";
            this.lblStartDateTo.Size = new System.Drawing.Size(30, 13);
            this.lblStartDateTo.TabIndex = 9;
            this.lblStartDateTo.Text = "To:";

            // lblStartDateFrom
            this.lblStartDateFrom.AutoSize = true;
            this.lblStartDateFrom.Location = new System.Drawing.Point(350, 65);
            this.lblStartDateFrom.Name = "lblStartDateFrom";
            this.lblStartDateFrom.Size = new System.Drawing.Size(38, 13);
            this.lblStartDateFrom.TabIndex = 8;
            this.lblStartDateFrom.Text = "From:";

            // nudMinCapacity
            this.nudMinCapacity.Location = new System.Drawing.Point(350, 35);
            this.nudMinCapacity.Maximum = 200;
            this.nudMinCapacity.Name = "nudMinCapacity";
            this.nudMinCapacity.Size = new System.Drawing.Size(100, 20);
            this.nudMinCapacity.TabIndex = 7;

            // lblMinCapacity
            this.lblMinCapacity.AutoSize = true;
            this.lblMinCapacity.Location = new System.Drawing.Point(350, 15);
            this.lblMinCapacity.Name = "lblMinCapacity";
            this.lblMinCapacity.Size = new System.Drawing.Size(80, 13);
            this.lblMinCapacity.TabIndex = 6;
            this.lblMinCapacity.Text = "Min Capacity:";

            // nudMaxPrice
            this.nudMaxPrice.DecimalPlaces = 2;
            this.nudMaxPrice.Location = new System.Drawing.Point(200, 35);
            this.nudMaxPrice.Maximum = 10000;
            this.nudMaxPrice.Name = "nudMaxPrice";
            this.nudMaxPrice.Size = new System.Drawing.Size(100, 20);
            this.nudMaxPrice.TabIndex = 5;

            // lblMaxPrice
            this.lblMaxPrice.AutoSize = true;
            this.lblMaxPrice.Location = new System.Drawing.Point(200, 15);
            this.lblMaxPrice.Name = "lblMaxPrice";
            this.lblMaxPrice.Size = new System.Drawing.Size(60, 13);
            this.lblMaxPrice.TabIndex = 4;
            this.lblMaxPrice.Text = "Max Price:";

            // cboTripType
            this.cboTripType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTripType.Items.AddRange(new object[] { "", "Adventure", "Cultural", "Leisure", "Historical", "Luxury", "Solo", "Group" });
            this.cboTripType.Location = new System.Drawing.Point(50, 35);
            this.cboTripType.Name = "cboTripType";
            this.cboTripType.Size = new System.Drawing.Size(100, 21);
            this.cboTripType.TabIndex = 3;

            // lblTripType
            this.lblTripType.AutoSize = true;
            this.lblTripType.Location = new System.Drawing.Point(50, 15);
            this.lblTripType.Name = "lblTripType";
            this.lblTripType.Size = new System.Drawing.Size(56, 13);
            this.lblTripType.TabIndex = 2;
            this.lblTripType.Text = "Trip Type:";

            // btnSearch
            this.btnSearch.Location = new System.Drawing.Point(600, 35);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 1;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);

            // txtSearch
            this.txtSearch.Location = new System.Drawing.Point(50, 85);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(200, 20);
            this.txtSearch.TabIndex = 0;

            // lblSearch
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(50, 65);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(47, 13);
            this.lblSearch.TabIndex = 0;
            this.lblSearch.Text = "Search:";

            // btnWishlist
            this.btnWishlist.Location = new System.Drawing.Point(600, 130);
            this.btnWishlist.Name = "btnWishlist";
            this.btnWishlist.Size = new System.Drawing.Size(100, 23);
            this.btnWishlist.TabIndex = 2;
            this.btnWishlist.Text = "Add to Wishlist";
            this.btnWishlist.UseVisualStyleBackColor = true;
            this.btnWishlist.Click += new System.EventHandler(this.btnWishlist_Click);

            // btnBook
            this.btnBook.Location = new System.Drawing.Point(500, 130);
            this.btnBook.Name = "btnBook";
            this.btnBook.Size = new System.Drawing.Size(75, 23);
            this.btnBook.TabIndex = 1;
            this.btnBook.Text = "Book Trip";
            this.btnBook.UseVisualStyleBackColor = true;
            this.btnBook.Click += new System.EventHandler(this.btnBook_Click);

            // dgvTrips
            this.dgvTrips.AllowUserToAddRows = false;
            this.dgvTrips.AllowUserToDeleteRows = false;
            this.dgvTrips.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTrips.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTrips.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvTrips.Location = new System.Drawing.Point(3, 3);
            this.dgvTrips.Name = "dgvTrips";
            this.dgvTrips.ReadOnly = true;
            this.dgvTrips.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTrips.Size = new System.Drawing.Size(786, 418);
            this.dgvTrips.TabIndex = 0;

            // tabBookings
            this.tabBookings.Controls.Add(this.btnCancelBooking);
            this.tabBookings.Controls.Add(this.dgvBookings);
            this.tabBookings.Location = new System.Drawing.Point(4, 22);
            this.tabBookings.Name = "tabBookings";
            this.tabBookings.Padding = new System.Windows.Forms.Padding(3);
            this.tabBookings.Size = new System.Drawing.Size(792, 424);
            this.tabBookings.TabIndex = 1;
            this.tabBookings.Text = "My Bookings";

            // btnCancelBooking
            this.btnCancelBooking.Location = new System.Drawing.Point(600, 130);
            this.btnCancelBooking.Name = "btnCancelBooking";
            this.btnCancelBooking.Size = new System.Drawing.Size(100, 23);
            this.btnCancelBooking.TabIndex = 1;
            this.btnCancelBooking.Text = "Cancel Booking";
            this.btnCancelBooking.UseVisualStyleBackColor = true;
            this.btnCancelBooking.Click += new System.EventHandler(this.btnCancelBooking_Click);

            // dgvBookings
            this.dgvBookings.AllowUserToAddRows = false;
            this.dgvBookings.AllowUserToDeleteRows = false;
            this.dgvBookings.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBookings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBookings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvBookings.Location = new System.Drawing.Point(3, 3);
            this.dgvBookings.Name = "dgvBookings";
            this.dgvBookings.ReadOnly = true;
            this.dgvBookings.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvBookings.Size = new System.Drawing.Size(786, 418);
            this.dgvBookings.TabIndex = 0;

            // tabProfile
            this.tabProfile.Controls.Add(this.btnSavePreferences);
            this.tabProfile.Controls.Add(this.clbPreferences);
            this.tabProfile.Controls.Add(this.lblPreferences);
            this.tabProfile.Controls.Add(this.txtAge);
            this.tabProfile.Controls.Add(this.lblAge);
            this.tabProfile.Controls.Add(this.txtNationality);
            this.tabProfile.Controls.Add(this.lblNationality);
            this.tabProfile.Controls.Add(this.txtPhone);
            this.tabProfile.Controls.Add(this.lblPhone);
            this.tabProfile.Controls.Add(this.txtEmail);
            this.tabProfile.Controls.Add(this.lblEmail);
            this.tabProfile.Controls.Add(this.txtFullName);
            this.tabProfile.Controls.Add(this.lblFullName);
            this.tabProfile.Location = new System.Drawing.Point(4, 22);
            this.tabProfile.Name = "tabProfile";
            this.tabProfile.Padding = new System.Windows.Forms.Padding(3);
            this.tabProfile.Size = new System.Drawing.Size(792, 424);
            this.tabProfile.TabIndex = 2;
            this.tabProfile.Text = "My Profile";

            // btnSavePreferences
            this.btnSavePreferences.Location = new System.Drawing.Point(500, 350);
            this.btnSavePreferences.Name = "btnSavePreferences";
            this.btnSavePreferences.Size = new System.Drawing.Size(100, 23);
            this.btnSavePreferences.TabIndex = 12;
            this.btnSavePreferences.Text = "Save Preferences";
            this.btnSavePreferences.UseVisualStyleBackColor = true;
            this.btnSavePreferences.Click += new System.EventHandler(this.btnSavePreferences_Click);

            // clbPreferences
            this.clbPreferences.FormattingEnabled = true;
            this.clbPreferences.Location = new System.Drawing.Point(350, 100);
            this.clbPreferences.Name = "clbPreferences";
            this.clbPreferences.Size = new System.Drawing.Size(200, 94);
            this.clbPreferences.TabIndex = 11;

            // lblPreferences
            this.lblPreferences.AutoSize = true;
            this.lblPreferences.Location = new System.Drawing.Point(350, 80);
            this.lblPreferences.Name = "lblPreferences";
            this.lblPreferences.Size = new System.Drawing.Size(71, 13);
            this.lblPreferences.TabIndex = 10;
            this.lblPreferences.Text = "Preferences:";

            // txtAge
            this.txtAge.Enabled = false;
            this.txtAge.Location = new System.Drawing.Point(100, 250);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(200, 20);
            this.txtAge.TabIndex = 9;

            // lblAge
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(100, 230);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(29, 13);
            this.lblAge.TabIndex = 8;
            this.lblAge.Text = "Age:";

            // txtNationality
            this.txtNationality.Enabled = false;
            this.txtNationality.Location = new System.Drawing.Point(100, 200);
            this.txtNationality.Name = "txtNationality";
            this.txtNationality.Size = new System.Drawing.Size(200, 20);
            this.txtNationality.TabIndex = 7;

            // lblNationality
            this.lblNationality.AutoSize = true;
            this.lblNationality.Location = new System.Drawing.Point(100, 180);
            this.lblNationality.Name = "lblNationality";
            this.lblNationality.Size = new System.Drawing.Size(61, 13);
            this.lblNationality.TabIndex = 6;
            this.lblNationality.Text = "Nationality:";

            // txtPhone
            this.txtPhone.Enabled = false;
            this.txtPhone.Location = new System.Drawing.Point(100, 150);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(200, 20);
            this.txtPhone.TabIndex = 5;

            // lblPhone
            this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(100, 130);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(41, 13);
            this.lblPhone.TabIndex = 4;
            this.lblPhone.Text = "Phone:";

            // txtEmail
            this.txtEmail.Enabled = false;
            this.txtEmail.Location = new System.Drawing.Point(100, 100);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(200, 20);
            this.txtEmail.TabIndex = 3;

            // lblEmail
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(100, 80);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(35, 13);
            this.lblEmail.TabIndex = 2;
            this.lblEmail.Text = "Email:";

            // txtFullName
            this.txtFullName.Enabled = false;
            this.txtFullName.Location = new System.Drawing.Point(100, 50);
            this.txtFullName.Name = "txtFullName";
            this.txtFullName.Size = new System.Drawing.Size(200, 20);
            this.txtFullName.TabIndex = 1;

            // lblFullName
            this.lblFullName.AutoSize = true;
            this.lblFullName.Location = new System.Drawing.Point(100, 30);
            this.lblFullName.Name = "lblFullName";
            this.lblFullName.Size = new System.Drawing.Size(60, 13);
            this.lblFullName.TabIndex = 0;
            this.lblFullName.Text = "Full Name:";

            // tabReviews
            this.tabReviews.Controls.Add(this.btnSubmitReview);
            this.tabReviews.Controls.Add(this.txtComment);
            this.tabReviews.Controls.Add(this.lblComment);
            this.tabReviews.Controls.Add(this.nudRating);
            this.tabReviews.Controls.Add(this.lblRating);
            this.tabReviews.Controls.Add(this.cboReviewItem);
            this.tabReviews.Controls.Add(this.lblReviewItem);
            this.tabReviews.Controls.Add(this.cboReviewTarget);
            this.tabReviews.Controls.Add(this.lblReviewTarget);
            this.tabReviews.Location = new System.Drawing.Point(4, 22);
            this.tabReviews.Name = "tabReviews";
            this.tabReviews.Padding = new System.Windows.Forms.Padding(3);
            this.tabReviews.Size = new System.Drawing.Size(792, 424);
            this.tabReviews.TabIndex = 3;
            this.tabReviews.Text = "Reviews";

            // btnSubmitReview
            this.btnSubmitReview.Location = new System.Drawing.Point(500, 350);
            this.btnSubmitReview.Name = "btnSubmitReview";
            this.btnSubmitReview.Size = new System.Drawing.Size(100, 23);
            this.btnSubmitReview.TabIndex = 7;
            this.btnSubmitReview.Text = "Submit Review";
            this.btnSubmitReview.UseVisualStyleBackColor = true;
            this.btnSubmitReview.Click += new System.EventHandler(this.btnSubmitReview_Click);

            // txtComment
            this.txtComment.Location = new System.Drawing.Point(100, 200);
            this.txtComment.Multiline = true;
            this.txtComment.Name = "txtComment";
            this.txtComment.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtComment.Size = new System.Drawing.Size(400, 100);
            this.txtComment.TabIndex = 6;

            // lblComment
            this.lblComment.AutoSize = true;
            this.lblComment.Location = new System.Drawing.Point(100, 180);
            this.lblComment.Name = "lblComment";
            this.lblComment.Size = new System.Drawing.Size(53, 13);
            this.lblComment.TabIndex = 5;
            this.lblComment.Text = "Comment:";

            // nudRating
            this.nudRating.Location = new System.Drawing.Point(100, 150);
            this.nudRating.Maximum = 5;
            this.nudRating.Minimum = 1;
            this.nudRating.Name = "nudRating";
            this.nudRating.Size = new System.Drawing.Size(50, 20);
            this.nudRating.TabIndex = 4;

            // lblRating
            this.lblRating.AutoSize = true;
            this.lblRating.Location = new System.Drawing.Point(100, 130);
            this.lblRating.Name = "lblRating";
            this.lblRating.Size = new System.Drawing.Size(43, 13);
            this.lblRating.TabIndex = 3;
            this.lblRating.Text = "Rating:";

            // cboReviewItem
            this.cboReviewItem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboReviewItem.Location = new System.Drawing.Point(100, 100);
            this.cboReviewItem.Name = "cboReviewItem";
            this.cboReviewItem.Size = new System.Drawing.Size(200, 21);
            this.cboReviewItem.TabIndex = 2;

            // lblReviewItem
            this.lblReviewItem.AutoSize = true;
            this.lblReviewItem.Location = new System.Drawing.Point(100, 80);
            this.lblReviewItem.Name = "lblReviewItem";
            this.lblReviewItem.Size = new System.Drawing.Size(62, 13);
            this.lblReviewItem.TabIndex = 1;
            this.lblReviewItem.Text = "Review For:";

            // cboReviewTarget
            this.cboReviewTarget.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboReviewTarget.Items.AddRange(new object[] { "Trip", "Service Provider" });
            this.cboReviewTarget.Location = new System.Drawing.Point(100, 50);
            this.cboReviewTarget.Name = "cboReviewTarget";
            this.cboReviewTarget.Size = new System.Drawing.Size(200, 21);
            this.cboReviewTarget.TabIndex = 0;
            this.cboReviewTarget.SelectedIndexChanged += new System.EventHandler(this.cboReviewTarget_SelectedIndexChanged);

            // lblReviewTarget
            this.lblReviewTarget.AutoSize = true;
            this.lblReviewTarget.Location = new System.Drawing.Point(100, 30);
            this.lblReviewTarget.Name = "lblReviewTarget";
            this.lblReviewTarget.Size = new System.Drawing.Size(74, 13);
            this.lblReviewTarget.TabIndex = 0;
            this.lblReviewTarget.Text = "Review Target:";

            // btnLogout
            this.btnLogout.Location = new System.Drawing.Point(700, 400);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(75, 23);
            this.btnLogout.TabIndex = 1;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);

            // frmTraveler
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnLogout);
            this.Controls.Add(this.tabControl);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "frmTraveler";
            this.Text = "Traveler Portal";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmTraveler_FormClosing);
            this.tabControl.ResumeLayout(false);
            this.tabBrowseTrips.ResumeLayout(false);
            this.panelSearch.ResumeLayout(false);
            this.panelSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudMinCapacity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudMaxPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTrips)).EndInit();
            this.tabBookings.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBookings)).EndInit();
            this.tabProfile.ResumeLayout(false);
            this.tabProfile.PerformLayout();
            this.tabReviews.ResumeLayout(false);
            this.tabReviews.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudRating)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabBrowseTrips;
        private System.Windows.Forms.DataGridView dgvTrips;
        private System.Windows.Forms.Button btnBook;
        private System.Windows.Forms.Button btnWishlist;
        private System.Windows.Forms.Panel panelSearch;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.ComboBox cboTripType;
        private System.Windows.Forms.Label lblTripType;
        private System.Windows.Forms.NumericUpDown nudMaxPrice;
        private System.Windows.Forms.Label lblMaxPrice;
        private System.Windows.Forms.NumericUpDown nudMinCapacity;
        private System.Windows.Forms.Label lblMinCapacity;
        private System.Windows.Forms.Label lblStartDateFrom;
        private System.Windows.Forms.Label lblStartDateTo;
        private System.Windows.Forms.DateTimePicker dtpStartDateFrom;
        private System.Windows.Forms.DateTimePicker dtpStartDateTo;
        private System.Windows.Forms.CheckBox chkDateFilter;
        private System.Windows.Forms.TabPage tabBookings;
        private System.Windows.Forms.DataGridView dgvBookings;
        private System.Windows.Forms.Button btnCancelBooking;
        private System.Windows.Forms.TabPage tabProfile;
        private System.Windows.Forms.TextBox txtFullName;
        private System.Windows.Forms.Label lblFullName;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.TextBox txtNationality;
        private System.Windows.Forms.Label lblNationality;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.CheckedListBox clbPreferences;
        private System.Windows.Forms.Label lblPreferences;
        private System.Windows.Forms.Button btnSavePreferences;
        private System.Windows.Forms.TabPage tabReviews;
        private System.Windows.Forms.ComboBox cboReviewTarget;
        private System.Windows.Forms.Label lblReviewTarget;
        private System.Windows.Forms.ComboBox cboReviewItem;
        private System.Windows.Forms.Label lblReviewItem;
        private System.Windows.Forms.NumericUpDown nudRating;
        private System.Windows.Forms.Label lblRating;
        private System.Windows.Forms.TextBox txtComment;
        private System.Windows.Forms.Label lblComment;
        private System.Windows.Forms.Button btnSubmitReview;
        private System.Windows.Forms.Button btnLogout;
    }
}