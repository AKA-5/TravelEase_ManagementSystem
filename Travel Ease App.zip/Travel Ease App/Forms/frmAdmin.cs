﻿using System;
using System.Data;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmAdmin : Form
    {
        private DataGridView _dgvBookings;
        private DataGridView _dgvStats;

        public frmAdmin()
        {
            InitializeComponent();
            SetupAdminDashboard();
        }

        private void SetupAdminDashboard()
        {
            this.Text = "Admin Dashboard";
            this.WindowState = FormWindowState.Maximized;

            // Stats Panel
            _dgvStats = new DataGridView { Dock = DockStyle.Top, Height = 150 };

            // Bookings Grid
            _dgvBookings = new DataGridView { Dock = DockStyle.Fill };

            // Export Button
            var btnExport = new Button { Text = "Export to Excel", Dock = DockStyle.Bottom };
            btnExport.Click += (s, e) => ExportToExcel();

            this.Controls.AddRange(new Control[] { _dgvStats, _dgvBookings, btnExport });
            RefreshDashboard();
        }

        private void RefreshDashboard()
        {
            _dgvStats.DataSource = DatabaseHelper.ExecuteQuery(
                @"SELECT 'Travelers' as Category, COUNT(*) as Count FROM Traveler
                  UNION ALL
                  SELECT 'Operators', COUNT(*) FROM TourOperator
                  UNION ALL
                  SELECT 'Active Trips', COUNT(*) FROM Trip WHERE TStatus = 'Open'");

            _dgvBookings.DataSource = DatabaseHelper.ExecuteQuery(
                "SELECT TOP 10 * FROM Booking ORDER BY BookingDate DESC");
        }

        private void ExportToExcel()
        {
            var saveFile = new SaveFileDialog { Filter = "Excel|*.xlsx" };
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    ExcelExporter.Export((DataTable)_dgvBookings.DataSource, saveFile.FileName);
                    MessageBox.Show("Exported successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Export failed: {ex.Message}");
                }
            }
        }

        private void frmAdmin_Load(object sender, EventArgs e)
        {

        }
    }
}