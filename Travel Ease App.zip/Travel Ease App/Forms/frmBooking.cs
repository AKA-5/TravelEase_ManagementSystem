﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmBooking : Form
    {
        private readonly string _tripId;
        private readonly string _travelerId;
        private Button _btnConfirm;
        private TableLayoutPanel tableLayout;
        private TextBox txtVoucherCode;
        private Button btnApplyVoucher;
        private Label lblPrice;
        private Label lblDiscount;
        private decimal discountAmount = 0m;
        private string appliedVoucherId;
        private decimal originalPrice;

        public frmBooking(string tripId, string travelerId)
        {
            _tripId = tripId;
            _travelerId = travelerId;
            InitializeComponent();
            SetupBookingForm();
        }

        private void SetupBookingForm()
        {
            this.Text = $"Book Trip {_tripId}";
            this.Size = new Size(500, 500);

            // Get trip details
            var trip = DatabaseHelper.ExecuteQuery(
                $"SELECT t.Title, d.City, d.Country, t.TDescription, t.PricePerPersonInDollars " +
                $"FROM Trip t JOIN Destination d ON t.TripID = d.TripID WHERE t.TripID = @TripID",
                new Dictionary<string, object> { { "@TripID", _tripId } }).Rows[0];
            originalPrice = Convert.ToDecimal(trip["PricePerPersonInDollars"]);

            // Use TableLayoutPanel for layout control
            tableLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                ColumnCount = 2,
                RowCount = 7,
                Padding = new Padding(10),
                CellBorderStyle = TableLayoutPanelCellBorderStyle.None
            };
            tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70F));
            tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30F));
            for (int i = 0; i < 7; i++)
                tableLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));

            // Title label
            var lblTitle = new Label
            {
                Text = trip["Title"].ToString(),
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleLeft,
                AutoSize = true
            };
            tableLayout.Controls.Add(lblTitle, 0, 0);
            tableLayout.SetColumnSpan(lblTitle, 2);

            // Location label (City, Country)
            var lblLocation = new Label
            {
                Text = $"{trip["City"]}, {trip["Country"]}",
                TextAlign = ContentAlignment.MiddleLeft,
                AutoSize = true
            };
            tableLayout.Controls.Add(lblLocation, 0, 1);
            tableLayout.SetColumnSpan(lblLocation, 2);

            // Description label
            var lblDescription = new Label
            {
                Text = trip["TDescription"].ToString(),
                TextAlign = ContentAlignment.TopLeft,
                AutoSize = true,
                MaximumSize = new Size(480, 0)
            };
            tableLayout.Controls.Add(lblDescription, 0, 2);
            tableLayout.SetColumnSpan(lblDescription, 2);

            // Price label
            lblPrice = new Label
            {
                Text = $"Price: ${originalPrice:F2}",
                TextAlign = ContentAlignment.MiddleLeft,
                AutoSize = true
            };
            tableLayout.Controls.Add(lblPrice, 0, 3);
            tableLayout.SetColumnSpan(lblPrice, 2);

            // Voucher input
            txtVoucherCode = new TextBox
            {
                Text = "Enter Voucher Code",
                Width = 200
            };
            btnApplyVoucher = new Button
            {
                Text = "Apply",
                Width = 80
            };
            btnApplyVoucher.Click += (s, e) => ApplyVoucher();
            tableLayout.Controls.Add(txtVoucherCode, 0, 4);
            tableLayout.Controls.Add(btnApplyVoucher, 1, 4);

            // Discount label
            lblDiscount = new Label
            {
                Text = "Discount: $0.00",
                TextAlign = ContentAlignment.MiddleLeft,
                AutoSize = true
            };
            tableLayout.Controls.Add(lblDiscount, 0, 5);
            tableLayout.SetColumnSpan(lblDiscount, 2);

            // Confirm button
            _btnConfirm = new Button { Text = "Confirm Booking", AutoSize = true };
            _btnConfirm.Click += (s, e) => ConfirmBooking();
            tableLayout.Controls.Add(_btnConfirm, 0, 6);
            tableLayout.SetColumnSpan(_btnConfirm, 2);

            // Add table layout to form
            this.Controls.Add(tableLayout);

            // Center the form on the screen
            this.StartPosition = FormStartPosition.CenterParent;
        }

        private void ApplyVoucher()
        {
            try
            {
                string voucherCode = txtVoucherCode.Text.Trim();
                if (string.IsNullOrEmpty(voucherCode))
                {
                    MessageBox.Show("Please enter a voucher code.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                string query = @"
                    SELECT VoucherID, DiscountAmount
                    FROM Voucher
                    WHERE TravelerID = @TravelerID AND VoucherCode = @VoucherCode AND VStatus = 'Active' AND ExpiryDate >= GETDATE()";
                var parameters = new Dictionary<string, object>
                {
                    { "@TravelerID", _travelerId },
                    { "@VoucherCode", voucherCode }
                };
                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Invalid or expired voucher code.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                discountAmount = Convert.ToDecimal(dt.Rows[0]["DiscountAmount"]);
                appliedVoucherId = dt.Rows[0]["VoucherID"].ToString();
                lblDiscount.Text = $"Discount: ${discountAmount:F2}";
                lblPrice.Text = $"Price: ${(originalPrice - discountAmount):F2} (Original: ${originalPrice:F2})";

                MessageBox.Show($"Voucher applied! Discount: ${discountAmount:F2}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error applying voucher: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ConfirmBooking()
        {
            try
            {
                string bookingCheckQuery = @"
                    SELECT COUNT(*) 
                    FROM Booking 
                    WHERE TravelerID = @TravelerID AND TripID = @TripID AND BStatus IN ('Confirmed', 'Recovered')";
                var bookingCheckParams = new Dictionary<string, object>
                {
                    { "@TravelerID", _travelerId },
                    { "@TripID", _tripId }
                };
                int existingBookingCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(bookingCheckQuery, bookingCheckParams));
                if (existingBookingCount > 0)
                {
                    MessageBox.Show("You have already booked this trip.", "Duplicate Booking", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Step 1: Get the number of confirmed travelers (including this booking)
                string travelerCountQuery = @"
                    SELECT COUNT(*) 
                    FROM Booking 
                    WHERE TripID = @TripID AND BStatus = 'Confirmed'";
                var travelerCountParams = new Dictionary<string, object> { { "@TripID", _tripId } };
                int currentTravelerCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(travelerCountQuery, travelerCountParams));

                // Since this booking is about to be confirmed, increment the count
                int totalTravelerCount = currentTravelerCount + 1;

                // Step 2: Check services assigned to the trip
                string serviceQuery = @"
                    SELECT sa.ServiceID, sa.ProviderID, s.AvailableCapacity 
                    FROM ServiceAssignment sa
                    JOIN [Service] s ON sa.ServiceID = s.ServiceID AND sa.ProviderID = s.ProviderID
                    WHERE sa.TripID = @TripID AND sa.SAStatus = 'Accepted'";
                var serviceParams = new Dictionary<string, object> { { "@TripID", _tripId } };
                DataTable services = DatabaseHelper.ExecuteQuery(serviceQuery, serviceParams);

                foreach (DataRow service in services.Rows)
                {
                    string serviceId = service["ServiceID"].ToString();
                    string providerId = service["ProviderID"].ToString();
                    int availableCapacity = Convert.ToInt32(service["AvailableCapacity"]);

                    // Step 3: If available capacity is less than the total number of travelers, reject the service assignment
                    if (availableCapacity < totalTravelerCount)
                    {
                        string updateStatusQuery = @"
                            UPDATE ServiceAssignment 
                            SET SAStatus = 'Rejected' 
                            WHERE TripID = @TripID AND ServiceID = @ServiceID AND ProviderID = @ProviderID";
                        var updateParams = new Dictionary<string, object>
                        {
                            { "@TripID", _tripId },
                            { "@ServiceID", serviceId },
                            { "@ProviderID", providerId }
                        };
                        DatabaseHelper.ExecuteNonQuery(updateStatusQuery, updateParams);
                    }
                }

                // Step 3: Create payment record
                string paymentCountQuery = "SELECT COUNT(*) FROM Payment";
                int paymentCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(paymentCountQuery));
                string paymentId = $"PY{(paymentCount + 1):D3}";
                decimal finalAmount = originalPrice - discountAmount;
                if (finalAmount < 0) finalAmount = 0;

                string paymentQuery = @"
                    INSERT INTO Payment (PaymentID, AmountInDollars, PaymentDate, PaymentMethod, PStatus)
                    VALUES (@PaymentID, @AmountInDollars, @PaymentDate, @PaymentMethod, @PStatus)";
                var paymentParams = new Dictionary<string, object>
                {
                    { "@PaymentID", paymentId },
                    { "@AmountInDollars", finalAmount },
                    { "@PaymentDate", DateTime.Now },
                    { "@PaymentMethod", "Credit Card" },
                    { "@PStatus", "Success" }
                };
                DatabaseHelper.ExecuteNonQuery(paymentQuery, paymentParams);

                // Step 4: Create booking record
                string bookingQuery = @"
                    INSERT INTO Booking (TravelerID, TripID, BStatus, PaymentID, VoucherID)
                    VALUES (@TravelerID, @TripID, @BStatus, @PaymentID, @VoucherID)";
                var bookingParams = new Dictionary<string, object>
                {
                    { "@TravelerID", _travelerId },
                    { "@TripID", _tripId },
                    { "@BStatus", "Confirmed" },
                    { "@PaymentID", paymentId },
                    { "@VoucherID", appliedVoucherId != null ? appliedVoucherId : (object)DBNull.Value }
                };
                DatabaseHelper.ExecuteNonQuery(bookingQuery, bookingParams);

                // Step 5: Mark voucher as used
                if (!string.IsNullOrEmpty(appliedVoucherId))
                {
                    string updateVoucherQuery = "UPDATE Voucher SET VStatus = 'Used' WHERE VoucherID = @VoucherID";
                    var voucherParams = new Dictionary<string, object> { { "@VoucherID", appliedVoucherId } };
                    DatabaseHelper.ExecuteNonQuery(updateVoucherQuery, voucherParams);
                }

                MessageBox.Show($"Booking confirmed! Final Amount: ${finalAmount:F2}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Booking failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmBooking_Load(object sender, EventArgs e)
        {

        }
    }
}