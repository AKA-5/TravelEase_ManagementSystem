﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmBooking : Form
    {
        private readonly string _tripId;
        private readonly string _travelerId;
        private Button _btnConfirm;

        public frmBooking(string tripId, string travelerId)
        {
            _tripId = tripId;
            _travelerId = travelerId;
            InitializeComponent();
            SetupBookingForm();
        }

        private void SetupBookingForm()
        {
            this.Text = $"Book Trip {_tripId}";
            this.Size = new Size(500, 400);

            // Get trip details
            var trip = DatabaseHelper.ExecuteQuery(
                $"SELECT t.Title, d.City, d.Country, t.TDescription FROM Trip t " +
                $"JOIN Destination d ON t.TripID = d.TripID WHERE t.TripID = '{_tripId}'").Rows[0];

            // Use TableLayoutPanel for better layout control
            var tableLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true,
                ColumnCount = 1,
                RowCount = 3,
                Padding = new Padding(10),
                CellBorderStyle = TableLayoutPanelCellBorderStyle.None
            };

            // Title label
            var lblTitle = new Label
            {
                Text = trip["Title"].ToString(),
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                AutoSize = true
            };

            // Location label (City, Country)
            var lblLocation = new Label
            {
                Text = $"{trip["City"]}, {trip["Country"]}",
                TextAlign = ContentAlignment.MiddleCenter,
                AutoSize = true
            };

            // Description label
            var lblDescription = new Label
            {
                Text = trip["TDescription"].ToString(),
                TextAlign = ContentAlignment.TopLeft,
                AutoSize = true,
                MaximumSize = new Size(480, 0) // Limit width to fit form, allow height to adjust
            };

            // Confirm button
            _btnConfirm = new Button { Text = "Confirm Booking", AutoSize = true };
            _btnConfirm.Click += (s, e) => ConfirmBooking();

            // Add controls to table layout
            tableLayout.Controls.Add(lblTitle, 0, 0);
            tableLayout.Controls.Add(lblLocation, 0, 1);
            tableLayout.Controls.Add(lblDescription, 0, 2);
            tableLayout.Controls.Add(_btnConfirm, 0, 3);
            tableLayout.SetCellPosition(_btnConfirm, new TableLayoutPanelCellPosition(0, 3));
            tableLayout.SetRowSpan(lblDescription, 1); // Allow description to take one row

            // Add table layout to form
            this.Controls.Add(tableLayout);

            // Center the form on the screen
            this.StartPosition = FormStartPosition.CenterParent;
        }

        private void ConfirmBooking()
        {
            try
            {
                // Step 1: Get the number of confirmed travelers (including this booking)
                string travelerCountQuery = @"
                    SELECT COUNT(*) 
                    FROM Booking 
                    WHERE TripID = @TripID AND BStatus = 'Confirmed'";
                var travelerCountParams = new Dictionary<string, object> { { "@TripID", _tripId } };
                int currentTravelerCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(travelerCountQuery, travelerCountParams));

                // Since this booking is about to be confirmed, increment the count
                int totalTravelerCount = currentTravelerCount + 1;

                // Step 2: Check services assigned to the trip
                string serviceQuery = @"
                    SELECT sa.ServiceID, sa.ProviderID, s.AvailableCapacity 
                    FROM ServiceAssignment sa
                    JOIN [Service] s ON sa.ServiceID = s.ServiceID AND sa.ProviderID = s.ProviderID
                    WHERE sa.TripID = @TripID AND sa.SAStatus = 'Accepted'";
                var serviceParams = new Dictionary<string, object> { { "@TripID", _tripId } };
                DataTable services = DatabaseHelper.ExecuteQuery(serviceQuery, serviceParams);

                foreach (DataRow service in services.Rows)
                {
                    string serviceId = service["ServiceID"].ToString();
                    string providerId = service["ProviderID"].ToString();
                    int availableCapacity = Convert.ToInt32(service["AvailableCapacity"]);

                    // Step 3: If available capacity is less than the total number of travelers, reject the service assignment
                    if (availableCapacity < totalTravelerCount)
                    {
                        string updateStatusQuery = @"
                            UPDATE ServiceAssignment 
                            SET SAStatus = 'Rejected' 
                            WHERE TripID = @TripID AND ServiceID = @ServiceID AND ProviderID = @ProviderID";
                        var updateParams = new Dictionary<string, object>
                        {
                            { "@TripID", _tripId },
                            { "@ServiceID", serviceId },
                            { "@ProviderID", providerId }
                        };
                        DatabaseHelper.ExecuteNonQuery(updateStatusQuery, updateParams);
                    }
                }

                // Step 4: Proceed with the booking regardless of service assignment status
                string bookingQuery = "INSERT INTO Booking (TravelerID, TripID, BStatus) VALUES (@TravelerID, @TripID, @BStatus)";
                var bookingParams = new Dictionary<string, object>
                {
                    { "@TravelerID", _travelerId },
                    { "@TripID", _tripId },
                    { "@BStatus", "Confirmed" }
                };
                DatabaseHelper.ExecuteNonQuery(bookingQuery, bookingParams);

                MessageBox.Show("Booking confirmed!");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Booking failed: {ex.Message}");
            }
        }

        private void frmBooking_Load(object sender, EventArgs e)
        {

        }
    }
}