﻿namespace Travel_Ease_App.Forms
{
    partial class frmManageServiceAssignment
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblServiceType = new System.Windows.Forms.Label();
            this.lblCurrentProvider = new System.Windows.Forms.Label();
            this.cboNewProvider = new System.Windows.Forms.ComboBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblServiceType
            // 
            this.lblServiceType.AutoSize = true;
            this.lblServiceType.Location = new System.Drawing.Point(12, 20);
            this.lblServiceType.Name = "lblServiceType";
            this.lblServiceType.Size = new System.Drawing.Size(71, 13);
            this.lblServiceType.TabIndex = 0;
            this.lblServiceType.Text = "Service Type:";
            // 
            // lblCurrentProvider
            // 
            this.lblCurrentProvider.AutoSize = true;
            this.lblCurrentProvider.Location = new System.Drawing.Point(12, 50);
            this.lblCurrentProvider.Name = "lblCurrentProvider";
            this.lblCurrentProvider.Size = new System.Drawing.Size(83, 13);
            this.lblCurrentProvider.TabIndex = 1;
            this.lblCurrentProvider.Text = "Current Provider:";
            // 
            // cboNewProvider
            // 
            this.cboNewProvider.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNewProvider.FormattingEnabled = true;
            this.cboNewProvider.Location = new System.Drawing.Point(15, 80);
            this.cboNewProvider.Name = "cboNewProvider";
            this.cboNewProvider.Size = new System.Drawing.Size(300, 21);
            this.cboNewProvider.TabIndex = 2;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(159, 120);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 3;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(240, 120);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmManageServiceAssignment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 161);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.cboNewProvider);
            this.Controls.Add(this.lblCurrentProvider);
            this.Controls.Add(this.lblServiceType);
            this.Name = "frmManageServiceAssignment";
            this.Text = "Reassign Service Provider";
            this.Load += new System.EventHandler(this.frmManageServiceAssignment_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label lblServiceType;
        private System.Windows.Forms.Label lblCurrentProvider;
        private System.Windows.Forms.ComboBox cboNewProvider;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnCancel;
    }
}