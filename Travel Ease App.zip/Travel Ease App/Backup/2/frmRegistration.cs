﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmRegistration : Form
    {
        private RadioButton _rdoTraveler;
        private RadioButton _rdoOperator;
        private Panel _pnlTravelerFields;
        private Panel _pnlOperatorFields;
        private Button _btnRegister;

        public frmRegistration()
        {
            InitializeComponent();
            SetupRegistrationForm();
        }

        private void SetupRegistrationForm()
        {
            this.Text = "TravelEase - New Account Registration";
            this.Size = new Size(450, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;

            // Main container
            var mainPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20) };

            // Title label
            var lblTitle = new Label
            {
                Text = "Create New Account",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 16, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                Height = 50
            };

            // Account type selection
            var pnlAccountType = new Panel { Dock = DockStyle.Top, Height = 50 };

            _rdoTraveler = new RadioButton
            {
                Text = "Traveler Account",
                Checked = true,
                Dock = DockStyle.Left,
                Width = 150
            };
            _rdoTraveler.CheckedChanged += (s, e) => ToggleRegistrationFields();

            _rdoOperator = new RadioButton
            {
                Text = "Tour Operator Account",
                Dock = DockStyle.Left,
                Width = 180
            };
            _rdoOperator.CheckedChanged += (s, e) => ToggleRegistrationFields();

            pnlAccountType.Controls.Add(_rdoOperator);
            pnlAccountType.Controls.Add(_rdoTraveler);

            // Common fields
            var pnlCommonFields = new Panel { Dock = DockStyle.Top, AutoSize = true };

            var lblEmail = new Label { Text = "Email:", Dock = DockStyle.Top, Margin = new Padding(0, 10, 0, 0) };
            var txtEmail = new TextBox { Dock = DockStyle.Top, Tag = "Email" };

            var lblPassword = new Label { Text = "Password:", Dock = DockStyle.Top, Margin = new Padding(0, 10, 0, 0) };
            var txtPassword = new TextBox { Dock = DockStyle.Top, UseSystemPasswordChar = true, Tag = "Password" };

            var lblConfirm = new Label { Text = "Confirm Password:", Dock = DockStyle.Top, Margin = new Padding(0, 10, 0, 0) };
            var txtConfirm = new TextBox { Dock = DockStyle.Top, UseSystemPasswordChar = true, Tag = "Confirm" };

            pnlCommonFields.Controls.AddRange(new Control[] { txtConfirm, lblConfirm, txtPassword, lblPassword, txtEmail, lblEmail });

            // Traveler-specific fields
            _pnlTravelerFields = new Panel { Dock = DockStyle.Top, AutoSize = true, Visible = true };

            var lblFullName = new Label { Text = "Full Name:", Dock = DockStyle.Top, Margin = new Padding(0, 10, 0, 0) };
            var txtFullName = new TextBox { Dock = DockStyle.Top, Tag = "FullName" };

            var lblPhone = new Label { Text = "Phone Number:", Dock = DockStyle.Top, Margin = new Padding(0, 10, 0, 0) };
            var txtPhone = new TextBox { Dock = DockStyle.Top, Tag = "Phone" };

            var lblNationality = new Label { Text = "Nationality:", Dock = DockStyle.Top, Margin = new Padding(0, 10, 0, 0) };
            var txtNationality = new TextBox { Dock = DockStyle.Top, Tag = "Nationality" };

            var lblAge = new Label { Text = "Age:", Dock = DockStyle.Top, Margin = new Padding(0, 10, 0, 0) };
            var numAge = new NumericUpDown { Dock = DockStyle.Top, Minimum = 5, Maximum = 120, Tag = "Age" };

            _pnlTravelerFields.Controls.AddRange(new Control[] { numAge, lblAge, txtNationality, lblNationality, txtPhone, lblPhone, txtFullName, lblFullName });

            // Operator-specific fields
            _pnlOperatorFields = new Panel { Dock = DockStyle.Top, AutoSize = true, Visible = false };

            var lblCompany = new Label { Text = "Company Name:", Dock = DockStyle.Top, Margin = new Padding(0, 10, 0, 0) };
            var txtCompany = new TextBox { Dock = DockStyle.Top, Tag = "Company" };

            var lblOpPhone = new Label { Text = "Contact Phone:", Dock = DockStyle.Top, Margin = new Padding(0, 10, 0, 0) };
            var txtOpPhone = new TextBox { Dock = DockStyle.Top, Tag = "OpPhone" };

            _pnlOperatorFields.Controls.AddRange(new Control[] { txtOpPhone, lblOpPhone, txtCompany, lblCompany });

            // Register button
            _btnRegister = new Button
            {
                Text = "Register",
                Dock = DockStyle.Top,
                Height = 40,
                Margin = new Padding(0, 20, 0, 0),
                BackColor = Color.SteelBlue,
                ForeColor = Color.White
            };
            _btnRegister.Click += (s, e) => ProcessRegistration();

            // Add all controls to main panel
            mainPanel.Controls.Add(_btnRegister);
            mainPanel.Controls.Add(_pnlOperatorFields);
            mainPanel.Controls.Add(_pnlTravelerFields);
            mainPanel.Controls.Add(pnlCommonFields);
            mainPanel.Controls.Add(pnlAccountType);
            mainPanel.Controls.Add(lblTitle);

            this.Controls.Add(mainPanel);

            // Add this temporarily to your SetupRegistrationForm method:
            var btnDebug = new Button
            {
                Text = "Debug",
                Dock = DockStyle.Bottom,
                Height = 30
            };
            btnDebug.Click += (s, e) => {
                MessageBox.Show($"Email value: {GetControlValue("Email")}\n" +
                               $"Password value: {GetControlValue("Password")}");
            };
            mainPanel.Controls.Add(btnDebug);
        }

        private void ToggleRegistrationFields()
        {
            _pnlTravelerFields.Visible = _rdoTraveler.Checked;
            _pnlOperatorFields.Visible = _rdoOperator.Checked;
        }

        private void ProcessRegistration()
        {
            try
            {
                // Debug: Show what values are being captured
                var email = GetControlValue("Email");
                var password = GetControlValue("Password");
                var confirm = GetControlValue("Confirm");

                Console.WriteLine($"Email: {email}");
                Console.WriteLine($"Password: {password}");
                Console.WriteLine($"Confirm: {confirm}");

                if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
                {
                    MessageBox.Show("Email and password are required");
                    return;
                }

                if (password != confirm)
                {
                    MessageBox.Show("Passwords do not match");
                    return;
                }

                if (_rdoTraveler.Checked)
                {
                    RegisterTraveler(email, password);
                }
                else
                {
                    RegisterOperator(email, password);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Registration failed: {ex.Message}");
            }
        }

        private void RegisterTraveler(string email, string password)
        {
            var fullName = GetControlValue("FullName");
            var phone = GetControlValue("Phone");
            var nationality = GetControlValue("Nationality");
            var ageStr = GetControlValue("Age");

            if (string.IsNullOrWhiteSpace(fullName))
            {
                MessageBox.Show("Full name is required");
                return;
            }

            // Validate and parse age
            if (!int.TryParse(ageStr, out int age) || age < 5 || age > 120)
            {
                MessageBox.Show("Please enter a valid age between 5 and 120");
                return;
            }

            string travelerId = DatabaseHelper.GetNextTravelerID();
            string query = @"
                INSERT INTO Traveler (
                    TravelerID, FullName, Email, TPassword, 
                    PhoneNumber, Nationality, Age, AccountStatus
                ) VALUES (
                    @TravelerID, @FullName, @Email, @Password,
                    @Phone, @Nationality, @Age, 'Active'
                )";

            var parameters = new Dictionary<string, object>
            {
                { "@TravelerID", travelerId },
                { "@FullName", fullName },
                { "@Email", email },
                { "@Password", password }, // Consider using DatabaseHelper.HashPassword(password)
                { "@Phone", string.IsNullOrWhiteSpace(phone) ? DBNull.Value : (object)phone },
                { "@Nationality", string.IsNullOrWhiteSpace(nationality) ? DBNull.Value : (object)nationality },
                { "@Age", age }
            };

            try
            {
                int rowsAffected = DatabaseHelper.ExecuteNonQuery(query, parameters);
                if (rowsAffected > 0)
                {
                    MessageBox.Show($"Traveler account created successfully! Your ID: {travelerId}");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Registration failed. Please try again.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Registration error: {ex.Message}");
            }
        }

        private void RegisterOperator(string email, string password)
        {
            var companyName = GetControlValue("Company");
            var phone = GetControlValue("OpPhone");

            if (string.IsNullOrWhiteSpace(companyName))
            {
                MessageBox.Show("Company name is required");
                return;
            }

            string operatorId = DatabaseHelper.GetNextOperatorID();
            string query = @"
                INSERT INTO TourOperator (
                    OperatorID, CompanyName, Email, TOPassword,
                    Phone, AccountStatus
                ) VALUES (
                    @OperatorID, @CompanyName, @Email, @Password,
                    @Phone, 'Active'
                )";

            var parameters = new Dictionary<string, object>
            {
                { "@OperatorID", operatorId },
                { "@CompanyName", companyName },
                { "@Email", email },
                { "@Password", password },
                { "@Phone", string.IsNullOrWhiteSpace(phone) ? DBNull.Value : (object)phone }
            };

            try
            {
                int rowsAffected = DatabaseHelper.ExecuteNonQuery(query, parameters);
                if (rowsAffected > 0)
                {
                    MessageBox.Show($"Tour operator account submitted for approval! Your ID: {operatorId}");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Registration failed. Please try again.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Registration error: {ex.Message}");
            }
        }

        private string GetControlValue(string tag)
        {
            // Search through all controls recursively
            foreach (Control control in GetAllControls(this))
            {
                if (control.Tag?.ToString() == tag)
                {
                    if (control is NumericUpDown num)
                        return num.Value.ToString();
                    if (control is TextBox txt)
                        return txt.Text;
                }
            }
            return string.Empty;
        }

        // Helper method to get all controls recursively
        private IEnumerable<Control> GetAllControls(Control control)
        {
            var controls = new List<Control>();

            foreach (Control child in control.Controls)
            {
                controls.Add(child);
                controls.AddRange(GetAllControls(child));
            }

            return controls;
        }
    }
}