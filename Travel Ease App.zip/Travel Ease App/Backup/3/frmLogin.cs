﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
            SetupLoginForm();
        }

        private void SetupLoginForm()
        {
            this.Text = "TravelEase - Login";
            this.Size = new Size(400, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.BackColor = Color.FromArgb(240, 245, 249);

            // Main container
            var mainPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(40),
                BackColor = Color.White
            };

            // Logo/Title
            var lblTitle = new Label
            {
                Text = "Welcome Back",
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.FromArgb(44, 62, 80),
                Dock = DockStyle.Top,
                Height = 80,
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Email field
            var pnlEmail = new Panel { Dock = DockStyle.Top, Height = 80 };
            var lblEmail = new Label
            {
                Text = "Email",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.FromArgb(44, 62, 80)
            };
            var txtEmail = new TextBox
            {
                Dock = DockStyle.Top,
                Height = 40,
                Font = new Font("Segoe UI", 10),
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(0, 5, 0, 0)
            };
            pnlEmail.Controls.AddRange(new Control[] { txtEmail, lblEmail });

            // Password field
            var pnlPassword = new Panel { Dock = DockStyle.Top, Height = 80 };
            var lblPassword = new Label
            {
                Text = "Password",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 9),
                ForeColor = Color.FromArgb(44, 62, 80)
            };
            var txtPassword = new TextBox
            {
                Dock = DockStyle.Top,
                Height = 40,
                Font = new Font("Segoe UI", 10),
                BorderStyle = BorderStyle.FixedSingle,
                UseSystemPasswordChar = true,
                Margin = new Padding(0, 5, 0, 0)
            };
            var chkShowPassword = new CheckBox
            {
                Text = "Show Password",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 8),
                Margin = new Padding(0, 5, 0, 0),
                Appearance = Appearance.Button
            };
            chkShowPassword.CheckedChanged += (s, e) => {
                txtPassword.UseSystemPasswordChar = !chkShowPassword.Checked;
            };
            pnlPassword.Controls.AddRange(new Control[] { chkShowPassword, txtPassword, lblPassword });

            // Login button
            var btnLogin = new Button
            {
                Text = "Login",
                Dock = DockStyle.Top,
                Height = 45,
                BackColor = Color.FromArgb(52, 152, 219),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11, FontStyle.Bold),
                Margin = new Padding(0, 20, 0, 0)
            };
            btnLogin.Click += (s, e) => Authenticate(txtEmail.Text, txtPassword.Text);

            // Register link
            var lblRegister = new LinkLabel
            {
                Text = "Don't have an account? Register here",
                Dock = DockStyle.Top,
                TextAlign = ContentAlignment.MiddleCenter,
                Margin = new Padding(0, 20, 0, 0),
                Font = new Font("Segoe UI", 9)
            };
            lblRegister.Click += (s, e) => {
                this.Hide();
                new frmRegistration().ShowDialog();
                this.Show();
            };

            // Add controls
            mainPanel.Controls.Add(lblRegister);
            mainPanel.Controls.Add(btnLogin);
            mainPanel.Controls.Add(pnlPassword);
            mainPanel.Controls.Add(pnlEmail);
            mainPanel.Controls.Add(lblTitle);

            this.Controls.Add(mainPanel);
        }

        private void Authenticate(string email, string password)
        {
            try
            {
                // First get the user record by email only
                var query = @"SELECT TOP 1 TravelerID, 'Traveler' as Role, TPassword as Password
                      FROM Traveler WHERE Email = @Email
                      
                      UNION ALL
                      
                      SELECT OperatorID, 'Operator', TOPassword
                      FROM TourOperator WHERE Email = @Email
                      
                      UNION ALL
                      
                      SELECT AdminID, 'Admin', APassword
                      FROM Admin WHERE Email = @Email
                      
                      UNION ALL
                      
                      SELECT ProviderID, 'Provider', SPPassword
                      FROM ServiceProvider WHERE Email = @Email";

                var parameters = new Dictionary<string, object> { { "@Email", email } };
                var result = DatabaseHelper.ExecuteQuery(query, parameters);

                if (result.Rows.Count > 0)
                {
                    // Perform case-sensitive comparison in code
                    string storedPassword = result.Rows[0]["Password"].ToString();

                    if (string.Equals(password, storedPassword, StringComparison.Ordinal))
                    {
                        var userId = result.Rows[0][0].ToString();
                        var role = result.Rows[0][1].ToString();
                        this.Hide();
                        new frmMain(userId, role).Show();
                        return;
                    }
                }

                MessageBox.Show("Invalid credentials");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Login error: {ex.Message}");
            }
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
