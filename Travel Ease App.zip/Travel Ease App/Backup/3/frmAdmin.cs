﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;
using System.Collections.Generic;
using OfficeOpenXml;
using System.Linq;
using System.Diagnostics;

namespace Travel_Ease_App.Forms
{
    public partial class frmAdmin : Form
    {
        private DataGridView _dgvBookings;
        private DataGridView _dgvStats;
        private TabControl _tabControl;
        private DataGridView _dgvReviews;

        public frmAdmin()
        {
            InitializeComponent();
            SetupAdminDashboard();
        }

        private void SetupAdminDashboard()
        {
            this.Text = "Admin Dashboard - TravelEase";
            this.WindowState = FormWindowState.Maximized;

            // Create tab control
            _tabControl = new TabControl { Dock = DockStyle.Fill };

            // Tab 1: Dashboard
            var tabDashboard = new TabPage("Dashboard");
            SetupDashboardTab(tabDashboard);

            // Tab 2: User Management
            var tabUsers = new TabPage("User Management");
            SetupUserManagementTab(tabUsers);

            // Tab 3: Reports
            var tabReports = new TabPage("Reports");
            SetupReportsTab(tabReports);

            var tabReviews = new TabPage("Review Moderation");
            SetupReviewModerationTab(tabReviews);
            _tabControl.TabPages.Add(tabReviews);

            _tabControl.TabPages.AddRange(new TabPage[] { tabDashboard, tabUsers, tabReports });
            this.Controls.Add(_tabControl);

            RefreshDashboard();
        }

        private void SetupReviewModerationTab(TabPage tab)
        {
            // Clear existing controls
            tab.Controls.Clear();

            // Main container panel
            var mainPanel = new Panel { Dock = DockStyle.Fill };

            /* ====================== */
            /*  FILTER PANEL (TOP)   */
            /* ====================== */
            var filterPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 50,
                BackColor = SystemColors.Control
            };

            // Filter dropdown
            var cmbFilter = new ComboBox
            {
                Name = "cmbReviewFilter",
                Dock = DockStyle.Left,
                Width = 200,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 9)
            };
            cmbFilter.Items.AddRange(new[] { "All Reviews", "Flagged Reviews", "Low Ratings (1-2 stars)" });
            cmbFilter.SelectedIndex = 0;
            cmbFilter.SelectedIndexChanged += (s, e) => LoadReviews(cmbFilter.Text);

            // Refresh button
            var btnRefresh = new Button
            {
                Text = "Refresh",
                Dock = DockStyle.Left,
                Width = 80,
                Margin = new Padding(5, 0, 0, 0),
                Font = new Font("Segoe UI", 9)
            };
            btnRefresh.Click += (s, e) => LoadReviews(cmbFilter.Text);

            filterPanel.Controls.Add(cmbFilter);
            filterPanel.Controls.Add(btnRefresh);

            /* ====================== */
            /*  REVIEWS GRID (MIDDLE) */
            /* ====================== */
            _dgvReviews = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                BackgroundColor = SystemColors.Window,
                BorderStyle = BorderStyle.FixedSingle,

                // Selection configuration
                MultiSelect = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    SelectionBackColor = Color.LightSteelBlue,
                    SelectionForeColor = SystemColors.ControlText
                }
            };

            /* ====================== */
            /*  ACTION PANEL (BOTTOM) */
            /* ====================== */
            var actionPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                BackColor = SystemColors.Control
            };

            // Selection info label
            var lblSelection = new Label
            {
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleLeft,
                Font = new Font("Segoe UI", 9, FontStyle.Bold),
                Text = "  No review selected",
                ForeColor = SystemColors.HotTrack
            };

            // Flag button
            var btnFlag = new Button
            {
                Text = "🚩 Flag",
                Dock = DockStyle.Right,
                Width = 90,
                Margin = new Padding(0, 0, 5, 0),
                Font = new Font("Segoe UI", 9),
                BackColor = Color.LightCoral
            };
            btnFlag.Click += (s, e) => FlagSelectedReview(true);

            // Unflag button
            var btnUnflag = new Button
            {
                Text = "✅ Unflag",
                Dock = DockStyle.Right,
                Width = 90,
                Margin = new Padding(0, 0, 5, 0),
                Font = new Font("Segoe UI", 9),
                BackColor = Color.LightGreen
            };
            btnUnflag.Click += (s, e) => FlagSelectedReview(false);

            // Delete button
            var btnDelete = new Button
            {
                Text = "🗑️ Delete",
                Dock = DockStyle.Left,
                Width = 90,
                Margin = new Padding(5, 0, 0, 0),
                Font = new Font("Segoe UI", 9),
                BackColor = Color.LightSalmon
            };
            btnDelete.Click += (s, e) => DeleteSelectedReview();

            // Selection changed handler
            _dgvReviews.SelectionChanged += (s, e) =>
            {
                if (_dgvReviews.SelectedRows.Count > 0)
                {
                    var row = _dgvReviews.SelectedRows[0];
                    lblSelection.Text = $"  Selected: {row.Cells["TripTitle"].Value} (Rating: {row.Cells["Rating"].Value})";
                }
                else
                {
                    lblSelection.Text = "  No review selected";
                }
            };

            // Add controls to action panel
            actionPanel.Controls.Add(btnDelete);
            actionPanel.Controls.Add(lblSelection);
            actionPanel.Controls.Add(btnUnflag);
            actionPanel.Controls.Add(btnFlag);

            /* ====================== */
            /*  ASSEMBLE ALL CONTROLS */
            /* ====================== */
            mainPanel.Controls.Add(_dgvReviews);
            mainPanel.Controls.Add(actionPanel);
            mainPanel.Controls.Add(filterPanel);

            tab.Controls.Add(mainPanel);

            // Load initial data
            LoadReviews("All Reviews");
        }

        private void LoadReviews(string filterType)
        {
            try
            {
                // Clear previous data
                _dgvReviews.DataSource = null;
                _dgvReviews.Columns.Clear();

                string filterParam;
                if (filterType == "Flagged Reviews")
                {
                    filterParam = "Flagged";
                }
                else if (filterType == "Low Ratings (1-2 stars)")
                {
                    filterParam = "LowRatings";
                }
                else
                {
                    filterParam = "All";
                }

                var parameters = new Dictionary<string, object>
        {
            { "@FilterType", filterParam }
        };

                // Get data from database
                DataTable reviewsData = DatabaseHelper.ExecuteQuery(
                    "EXEC sp_GetReviewsForModeration @FilterType",
                    parameters);

                // Configure grid
                _dgvReviews.AutoGenerateColumns = false;

                // Add columns
                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "TravelerName",
                    HeaderText = "Traveler",
                    Name = "TravelerName",
                    Width = 120
                });

                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "TripTitle",
                    HeaderText = "Trip",
                    Name = "TripTitle",
                    Width = 150
                });

                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "ProviderName",
                    HeaderText = "Service Provider",
                    Name = "ProviderName",
                    Width = 150
                });

                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "Rating",
                    HeaderText = "Rating",
                    Name = "Rating",
                    Width = 60
                });

                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "Comment",
                    HeaderText = "Comment",
                    Name = "Comment",
                    Width = 200,
                    DefaultCellStyle = new DataGridViewCellStyle { WrapMode = DataGridViewTriState.True }
                });

                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "ReviewDate",
                    HeaderText = "Date",
                    Name = "ReviewDate",
                    Width = 120
                });

                // Make IsFlagged column visible
                _dgvReviews.Columns.Add(new DataGridViewCheckBoxColumn()
                {
                    DataPropertyName = "IsFlagged",
                    HeaderText = "Flagged",
                    Name = "IsFlagged",
                    Width = 60,
                    ReadOnly = true  // Make it read-only since we'll use buttons to change flag status
                });

                // Hidden column for ReviewID
                _dgvReviews.Columns.Add(new DataGridViewTextBoxColumn()
                {
                    DataPropertyName = "ReviewID",
                    HeaderText = "ReviewID",
                    Name = "ReviewID",
                    Visible = false
                });

                // Bind data
                _dgvReviews.DataSource = reviewsData;

                // Highlight flagged reviews
                foreach (DataGridViewRow row in _dgvReviews.Rows)
                {
                    if (row.Cells["IsFlagged"].Value != DBNull.Value &&
                        Convert.ToBoolean(row.Cells["IsFlagged"].Value))
                    {
                        row.DefaultCellStyle.BackColor = Color.LightPink;
                    }
                    else
                    {
                        row.DefaultCellStyle.BackColor = _dgvReviews.DefaultCellStyle.BackColor;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading reviews: {ex.Message}");
            }
        }

        private void FlagSelectedReview(bool isFlagged)
        {
            if (_dgvReviews.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a review first by clicking on a row");
                return;
            }

            var reviewId = _dgvReviews.SelectedRows[0].Cells["ReviewID"].Value.ToString();
            var reviewTitle = _dgvReviews.SelectedRows[0].Cells["TripTitle"].Value.ToString();

            try
            {
                var parameters = new Dictionary<string, object>
        {
            { "@ReviewID", reviewId },
            { "@IsFlagged", isFlagged }
        };

                DatabaseHelper.ExecuteNonQuery(
                    "EXEC sp_FlagReview @ReviewID, @IsFlagged",
                    parameters);

                MessageBox.Show($"Review '{reviewTitle}' has been {(isFlagged ? "flagged" : "unflagged")}");

                // Update the UI immediately
                _dgvReviews.SelectedRows[0].Cells["IsFlagged"].Value = isFlagged;
                _dgvReviews.SelectedRows[0].DefaultCellStyle.BackColor = isFlagged ? Color.LightPink : _dgvReviews.DefaultCellStyle.BackColor;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating review: {ex.Message}");
            }
        }

        private void DeleteSelectedReview()
        {
            if (_dgvReviews.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a review first by clicking on a row");
                return;
            }

            var reviewId = _dgvReviews.SelectedRows[0].Cells["ReviewID"].Value.ToString();
            var reviewTitle = _dgvReviews.SelectedRows[0].Cells["TripTitle"].Value.ToString();

            if (MessageBox.Show($"Are you sure you want to delete the review for '{reviewTitle}'?",
                "Confirm Delete", MessageBoxButtons.YesNo) != DialogResult.Yes)
            {
                return;
            }

            try
            {
                var parameters = new Dictionary<string, object>
        {
            { "@ReviewID", reviewId }
        };

                DatabaseHelper.ExecuteNonQuery(
                    "EXEC sp_DeleteReview @ReviewID",
                    parameters);

                MessageBox.Show("Review deleted successfully");
                LoadReviews(GetCurrentFilter()); // Refresh the list
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting review: {ex.Message}");
            }
        }
        private string GetCurrentFilter()
        {
            // Find the filter combobox in the controls hierarchy
            foreach (Control control in _dgvReviews.Parent.Controls)
            {
                if (control is Panel panel)
                {
                    foreach (Control panelControl in panel.Controls)
                    {
                        if (panelControl is ComboBox comboBox && comboBox.Name == "cmbReviewFilter")
                        {
                            return comboBox.Text;
                        }
                    }
                }
            }
            return "All Reviews"; // Default if not found
        }

        private void SetupDashboardTab(TabPage tab)
        {
            // Clear existing controls
            tab.Controls.Clear();

            // Main container panel
            var mainPanel = new Panel { Dock = DockStyle.Fill };

            // 1. Stats Panel (Top Section)
            var statsPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 120,  // Reduced height
                Padding = new Padding(5),
                BackColor = SystemColors.Control
            };

            _dgvStats = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                BackgroundColor = SystemColors.Window
            };

            // 2. Bookings Panel (Middle Section)
            var bookingsPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(5, 0, 5, 5)
            };

            _dgvBookings = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                RowHeadersVisible = false,
                BackgroundColor = SystemColors.Window,
                ScrollBars = ScrollBars.Vertical
            };

            // 3. Export Button (Bottom Section)
            var buttonPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 25,
                Padding = new Padding(5, 0, 5, 0)
            };

            var btnExport = new Button
            {
                Text = "Export to Excel",
                Dock = DockStyle.Fill,
                Height = 40
            };
            btnExport.Click += (s, e) => ExportToExcel();

            // Add controls to containers
            statsPanel.Controls.Add(_dgvStats);
            bookingsPanel.Controls.Add(_dgvBookings);
            buttonPanel.Controls.Add(btnExport);

            // Add panels to main panel in correct order
            mainPanel.Controls.Add(buttonPanel);
            mainPanel.Controls.Add(bookingsPanel);
            mainPanel.Controls.Add(statsPanel);

            // Add main panel to tab
            tab.Controls.Add(mainPanel);

            // Safe event handler for DataBindingComplete
            _dgvBookings.DataBindingComplete += BookingsGrid_DataBindingComplete;
        }

        private void BookingsGrid_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            // Ensure the grid has rows and is properly initialized
            if (_dgvBookings.Rows.Count > 0 && _dgvBookings.DisplayedRowCount(false) > 0)
            {
                try
                {
                    // Suspend layout to prevent flickering
                    _dgvBookings.SuspendLayout();

                    // Select and scroll to first row safely
                    _dgvBookings.ClearSelection();
                    _dgvBookings.Rows[0].Selected = true;
                    _dgvBookings.FirstDisplayedScrollingRowIndex = 0;

                    // Ensure columns are properly sized
                    _dgvBookings.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                }
                catch (Exception ex)
                {
                    // Log error if needed
                    Debug.WriteLine($"Error in DataBindingComplete: {ex.Message}");
                }
                finally
                {
                    _dgvBookings.ResumeLayout();
                }
            }
        }



        private void ConfigureBookingsGrid()
        {
            _dgvBookings.AutoGenerateColumns = true;
            _dgvBookings.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            _dgvBookings.EnableHeadersVisualStyles = false;
            _dgvBookings.DefaultCellStyle.WrapMode = DataGridViewTriState.False;
            _dgvBookings.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);

            // Scroll to top after data loads
            _dgvBookings.DataBindingComplete += (s, e) =>
            {
                if (_dgvBookings.Rows.Count > 0)
                {
                    _dgvBookings.FirstDisplayedScrollingRowIndex = 0;
                }
            };
        }



        private void SetupUserManagementTab(TabPage tab)
        {
            var dgvUsers = new DataGridView { Dock = DockStyle.Fill };

            // User type filter
            var cmbUserType = new ComboBox
            {
                Dock = DockStyle.Top,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Items = { "All", "Travelers", "Operators", "Service Providers", "Admins" }
            };
            cmbUserType.SelectedIndexChanged += (s, e) => FilterUsers(dgvUsers, cmbUserType.Text);

            // Action buttons
            var panelButtons = new Panel { Dock = DockStyle.Bottom, Height = 40 };
            var btnApprove = new Button { Text = "Approve", Width = 100, Top = 5, Left = 5 };
            var btnReject = new Button { Text = "Reject", Width = 100, Top = 5, Left = 110 };

            // In SetupUserManagementTab method:
            btnApprove.Click += (s, e) => ProcessUserAction(dgvUsers, "Approve");
            btnReject.Click += (s, e) => ProcessUserAction(dgvUsers, "Reject");

            panelButtons.Controls.AddRange(new Control[] { btnApprove, btnReject });
            tab.Controls.AddRange(new Control[] { dgvUsers, cmbUserType, panelButtons });

            FilterUsers(dgvUsers, "All");
        }

        private void SetupReportsTab(TabPage tab)
        {
            var cmbReports = new ComboBox
            {
                Dock = DockStyle.Top,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Items = {
                    "Trip Booking and Revenue",
                    "Traveler Demographics",
                    "Operator Performance",
                    "Service Provider Efficiency",
                    "Destination Popularity",
                    "Abandoned Bookings",
                    "Platform Growth",
                    "Payment Transactions"
                }
            };

            var dgvReport = new DataGridView { Dock = DockStyle.Fill };
            var chartPanel = new Panel { Dock = DockStyle.Bottom, Height = 300 };

            cmbReports.SelectedIndexChanged += (s, e) =>
                LoadReport(dgvReport, chartPanel, cmbReports.SelectedItem.ToString());

            tab.Controls.AddRange(new Control[] { cmbReports, dgvReport, chartPanel });
            cmbReports.SelectedIndex = 0;
        }

        private void RefreshDashboard()
        {
            try
            {
                // Load stats
                _dgvStats.DataSource = DatabaseHelper.ExecuteQuery(
                    @"SELECT 'Total Travelers' as Category, COUNT(*) as Count FROM Traveler WHERE AccountStatus = 'Active'
              UNION ALL
              SELECT 'Total Operators', COUNT(*) FROM TourOperator WHERE AccountStatus = 'Active'
              UNION ALL
              SELECT 'Active Trips', COUNT(*) FROM Trip WHERE TStatus = 'Open'
              UNION ALL
              SELECT 'Pending Approvals', COUNT(*) FROM (
                  SELECT TravelerID FROM Traveler WHERE AccountStatus = 'Pending'
                  UNION ALL SELECT OperatorID FROM TourOperator WHERE AccountStatus = 'Pending'
                  UNION ALL SELECT ProviderID FROM ServiceProvider WHERE AccountStatus = 'Pending'
              ) as PendingUsers");

                // Load bookings
                var bookingsData = DatabaseHelper.ExecuteQuery(
                    @"SELECT 
                b.TravelerID, b.TripID, 
                FORMAT(b.BookingDate, 'dd/MM/yyyy') as BookingDate,
                b.BStatus as Status,
                b.AbandonmentReason,
                b.PaymentID
              FROM Booking b
              ORDER BY b.BookingDate DESC");

                // Bind data safely
                _dgvBookings.DataSource = null;
                _dgvBookings.DataSource = bookingsData;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading dashboard data: {ex.Message}");
            }
        }

        private void FilterUsers(DataGridView dgv, string userType)
        {
            string query;

            if (userType == "Travelers")
            {
                query = "SELECT TravelerID as UserID, Email, 'Traveler' as Role, AccountStatus FROM Traveler";
            }
            else if (userType == "Operators")
            {
                query = "SELECT OperatorID as UserID, Email, 'Operator' as Role, AccountStatus FROM TourOperator";
            }
            else if (userType == "Service Providers")
            {
                query = "SELECT ProviderID as UserID, Email, 'Service Provider' as Role, AccountStatus FROM ServiceProvider";
            }
            else if (userType == "Admins")
            {
                query = "SELECT AdminID as UserID, Email, 'Admin' as Role, AccountStatus FROM Admin";
            }
            else
            {
                query = @"SELECT TravelerID as UserID, Email, 'Traveler' as Role, AccountStatus FROM Traveler
                UNION ALL SELECT OperatorID, Email, 'Operator', AccountStatus FROM TourOperator
                UNION ALL SELECT ProviderID, Email, 'Service Provider', AccountStatus FROM ServiceProvider
                UNION ALL SELECT AdminID, Email, 'Admin', AccountStatus FROM Admin";
            }

            dgv.DataSource = DatabaseHelper.ExecuteQuery(query);
        }

        private void ProcessUserAction(DataGridView dgv, string action)
        {
            if (dgv.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a user first");
                return;
            }

            DataGridViewRow selectedRow = dgv.SelectedRows[0];
            var userId = selectedRow.Cells["UserID"].Value?.ToString();
            var role = selectedRow.Cells["Role"].Value?.ToString();

            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(role))
            {
                MessageBox.Show("Invalid user selection");
                return;
            }

            string statusValue = action == "Approve" ? "Active" : "Inactive";
            string tableName;
            string idColumn;

            if (role == "Traveler")
            {
                tableName = "Traveler";
                idColumn = "TravelerID";
            }
            else if (role == "Operator")
            {
                tableName = "TourOperator";
                idColumn = "OperatorID";
            }
            else if (role == "Service Provider")
            {
                tableName = "ServiceProvider";
                idColumn = "ProviderID";
            }
            else
            {
                tableName = "Admin";
                idColumn = "AdminID";
            }

            try
            {
                string query = $"UPDATE {tableName} SET AccountStatus = @Status WHERE {idColumn} = @UserId";
                var parameters = new Dictionary<string, object>
                {
                    { "@Status", statusValue },
                    { "@UserId", userId }
                };

                int rowsAffected = DatabaseHelper.ExecuteNonQuery(query, parameters);

                if (rowsAffected > 0)
                {
                    MessageBox.Show($"User {userId} status updated to {statusValue}");
                    // Refresh the user list
                    if (dgv.Parent is TabPage tabPage && tabPage.Parent is TabControl tabControl)
                    {
                        if (tabControl.SelectedTab == tabPage)
                        {
                            var cmbUserType = tabPage.Controls.OfType<ComboBox>().FirstOrDefault();
                            if (cmbUserType != null)
                            {
                                FilterUsers(dgv, cmbUserType.Text);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("No changes were made. User not found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating user status: {ex.Message}");
            }
        }

        private void LoadReport(DataGridView dgv, Panel chartPanel, string reportType)
        {
            string query;

            if (reportType == "Trip Booking and Revenue")
            {
                query = @"SELECT t.Title, t.TripType, 
                COUNT(CONCAT(b.TravelerID, b.TripID)) as Bookings, 
                SUM(t.PricePerPersonInDollars) as Revenue, 
                SUM(CASE WHEN b.BStatus = 'Cancelled' THEN 1 ELSE 0 END) as Cancellations
                FROM Trip t 
                LEFT JOIN Booking b ON t.TripID = b.TripID
                GROUP BY t.Title, t.TripType";
            }
            else if (reportType == "Traveler Demographics")
            {
                query = @"SELECT Nationality, Age, COUNT(*) as Count, 
                FROM Traveler GROUP BY Nationality, Age";
            }
            else if (reportType == "Operator Performance")
            {
                query = @"SELECT o.CompanyName, AVG(r.Rating) as AvgRating, 
                COUNT(DISTINCT CONCAT(b.TravelerID, b.TripID)) as Bookings, 
                SUM(t.PricePerPersonInDollars) as Revenue
                FROM TourOperator o
                LEFT JOIN Trip t ON o.OperatorID = t.OperatorID
                LEFT JOIN Booking b ON t.TripID = b.TripID
                LEFT JOIN Review r ON t.TripID = r.TripID
                GROUP BY o.CompanyName";
            }
            else if (reportType == "Service Provider Efficiency")
            {
                query = @"SELECT p.SPName, p.ServiceType, AVG(r.Rating) as AvgRating, 
                COUNT(a.AssignmentID) as Assignments
                FROM ServiceProvider p
                LEFT JOIN ServiceAssignment a ON p.ProviderID = a.ProviderID
                LEFT JOIN Review r ON a.AssignmentID = r.AssignmentID
                GROUP BY p.SPName, p.ServiceType";
            }
            else if (reportType == "Destination Popularity")
            {
                query = @"SELECT d.City, d.Country, 
                COUNT(DISTINCT CONCAT(b.TravelerID, b.TripID)) as Bookings, 
                AVG(r.Rating) as AvgRating
                FROM Destination d
                JOIN Trip t ON d.TripID = t.TripID
                LEFT JOIN Booking b ON t.TripID = b.TripID
                LEFT JOIN Review r ON t.TripID = r.TripID
                GROUP BY d.City, d.Country";
            }
            else if (reportType == "Abandoned Bookings")
            {
                query = @"SELECT t.Title, COUNT(*) as AbandonedCount
                FROM Trip t
                JOIN Booking b ON t.TripID = b.TripID
                WHERE b.BStatus = 'Abandoned'
                GROUP BY t.Title";
            }
            else if (reportType == "Platform Growth")
            {
                query = @"SELECT 
                COUNT(CASE WHEN Role = 'Traveler' THEN 1 END) as NewTravelers,
                COUNT(CASE WHEN Role = 'Operator' THEN 1 END) as NewOperators,
                MONTH(RegistrationDate) as Month,
                YEAR(RegistrationDate) as Year
                FROM (
                    SELECT TravelerID as ID, 'Traveler' as Role, RegistrationDate FROM Traveler
                    UNION ALL
                    SELECT OperatorID, 'Operator', RegistrationDate FROM TourOperator
                ) as Users
                GROUP BY YEAR(RegistrationDate), MONTH(RegistrationDate)
                ORDER BY Year, Month";
            }
            else if (reportType == "Payment Transactions")
            {
                query = @"SELECT 
                COUNT(*) as TotalTransactions,
                SUM(CASE WHEN Status = 'Success' THEN 1 ELSE 0 END) as SuccessCount,
                SUM(CASE WHEN Status = 'Failed' THEN 1 ELSE 0 END) as FailedCount,
                PaymentMethod
                FROM Payments
                GROUP BY PaymentMethod";
            }
            else
            {
                query = @"SELECT 
                b.TravelerID, b.TripID, t.Title, 
                b.BookingDate, b.BStatus as Status
                FROM Booking b
                JOIN Trip t ON b.TripID = t.TripID
                ORDER BY b.BookingDate DESC";
            }

            dgv.DataSource = DatabaseHelper.ExecuteQuery(query);
            // TODO: Add chart visualization in chartPanel
        }

        private void ExportToExcel()
        {
            var saveFile = new SaveFileDialog { Filter = "Excel|*.xlsx" };
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;
                    ExcelExporter.Export((DataTable)_dgvBookings.DataSource, saveFile.FileName);
                    MessageBox.Show("Exported successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Export failed: {ex.Message}");
                }
            }
        }

        private void frmAdmin_Load(object sender, EventArgs e)
        {

        }
    }
}