﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmRegistration : Form
    {
        private RadioButton _rdoTraveler;
        private RadioButton _rdoOperator;
        private Panel _pnlTravelerFields;
        private Panel _pnlOperatorFields;
        private Button _btnRegister;
        private CheckBox _chkShowPassword;
        private CheckBox _chkShowConfirm;

        public frmRegistration()
        {
            InitializeComponent();
            SetupRegistrationForm();
        }

        private void SetupRegistrationForm()
        {
            this.Text = "TravelEase - New Account Registration";
            this.Size = new Size(500, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.BackColor = Color.FromArgb(240, 245, 249);

            // Main container
            var mainPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(25),
                BackColor = Color.White
            };

            // Title label
            var lblTitle = new Label
            {
                Text = "Create New Account",
                Dock = DockStyle.Top,
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                TextAlign = ContentAlignment.MiddleCenter,
                Height = 60,
                ForeColor = Color.FromArgb(44, 62, 80)
            };

            // Account type selection
            var pnlAccountType = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                Padding = new Padding(0, 10, 0, 10)
            };

            _rdoTraveler = new RadioButton
            {
                Text = "Traveler Account",
                Checked = true,
                Dock = DockStyle.Left,
                Width = 160,
                Font = new Font("Segoe UI", 10),
                Appearance = Appearance.Button,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(52, 152, 219),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter,
                Height = 40
            };
            _rdoTraveler.CheckedChanged += (s, e) => ToggleRegistrationFields();

            _rdoOperator = new RadioButton
            {
                Text = "Tour Operator Account",
                Dock = DockStyle.Left,
                Width = 180,
                Font = new Font("Segoe UI", 10),
                Appearance = Appearance.Button,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.FromArgb(231, 76, 60),
                ForeColor = Color.White,
                TextAlign = ContentAlignment.MiddleCenter,
                Height = 40
            };
            _rdoOperator.CheckedChanged += (s, e) => ToggleRegistrationFields();

            pnlAccountType.Controls.Add(_rdoOperator);
            pnlAccountType.Controls.Add(_rdoTraveler);

            // Common fields
            var pnlCommonFields = new Panel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                Padding = new Padding(0, 10, 0, 10)
            };

            var lblEmail = new Label
            {
                Text = "Email:",
                Dock = DockStyle.Top,
                Margin = new Padding(0, 10, 0, 5),
                Font = new Font("Segoe UI", 9)
            };
            var txtEmail = new TextBox
            {
                Dock = DockStyle.Top,
                Tag = "Email",
                Height = 30,
                Font = new Font("Segoe UI", 10)
            };

            var pnlPassword = new Panel { Dock = DockStyle.Top, Height = 60 };
            var lblPassword = new Label
            {
                Text = "Password:",
                Dock = DockStyle.Top,
                Margin = new Padding(0, 10, 0, 5),
                Font = new Font("Segoe UI", 9)
            };
            var txtPassword = new TextBox
            {
                Dock = DockStyle.Left,
                Tag = "Password",
                UseSystemPasswordChar = true,
                Width = mainPanel.Width - 70,
                Height = 30,
                Font = new Font("Segoe UI", 10)
            };
            _chkShowPassword = new CheckBox
            {
                Text = "👁️",
                Dock = DockStyle.Right,
                Appearance = Appearance.Button,
                FlatStyle = FlatStyle.Flat,
                Width = 40,
                Height = 30,
                BackColor = Color.Transparent
            };
            _chkShowPassword.CheckedChanged += (s, e) => {
                txtPassword.UseSystemPasswordChar = !_chkShowPassword.Checked;
            };
            pnlPassword.Controls.AddRange(new Control[] { _chkShowPassword, txtPassword, lblPassword });

            var pnlConfirm = new Panel { Dock = DockStyle.Top, Height = 60 };
            var lblConfirm = new Label
            {
                Text = "Confirm Password:",
                Dock = DockStyle.Top,
                Margin = new Padding(0, 10, 0, 5),
                Font = new Font("Segoe UI", 9)
            };
            var txtConfirm = new TextBox
            {
                Dock = DockStyle.Left,
                Tag = "Confirm",
                UseSystemPasswordChar = true,
                Width = mainPanel.Width - 70,
                Height = 30,
                Font = new Font("Segoe UI", 10)
            };
            _chkShowConfirm = new CheckBox
            {
                Text = "👁️",
                Dock = DockStyle.Right,
                Appearance = Appearance.Button,
                FlatStyle = FlatStyle.Flat,
                Width = 40,
                Height = 30,
                BackColor = Color.Transparent
            };
            _chkShowConfirm.CheckedChanged += (s, e) => {
                txtConfirm.UseSystemPasswordChar = !_chkShowConfirm.Checked;
            };
            pnlConfirm.Controls.AddRange(new Control[] { _chkShowConfirm, txtConfirm, lblConfirm });

            pnlCommonFields.Controls.AddRange(new Control[] { pnlConfirm, pnlPassword, txtEmail, lblEmail });

            // Traveler-specific fields
            _pnlTravelerFields = new Panel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                Visible = true,
                Padding = new Padding(0, 10, 0, 10)
            };

            var lblFullName = new Label
            {
                Text = "Full Name:",
                Dock = DockStyle.Top,
                Margin = new Padding(0, 10, 0, 5),
                Font = new Font("Segoe UI", 9)
            };
            var txtFullName = new TextBox
            {
                Dock = DockStyle.Top,
                Tag = "FullName",
                Height = 30,
                Font = new Font("Segoe UI", 10)
            };

            var lblPhone = new Label
            {
                Text = "Phone Number:",
                Dock = DockStyle.Top,
                Margin = new Padding(0, 10, 0, 5),
                Font = new Font("Segoe UI", 9)
            };
            var txtPhone = new TextBox
            {
                Dock = DockStyle.Top,
                Tag = "Phone",
                Height = 30,
                Font = new Font("Segoe UI", 10)
            };

            var lblNationality = new Label
            {
                Text = "Nationality:",
                Dock = DockStyle.Top,
                Margin = new Padding(0, 10, 0, 5),
                Font = new Font("Segoe UI", 9)
            };
            var txtNationality = new TextBox
            {
                Dock = DockStyle.Top,
                Tag = "Nationality",
                Height = 30,
                Font = new Font("Segoe UI", 10)
            };

            var lblAge = new Label
            {
                Text = "Age (optional):",
                Dock = DockStyle.Top,
                Margin = new Padding(0, 10, 0, 5),
                Font = new Font("Segoe UI", 9)
            };
            var numAge = new NumericUpDown
            {
                Dock = DockStyle.Top,
                Tag = "Age",
                Minimum = 5,
                Maximum = 120,
                Height = 30,
                Font = new Font("Segoe UI", 10),
                Value = 5 // Default value
            };
            // Allow NULL value for age
            numAge.Controls[0].Visible = false; // Hide the up/down buttons
            numAge.Text = ""; // Start with empty value
            numAge.Enter += (s, e) => {
                if (string.IsNullOrEmpty(numAge.Text)) numAge.Text = "5";
            };
            numAge.Leave += (s, e) => {
                if (string.IsNullOrEmpty(numAge.Text)) numAge.Text = "";
            };

            _pnlTravelerFields.Controls.AddRange(new Control[] {
                numAge, lblAge, txtNationality, lblNationality,
                txtPhone, lblPhone, txtFullName, lblFullName
            });

            // Operator-specific fields
            _pnlOperatorFields = new Panel
            {
                Dock = DockStyle.Top,
                AutoSize = true,
                Visible = false,
                Padding = new Padding(0, 10, 0, 10)
            };

            var lblCompany = new Label
            {
                Text = "Company Name:",
                Dock = DockStyle.Top,
                Margin = new Padding(0, 10, 0, 5),
                Font = new Font("Segoe UI", 9)
            };
            var txtCompany = new TextBox
            {
                Dock = DockStyle.Top,
                Tag = "Company",
                Height = 30,
                Font = new Font("Segoe UI", 10)
            };

            var lblOpPhone = new Label
            {
                Text = "Contact Phone:",
                Dock = DockStyle.Top,
                Margin = new Padding(0, 10, 0, 5),
                Font = new Font("Segoe UI", 9)
            };
            var txtOpPhone = new TextBox
            {
                Dock = DockStyle.Top,
                Tag = "OpPhone",
                Height = 30,
                Font = new Font("Segoe UI", 10)
            };

            _pnlOperatorFields.Controls.AddRange(new Control[] { txtOpPhone, lblOpPhone, txtCompany, lblCompany });

            // Register button
            _btnRegister = new Button
            {
                Text = "Register",
                Dock = DockStyle.Top,
                Height = 45,
                Margin = new Padding(0, 20, 0, 0),
                BackColor = Color.FromArgb(46, 204, 113),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 11, FontStyle.Bold)
            };
            _btnRegister.Click += (s, e) => ProcessRegistration();

            // Set tab order programmatically
            SetTabOrder(new Control[] {
                txtEmail, txtPassword, txtConfirm, txtFullName, txtPhone,
                txtNationality, numAge, txtCompany, txtOpPhone, _btnRegister
            });

            // Add all controls to main panel
            mainPanel.Controls.Add(_btnRegister);
            mainPanel.Controls.Add(_pnlOperatorFields);
            mainPanel.Controls.Add(_pnlTravelerFields);
            mainPanel.Controls.Add(pnlCommonFields);
            mainPanel.Controls.Add(pnlAccountType);
            mainPanel.Controls.Add(lblTitle);

            this.Controls.Add(mainPanel);
        }

        private void SetTabOrder(Control[] controls)
        {
            for (int i = 0; i < controls.Length; i++)
            {
                controls[i].TabStop = true;
                controls[i].TabIndex = i;
            }
        }

        private void ToggleRegistrationFields()
        {
            _pnlTravelerFields.Visible = _rdoTraveler.Checked;
            _pnlOperatorFields.Visible = _rdoOperator.Checked;

            // Update button colors based on selection
            if (_rdoTraveler.Checked)
            {
                _rdoTraveler.BackColor = Color.FromArgb(52, 152, 219);
                _rdoOperator.BackColor = Color.FromArgb(231, 76, 60);
            }
            else
            {
                _rdoTraveler.BackColor = Color.FromArgb(189, 195, 199);
                _rdoOperator.BackColor = Color.FromArgb(231, 76, 60);
            }
        }

        private void ProcessRegistration()
        {
            try
            {
                var email = GetControlValue("Email");
                var password = GetControlValue("Password");
                var confirm = GetControlValue("Confirm");

                // Validate email format
                if (!System.Text.RegularExpressions.Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                {
                    MessageBox.Show("Please enter a valid email address");
                    return;
                }

                if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
                {
                    MessageBox.Show("Password must be at least 8 characters long");
                    return;
                }

                if (password != confirm)
                {
                    MessageBox.Show("Passwords do not match");
                    return;
                }

                if (_rdoTraveler.Checked)
                {
                    RegisterTraveler(email, password);
                }
                else
                {
                    RegisterOperator(email, password);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Registration failed: {ex.Message}");
            }
        }

        private void RegisterTraveler(string email, string password)
        {
            var fullName = GetControlValue("FullName");
            var phone = GetControlValue("Phone");
            var nationality = GetControlValue("Nationality");
            var ageStr = GetControlValue("Age");

            if (string.IsNullOrWhiteSpace(fullName))
            {
                MessageBox.Show("Full name is required");
                return;
            }

            // Validate phone number if provided
            if (!string.IsNullOrWhiteSpace(phone) && !phone.All(char.IsDigit))
            {
                MessageBox.Show("Phone number should contain only digits");
                return;
            }

            string travelerId = DatabaseHelper.GetNextTravelerID();
            string query = @"
                INSERT INTO Traveler (
                    TravelerID, FullName, Email, TPassword, 
                    PhoneNumber, Nationality, Age, AccountStatus
                ) VALUES (
                    @TravelerID, @FullName, @Email, @Password,
                    @Phone, @Nationality, @Age, 'Active'
                )";

            var parameters = new Dictionary<string, object>
            {
                { "@TravelerID", travelerId },
                { "@FullName", fullName },
                { "@Email", email },
                { "@Password", password },
                { "@Phone", string.IsNullOrWhiteSpace(phone) ? DBNull.Value : (object)phone },
                { "@Nationality", string.IsNullOrWhiteSpace(nationality) ? DBNull.Value : (object)nationality },
                { "@Age", string.IsNullOrEmpty(ageStr) ? DBNull.Value : (object)int.Parse(ageStr) }
            };

            try
            {
                int rowsAffected = DatabaseHelper.ExecuteNonQuery(query, parameters);
                if (rowsAffected > 0)
                {
                    MessageBox.Show($"Traveler account created successfully! Your ID: {travelerId}");
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Registration error: {ex.Message}");
            }
        }

        private void RegisterOperator(string email, string password)
        {
            var companyName = GetControlValue("Company");
            var phone = GetControlValue("OpPhone");


            if (string.IsNullOrWhiteSpace(companyName))
            {
                MessageBox.Show("Company name is required");
                return;
            }

            // Validate phone number if provided
            if (!string.IsNullOrWhiteSpace(phone) && !phone.All(char.IsDigit))
            {
                MessageBox.Show("Phone number should contain only digits");
                return;
            }

            string operatorId = DatabaseHelper.GetNextOperatorID();
            string query = @"
                INSERT INTO TourOperator (
                    OperatorID, CompanyName, Email, TOPassword,
                    Phone, AccountStatus, Rating
                ) VALUES (
                    @OperatorID, @CompanyName, @Email, @Password,
                    @Phone, 'Active', 3.0
                )";

            var parameters = new Dictionary<string, object>
            {
                { "@OperatorID", operatorId },
                { "@CompanyName", companyName },
                { "@Email", email },
                { "@Password",password },
                { "@Phone", string.IsNullOrWhiteSpace(phone) ? DBNull.Value : (object)phone }
            };

            try
            {
                int rowsAffected = DatabaseHelper.ExecuteNonQuery(query, parameters);
                if (rowsAffected > 0)
                {
                    MessageBox.Show($"Tour operator account created! Your ID: {operatorId}");
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Registration error: {ex.Message}");
            }
        }

        private string GetControlValue(string tag)
        {
            foreach (Control control in GetAllControls(this))
            {
                if (control.Tag?.ToString() == tag)
                {
                    if (control is NumericUpDown num)
                        return string.IsNullOrEmpty(num.Text) ? null : num.Value.ToString();
                    if (control is TextBox txt)
                        return txt.Text;
                }
            }
            return string.Empty;
        }

        private IEnumerable<Control> GetAllControls(Control control)
        {
            var controls = new List<Control>();
            foreach (Control child in control.Controls)
            {
                controls.Add(child);
                controls.AddRange(GetAllControls(child));
            }
            return controls;
        }
    }
}