﻿using System;
using System.Data;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    // frmTraveler.cs
    public partial class frmTraveler : Form
    {
        private readonly string _travelerId;
        private DataGridView _dgvTrips;

        public frmTraveler(string travelerId)
        {
            _travelerId = travelerId;
            InitializeComponent();
            SetupTravelerForm();
        }

        private void SetupTravelerForm()
        {
            this.Text = $"Traveler Portal - User: {_travelerId}";

            // Main Grid
            _dgvTrips = new DataGridView { Dock = DockStyle.Fill };

            // Controls
            var btnLoad = new Button { Text = "Load My Trips", Dock = DockStyle.Top };
            btnLoad.Click += (s, e) => LoadTrips();

            this.Controls.AddRange(new Control[] { _dgvTrips, btnLoad });
        }

        private void LoadTrips()
        {
            try
            {
                string query = $@"SELECT t.TripID, t.Title, d.City, d.Country, b.BookingDate 
                             FROM Booking b
                             JOIN Trip t ON b.TripID = t.TripID
                             JOIN Destination d ON t.TripID = d.TripID
                             WHERE b.TravelerID = '{_travelerId}'";

                _dgvTrips.DataSource = DatabaseHelper.ExecuteQuery(query);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading trips: {ex.Message}");
            }
        }
        private void SetupBookingControls()
        {
            var btnCancel = new Button { Text = "Cancel Booking", Dock = DockStyle.Bottom };
            btnCancel.Click += (s, e) => {
                if (_dgvTrips.SelectedRows.Count > 0)
                {
                    string bookingId = _dgvTrips.SelectedRows[0].Cells["BookingID"].Value.ToString();
                    DatabaseHelper.ExecuteNonQuery(
                        $"UPDATE Booking SET BStatus = 'Cancelled' WHERE BookingID = '{bookingId}'");
                    LoadTrips(); // Refresh
                }
            };
            this.Controls.Add(btnCancel);
        }

        private void frmTraveler_Load(object sender, EventArgs e)
        {

        }
    }
}