﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmAssignServices : Form
    {
        private readonly string _tripId;

        public frmAssignServices(string tripId)
        {
            _tripId = tripId;
            InitializeComponent();
            SetupForm();
        }

        private void SetupForm()
        {
            this.Text = $"Assign Services - Trip {_tripId}";
            this.Size = new Size(500, 400);

            var providers = DatabaseHelper.ExecuteQuery(
                "SELECT ProviderID, SPName FROM ServiceProvider");

            var clbProviders = new CheckedListBox { Dock = DockStyle.Fill };
            foreach (DataRow row in providers.Rows)
            {
                clbProviders.Items.Add(row["SPName"], IsAssigned(row["ProviderID"].ToString()));
            }

            var btnSave = new Button { Text = "Save Assignments", Dock = DockStyle.Bottom };
            btnSave.Click += (s, e) => SaveAssignments(clbProviders);

            this.Controls.AddRange(new Control[] { clbProviders, btnSave });
        }

        private bool IsAssigned(string providerId)
        {
            var result = DatabaseHelper.ExecuteQuery(
                $"SELECT 1 FROM ServiceAssignment WHERE TripID = '{_tripId}' AND ProviderID = '{providerId}'");
            return result.Rows.Count > 0;
        }

        private void SaveAssignments(CheckedListBox clb)
        {
            // Clear existing assignments
            DatabaseHelper.ExecuteNonQuery(
                $"DELETE FROM ServiceAssignment WHERE TripID = '{_tripId}'");

            // Add new assignments
            foreach (var item in clb.CheckedItems)
            {
                var providerId = DatabaseHelper.ExecuteQuery(
                    $"SELECT ProviderID FROM ServiceProvider WHERE SPName = '{item}'").Rows[0][0];

                DatabaseHelper.ExecuteNonQuery(
                    $"INSERT INTO ServiceAssignment (TripID, ProviderID, Accepted) " +
                    $"VALUES ('{_tripId}', '{providerId}', 0)");
            }

            MessageBox.Show("Services assigned successfully!");
            this.Close();
        }
    }
}