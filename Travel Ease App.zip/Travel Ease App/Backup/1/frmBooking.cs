﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmBooking : Form
    {
        private readonly string _tripId;
        private readonly string _travelerId;
        private Button _btnConfirm;

        public frmBooking(string tripId, string travelerId)
        {
            _tripId = tripId;
            _travelerId = travelerId;
            InitializeComponent();
            SetupBookingForm();
        }

        private void SetupBookingForm()
        {
            this.Text = $"Book Trip {_tripId}";
            this.Size = new Size(300, 200);

            // Get trip details
            var trip = DatabaseHelper.ExecuteQuery(
                $"SELECT t.Title, d.City, d.Country FROM Trip t " +
                $"JOIN Destination d ON t.TripID = d.TripID WHERE t.TripID = '{_tripId}'").Rows[0];

            // Display controls
            var lblInfo = new Label
            {
                Text = $"{trip["Title"]}\n{trip["City"]}, {trip["Country"]}",
                Dock = DockStyle.Top,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter
            };

            _btnConfirm = new Button { Text = "Confirm Booking", Dock = DockStyle.Bottom };
            _btnConfirm.Click += (s, e) => ConfirmBooking();

            this.Controls.AddRange(new Control[] { lblInfo, _btnConfirm });
        }

        private void ConfirmBooking()
        {
            try
            {
                string bookingId = "BK" + Guid.NewGuid().ToString("N").Substring(0, 8);
                string query = $@"INSERT INTO Booking (BookingID, TravelerID, TripID, BookingDate, BStatus) 
                               VALUES ('{bookingId}', '{_travelerId}', '{_tripId}', GETDATE(), 'Confirmed')";

                DatabaseHelper.ExecuteNonQuery(query);
                MessageBox.Show("Booking confirmed!");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Booking failed: {ex.Message}");
            }
        }
    }
}