﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmAddEditTrip : Form
    {
        private readonly string _operatorId;
        private readonly string _tripId;

        public frmAddEditTrip(string operatorId, string tripId = null)
        {
            _operatorId = operatorId;
            _tripId = tripId;
            InitializeComponent();
            SetupForm();

            if (_tripId != null) LoadExistingTrip();
        }

        private void SetupForm()
        {
            this.Text = _tripId == null ? "Add New Trip" : $"Edit Trip {_tripId}";
            this.Size = new Size(400, 200);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Form Controls
            var lblTitle = new Label { Text = "Trip Title:", Top = 30, Left = 20, Width = 80 };
            var txtTitle = new TextBox { Top = 30, Left = 110, Width = 250 };

            var btnSave = new Button { Text = "Save", Top = 100, Left = 150, Width = 100 };
            btnSave.Click += (s, e) => SaveTrip(txtTitle.Text);

            this.Controls.AddRange(new Control[] { lblTitle, txtTitle, btnSave });
        }

        private void LoadExistingTrip()
        {
            try
            {
                var trip = DatabaseHelper.ExecuteQuery(
                    $"SELECT * FROM Trip WHERE TripID = '{_tripId}'").Rows[0];
                ((TextBox)this.Controls[1]).Text = trip["Title"].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading trip: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveTrip(string title)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(title))
                {
                    MessageBox.Show("Title cannot be empty", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string query = _tripId == null
                    ? @"INSERT INTO Trip (TripID, Title, OperatorID, CreatedAt) 
                       VALUES (@TripID, @Title, @OperatorID, GETDATE())"
                    : @"UPDATE Trip SET Title = @Title 
                       WHERE TripID = @TripID";

                var parameters = new System.Collections.Generic.Dictionary<string, object>
                {
                    { "@Title", title },
                    { "@OperatorID", _operatorId }
                };

                if (_tripId == null)
                {
                    parameters.Add("@TripID", "TP" + Guid.NewGuid().ToString("N").Substring(0, 8));
                }
                else
                {
                    parameters.Add("@TripID", _tripId);
                }

                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("Trip saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving trip: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmAddEditTrip_Load(object sender, EventArgs e)
        {

        }
    }
}