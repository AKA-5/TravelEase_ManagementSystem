﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Travel_Ease_App.Data;
using Travel_Ease_App.Forms; // Ensure you have this using directive for the Forms namespace

namespace Travel_Ease_App.Forms
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
            SetupLoginForm();
        }

        private void SetupLoginForm()
        {
            this.Text = "TravelEase Login";
            this.Size = new Size(300, 200);

            var txtEmail = new TextBox { Text = "Email", Top = 20, Width = 200 };
            var txtPassword = new TextBox { Text = "Password", Top = 50, Width = 200, UseSystemPasswordChar = true };
            var btnLogin = new Button { Text = "Login", Top = 80, Width = 200 };

            btnLogin.Click += (s, e) => Authenticate(txtEmail.Text, txtPassword.Text);

            this.Controls.AddRange(new Control[] { txtEmail, txtPassword, btnLogin });
        }

        private void Authenticate(string email, string password)
        {
            try
            {
                var query = @"SELECT TOP 1 TravelerID, 'Traveler' as Role FROM Traveler WHERE Email = @Email AND TPassword = @Password
                      UNION ALL
                      SELECT OperatorID, 'Operator' FROM TourOperator WHERE Email = @Email AND TOPassword = @Password
                      UNION ALL
                      SELECT AdminID, 'Admin' FROM Admin WHERE Email = @Email AND APassword = @Password
                      UNION ALL
                      SELECT ProviderID, 'Provider' FROM ServiceProvider WHERE Email = @Email AND SPPassword = @Password";

                var parameters = new System.Collections.Generic.Dictionary<string, object>
                {
                    { "@Email", email },
                    { "@Password", password }
                };

                var result = DatabaseHelper.ExecuteQuery(query, parameters);

                if (result.Rows.Count > 0)
                {
                    var userId = result.Rows[0][0].ToString();
                    var role = result.Rows[0][1].ToString();

                    this.Hide();
                    new frmMain(userId, role).Show();
                }
                else
                {
                    MessageBox.Show("Invalid credentials", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Login error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmLogin_Load(object sender, EventArgs e)
        {

        }
    }
}
