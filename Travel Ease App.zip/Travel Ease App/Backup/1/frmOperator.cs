﻿using System;
using System.Data;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmOperator : Form
    {
        private readonly string _operatorId;
        private DataGridView _dgvTrips;

        public frmOperator(string operatorId)
        {
            _operatorId = operatorId;
            InitializeComponent();
            SetupOperatorForm();
        }

        private void SetupOperatorForm()
        {
            this.Text = $"Operator Portal - ID: {_operatorId}";
            this.WindowState = FormWindowState.Maximized;

            // Trip Grid
            _dgvTrips = new DataGridView { Dock = DockStyle.Fill };
            LoadTrips();

            // Control Panel
            var panel = new Panel { Dock = DockStyle.Right, Width = 200 };
            var btnAdd = new Button { Text = "Add Trip", Width = 180, Top = 20 };
            var btnRefresh = new Button { Text = "Refresh", Width = 180, Top = 60 };

            btnAdd.Click += (s, e) => new frmAddEditTrip(_operatorId).ShowDialog();
            btnRefresh.Click += (s, e) => LoadTrips();

            AddContextMenu();
            panel.Controls.AddRange(new Control[] { btnAdd, btnRefresh });
            this.Controls.AddRange(new Control[] { _dgvTrips, panel });
        }

        private void LoadTrips()
        {
            _dgvTrips.DataSource = DatabaseHelper.ExecuteQuery(
                $"SELECT * FROM Trip WHERE OperatorID = '{_operatorId}'");
        }

        private void AddContextMenu()
        {
            var menu = new ContextMenuStrip();
            menu.Items.Add("Edit Trip").Click += (s, e) => EditSelectedTrip();
            menu.Items.Add("Assign Services").Click += (s, e) => AssignServices();
            _dgvTrips.ContextMenuStrip = menu;
        }

        private void EditSelectedTrip()
        {
            if (_dgvTrips.SelectedRows.Count == 0) return;
            string tripId = _dgvTrips.SelectedRows[0].Cells["TripID"].Value.ToString();
            new frmAddEditTrip(_operatorId, tripId).ShowDialog();
        }

        private void AssignServices()
        {
            if (_dgvTrips.SelectedRows.Count == 0) return;
            string tripId = _dgvTrips.SelectedRows[0].Cells["TripID"].Value.ToString();
            new frmAssignServices(tripId).ShowDialog();
        }
    }
}