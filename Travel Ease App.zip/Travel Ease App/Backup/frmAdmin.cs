﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;
using System.Collections.Generic;
using OfficeOpenXml;

namespace Travel_Ease_App.Forms
{
    public partial class frmAdmin : Form
    {
        private DataGridView _dgvBookings;
        private DataGridView _dgvStats;
        private TabControl _tabControl;

        public frmAdmin()
        {
            InitializeComponent();
            SetupAdminDashboard();
        }

        private void SetupAdminDashboard()
        {
            this.Text = "Admin Dashboard - TravelEase";
            this.WindowState = FormWindowState.Maximized;

            // Create tab control
            _tabControl = new TabControl { Dock = DockStyle.Fill };

            // Tab 1: Dashboard
            var tabDashboard = new TabPage("Dashboard");
            SetupDashboardTab(tabDashboard);

            // Tab 2: User Management
            var tabUsers = new TabPage("User Management");
            SetupUserManagementTab(tabUsers);

            // Tab 3: Reports
            var tabReports = new TabPage("Reports");
            SetupReportsTab(tabReports);

            _tabControl.TabPages.AddRange(new TabPage[] { tabDashboard, tabUsers, tabReports });
            this.Controls.Add(_tabControl);

            RefreshDashboard();
        }

        private void SetupDashboardTab(TabPage tab)
        {
            // Stats Panel
            _dgvStats = new DataGridView { Dock = DockStyle.Top, Height = 150 };

            // Bookings Grid - Show ALL bookings, not just top 10
            _dgvBookings = new DataGridView { Dock = DockStyle.Fill };

            // Export Button
            var btnExport = new Button { Text = "Export to Excel", Dock = DockStyle.Bottom };
            btnExport.Click += (s, e) => ExportToExcel();

            tab.Controls.AddRange(new Control[] { _dgvStats, _dgvBookings, btnExport });
        }

        private void SetupUserManagementTab(TabPage tab)
        {
            var dgvUsers = new DataGridView { Dock = DockStyle.Fill };

            // User type filter
            var cmbUserType = new ComboBox
            {
                Dock = DockStyle.Top,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Items = { "All", "Travelers", "Operators", "Service Providers", "Admins" }
            };
            cmbUserType.SelectedIndexChanged += (s, e) => FilterUsers(dgvUsers, cmbUserType.Text);

            // Action buttons
            var panelButtons = new Panel { Dock = DockStyle.Bottom, Height = 40 };
            var btnApprove = new Button { Text = "Approve", Width = 100, Top = 5, Left = 5 };
            var btnReject = new Button { Text = "Reject", Width = 100, Top = 5, Left = 110 };

            btnApprove.Click += (s, e) => ProcessUserAction(dgvUsers, "Approve");
            btnReject.Click += (s, e) => ProcessUserAction(dgvUsers, "Reject");

            panelButtons.Controls.AddRange(new Control[] { btnApprove, btnReject });
            tab.Controls.AddRange(new Control[] { dgvUsers, cmbUserType, panelButtons });

            FilterUsers(dgvUsers, "All");
        }

        private void SetupReportsTab(TabPage tab)
        {
            var cmbReports = new ComboBox
            {
                Dock = DockStyle.Top,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Items = {
                    "Trip Booking and Revenue",
                    "Traveler Demographics",
                    "Operator Performance",
                    "Service Provider Efficiency",
                    "Destination Popularity",
                    "Abandoned Bookings",
                    "Platform Growth",
                    "Payment Transactions"
                }
            };

            var dgvReport = new DataGridView { Dock = DockStyle.Fill };
            var chartPanel = new Panel { Dock = DockStyle.Bottom, Height = 300 };

            cmbReports.SelectedIndexChanged += (s, e) =>
                LoadReport(dgvReport, chartPanel, cmbReports.SelectedItem.ToString());

            tab.Controls.AddRange(new Control[] { cmbReports, dgvReport, chartPanel });
            cmbReports.SelectedIndex = 0;
        }

        private void RefreshDashboard()
        {
            _dgvStats.DataSource = DatabaseHelper.ExecuteQuery(
                @"SELECT 'Total Travelers' as Category, COUNT(*) as Count FROM Traveler WHERE AccountStatus = 'Active'
                UNION ALL
                SELECT 'Total Operators', COUNT(*) FROM TourOperator WHERE AccountStatus = 'Active'
                UNION ALL
                SELECT 'Active Trips', COUNT(*) FROM Trip WHERE TStatus = 'Open'
                UNION ALL
                SELECT 'Pending Approvals', COUNT(*) FROM (
                    SELECT TravelerID FROM Traveler WHERE AccountStatus = 'Pending'
                    UNION ALL SELECT OperatorID FROM TourOperator WHERE AccountStatus = 'Pending'
                    UNION ALL SELECT ProviderID FROM ServiceProvider WHERE AccountStatus = 'Pending'
                ) as PendingUsers");

            // Show ALL bookings, not just top 10
            _dgvBookings.DataSource = DatabaseHelper.ExecuteQuery(
                "SELECT * FROM Booking ORDER BY BookingDate DESC");
        }

        private void FilterUsers(DataGridView dgv, string userType)
        {
            string query;

            if (userType == "Travelers")
            {
                query = "SELECT TravelerID as UserID, Email, 'Traveler' as Role, AccountStatus FROM Traveler";
            }
            else if (userType == "Operators")
            {
                query = "SELECT OperatorID as UserID, Email, 'Operator' as Role, AccountStatus FROM TourOperator";
            }
            else if (userType == "Service Providers")
            {
                query = "SELECT ProviderID as UserID, Email, 'Service Provider' as Role, AccountStatus FROM ServiceProvider";
            }
            else if (userType == "Admins")
            {
                query = "SELECT AdminID as UserID, Email, 'Admin' as Role, AccountStatus FROM Admin";
            }
            else
            {
                query = @"SELECT TravelerID as UserID, Email, 'Traveler' as Role, AccountStatus FROM Traveler
                UNION ALL SELECT OperatorID, Email, 'Operator', AccountStatus FROM TourOperator
                UNION ALL SELECT ProviderID, Email, 'Service Provider', AccountStatus FROM ServiceProvider
                UNION ALL SELECT AdminID, Email, 'Admin', AccountStatus FROM Admin";
            }

            dgv.DataSource = DatabaseHelper.ExecuteQuery(query);
        }

        private void ProcessUserAction(DataGridView dgv, string action)
        {
            if (dgv.SelectedRows.Count == 0) return;

            var userId = dgv.SelectedRows[0].Cells["UserID"].Value.ToString();
            var role = dgv.SelectedRows[0].Cells["Role"].Value.ToString();

            string statusValue = action == "Approve" ? "Active" : "Inactive";
            string query;

            if (role == "Traveler")
            {
                query = $"UPDATE Traveler SET AccountStatus = '{statusValue}' WHERE TravelerID = '{userId}'";
            }
            else if (role == "Operator")
            {
                query = $"UPDATE TourOperator SET AccountStatus = '{statusValue}' WHERE OperatorID = '{userId}'";
            }
            else if (role == "Service Provider")
            {
                query = $"UPDATE ServiceProvider SET AccountStatus = '{statusValue}' WHERE ProviderID = '{userId}'";
            }
            else // Admin
            {
                query = $"UPDATE Admin SET AccountStatus = '{statusValue}' WHERE AdminID = '{userId}'";
            }

            DatabaseHelper.ExecuteNonQuery(query);
            MessageBox.Show($"User {userId} has been set to {statusValue.ToLower()}");
            FilterUsers(dgv, "All");
        }

        private void LoadReport(DataGridView dgv, Panel chartPanel, string reportType)
        {
            string query;

            if (reportType == "Trip Booking and Revenue")
            {
                query = @"SELECT t.Title, t.TripType, 
                COUNT(CONCAT(b.TravelerID, b.TripID)) as Bookings, 
                SUM(t.PricePerPersonInDollars) as Revenue, 
                SUM(CASE WHEN b.BStatus = 'Cancelled' THEN 1 ELSE 0 END) as Cancellations
                FROM Trip t 
                LEFT JOIN Booking b ON t.TripID = b.TripID
                GROUP BY t.Title, t.TripType";
            }
            else if (reportType == "Traveler Demographics")
            {
                query = @"SELECT Nationality, Age, COUNT(*) as Count, 
                FROM Traveler GROUP BY Nationality, Age";
            }
            else if (reportType == "Operator Performance")
            {
                query = @"SELECT o.CompanyName, AVG(r.Rating) as AvgRating, 
                COUNT(DISTINCT CONCAT(b.TravelerID, b.TripID)) as Bookings, 
                SUM(t.PricePerPersonInDollars) as Revenue
                FROM TourOperator o
                LEFT JOIN Trip t ON o.OperatorID = t.OperatorID
                LEFT JOIN Booking b ON t.TripID = b.TripID
                LEFT JOIN Review r ON t.TripID = r.TripID
                GROUP BY o.CompanyName";
            }
            else if (reportType == "Service Provider Efficiency")
            {
                query = @"SELECT p.SPName, p.ServiceType, AVG(r.Rating) as AvgRating, 
                COUNT(a.AssignmentID) as Assignments
                FROM ServiceProvider p
                LEFT JOIN ServiceAssignment a ON p.ProviderID = a.ProviderID
                LEFT JOIN Review r ON a.AssignmentID = r.AssignmentID
                GROUP BY p.SPName, p.ServiceType";
            }
            else if (reportType == "Destination Popularity")
            {
                query = @"SELECT d.City, d.Country, 
                COUNT(DISTINCT CONCAT(b.TravelerID, b.TripID)) as Bookings, 
                AVG(r.Rating) as AvgRating
                FROM Destination d
                JOIN Trip t ON d.TripID = t.TripID
                LEFT JOIN Booking b ON t.TripID = b.TripID
                LEFT JOIN Review r ON t.TripID = r.TripID
                GROUP BY d.City, d.Country";
            }
            else if (reportType == "Abandoned Bookings")
            {
                query = @"SELECT t.Title, COUNT(*) as AbandonedCount
                FROM Trip t
                JOIN Booking b ON t.TripID = b.TripID
                WHERE b.BStatus = 'Abandoned'
                GROUP BY t.Title";
            }
            else if (reportType == "Platform Growth")
            {
                query = @"SELECT 
                COUNT(CASE WHEN Role = 'Traveler' THEN 1 END) as NewTravelers,
                COUNT(CASE WHEN Role = 'Operator' THEN 1 END) as NewOperators,
                MONTH(RegistrationDate) as Month,
                YEAR(RegistrationDate) as Year
                FROM (
                    SELECT TravelerID as ID, 'Traveler' as Role, RegistrationDate FROM Traveler
                    UNION ALL
                    SELECT OperatorID, 'Operator', RegistrationDate FROM TourOperator
                ) as Users
                GROUP BY YEAR(RegistrationDate), MONTH(RegistrationDate)
                ORDER BY Year, Month";
            }
            else if (reportType == "Payment Transactions")
            {
                query = @"SELECT 
                COUNT(*) as TotalTransactions,
                SUM(CASE WHEN Status = 'Success' THEN 1 ELSE 0 END) as SuccessCount,
                SUM(CASE WHEN Status = 'Failed' THEN 1 ELSE 0 END) as FailedCount,
                PaymentMethod
                FROM Payments
                GROUP BY PaymentMethod";
            }
            else
            {
                query = @"SELECT 
                b.TravelerID, b.TripID, t.Title, 
                b.BookingDate, b.BStatus as Status
                FROM Booking b
                JOIN Trip t ON b.TripID = t.TripID
                ORDER BY b.BookingDate DESC";
            }

            dgv.DataSource = DatabaseHelper.ExecuteQuery(query);
            // TODO: Add chart visualization in chartPanel
        }

        private void ExportToExcel()
        {
            var saveFile = new SaveFileDialog { Filter = "Excel|*.xlsx" };
            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    ExcelPackage.LicenseContext = OfficeOpenXml.LicenseContext.NonCommercial;
                    ExcelExporter.Export((DataTable)_dgvBookings.DataSource, saveFile.FileName);
                    MessageBox.Show("Exported successfully!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Export failed: {ex.Message}");
                }
            }
        }
    }
}