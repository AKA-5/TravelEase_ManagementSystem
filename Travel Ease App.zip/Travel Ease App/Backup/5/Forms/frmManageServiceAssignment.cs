﻿using System;
using System.Data;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmManageServiceAssignment : Form
    {
        private readonly string _tripId;
        private readonly string _serviceId;

        public frmManageServiceAssignment(string tripId, string serviceId)
        {
            InitializeComponent();
            _tripId = tripId;
            _serviceId = serviceId;
        }

        private void frmManageServiceAssignment_Load(object sender, EventArgs e)
        {
            LoadServiceAssignmentData();
            LoadAvailableProviders();

            // Initialize status dropdown
            cboStatus.Items.AddRange(new object[] { "Pending", "Accepted", "Rejected" });
        }

        private void LoadServiceAssignmentData()
        {
            string query = $@"SELECT sa.*, s.SType, sp.SPName, sp.SPType, sp.ProviderID as CurrentProviderID
                           FROM ServiceAssignment sa
                           JOIN Service s ON sa.ServiceID = s.ServiceID AND sa.ProviderID = s.ProviderID
                           JOIN ServiceProvider sp ON sa.ProviderID = sp.ProviderID
                           WHERE sa.TripID = '{_tripId}' AND sa.ServiceID = '{_serviceId}'";

            DataTable dt = DatabaseHelper.ExecuteQuery(query);

            if (dt.Rows.Count == 1)
            {
                DataRow row = dt.Rows[0];
                lblServiceType.Text = row["SType"].ToString();
                lblCurrentProvider.Text = row["SPName"].ToString();
                cboStatus.SelectedItem = row["SAStatus"].ToString();
            }
        }

        private void LoadAvailableProviders()
        {
            // Get current provider ID
            string currentProviderId = "";
            string currentQuery = $@"SELECT ProviderID FROM ServiceAssignment 
                                   WHERE TripID = '{_tripId}' AND ServiceID = '{_serviceId}'";
            currentProviderId = DatabaseHelper.ExecuteScalar(currentQuery)?.ToString();

            // Get all available providers (including current one)
            string query = $@"SELECT sp.ProviderID, sp.SPName, sp.SPType, 
                            s.ServiceID, s.SType, s.AvailableCapacity
                            FROM Service s
                            JOIN ServiceProvider sp ON s.ProviderID = sp.ProviderID
                            WHERE s.SType = '{lblServiceType.Text}'
                            AND s.AvailableCapacity > 0
                            AND sp.AccountStatus = 'Active'
                            {(string.IsNullOrEmpty(currentProviderId) ? "" : $"AND (sp.ProviderID = '{currentProviderId}' OR sp.ProviderID <> '{currentProviderId}')")}";

            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            cboNewProvider.DataSource = dt;
            cboNewProvider.DisplayMember = "SPName";
            cboNewProvider.ValueMember = "ProviderID";

            // Select current provider if exists
            if (!string.IsNullOrEmpty(currentProviderId))
            {
                cboNewProvider.SelectedValue = currentProviderId;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (cboStatus.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a status.", "Validation Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboStatus.Focus();
                return;
            }

            try
            {
                string status = cboStatus.SelectedItem.ToString();
                string providerId = cboNewProvider.SelectedValue?.ToString();

                // Update the service assignment
                string query = $@"UPDATE ServiceAssignment 
                                SET SAStatus = '{status}' 
                                {((providerId != null) ? $", ProviderID = '{providerId}'" : "")}
                                WHERE TripID = '{_tripId}' AND ServiceID = '{_serviceId}'";

                int rowsAffected = DatabaseHelper.ExecuteNonQuery(query);

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Service assignment updated successfully!", "Success",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating service assignment: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}