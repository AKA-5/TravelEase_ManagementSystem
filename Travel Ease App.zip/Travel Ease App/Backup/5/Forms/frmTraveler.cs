﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text.RegularExpressions; // Added for regex validation
using System.Windows.Forms;
using System.Xml.Linq;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmTraveler : Form
    {
        private readonly string _travelerId;
        private Button _btnSaveProfile; // button for saving profile details

        public frmTraveler(string travelerId)
        {
            _travelerId = travelerId;
            InitializeComponent();
            this.Text = $"Traveler Portal - User: {_travelerId}";
            this.WindowState = FormWindowState.Maximized;
            this.Load += new EventHandler(frmTraveler_Load);
            SetupProfileTab();
        }

        private void SetupProfileTab()
        {
            // Ensuriong that the textboxes are editable
            txtFullName.ReadOnly = false;
            txtEmail.ReadOnly = false;
            txtPhone.ReadOnly = false;
            txtNationality.ReadOnly = false;
            txtAge.ReadOnly = false;

            _btnSaveProfile = new Button
            {
                Text = "Save Profile",
                Width = 120,
                Height = 30,
                Location = new Point(10, 300)
            };
            _btnSaveProfile.Click += (s, e) => SaveProfile();
            tabProfile.Controls.Add(_btnSaveProfile);
        }

        private void frmTraveler_Load(object sender, EventArgs e)
        {
            LoadTrips();
        }

        private void LoadTrips()
        {
            try
            {
                string query = @"SELECT t.TripID, t.Title, d.City, d.Country, t.StartDate, t.EndDate, 
                        t.PricePerPersonInDollars, t.TripType, t.Capacity, t.TStatus
                        FROM Trip t
                        JOIN Destination d ON t.TripID = d.TripID
                        LEFT JOIN Wishlist w ON t.TripID = w.TripID AND w.TravelerID = @TravelerID
                        WHERE t.TStatus = 'Open To Register'";

                // Apply filters
                var parameters = new Dictionary<string, object>();
                parameters.Add("@TravelerID", _travelerId);

                if (!string.IsNullOrWhiteSpace(txtSearch.Text))
                {
                    query += " AND (d.City LIKE @Search OR d.Country LIKE @Search OR t.Title LIKE @Search)";
                    parameters.Add("@Search", $"%{txtSearch.Text}%");
                }
                if (cboTripType.SelectedIndex > 0)
                {
                    query += " AND t.TripType = @TripType";
                    parameters.Add("@TripType", cboTripType.SelectedItem.ToString());
                }
                if (nudMaxPrice.Value > 0)
                {
                    query += " AND t.PricePerPersonInDollars <= @MaxPrice";
                    parameters.Add("@MaxPrice", nudMaxPrice.Value);
                }
                if (nudMinCapacity.Value > 0)
                {
                    query += " AND t.Capacity >= @MinCapacity";
                    parameters.Add("@MinCapacity", nudMinCapacity.Value);
                }
                if (chkDateFilter.Checked)
                {
                    query += " AND t.StartDate BETWEEN @StartDateFrom AND @StartDateTo";
                    parameters.Add("@StartDateFrom", dtpStartDateFrom.Value);
                    parameters.Add("@StartDateTo", dtpStartDateTo.Value);
                }
                if (chkMyWishlist.Checked)
                {
                    query += " AND w.TripID IS NOT NULL"; // Filter to show only wishlist trips
                }

                DataTable dt = parameters.Count > 0 ? DatabaseHelper.ExecuteQuery(query, parameters) : DatabaseHelper.ExecuteQuery(query);
                dgvTrips.DataSource = dt;

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("No trips found matching your criteria.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading trips: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadBookings()
        {
            try
            {
                string query = @"SELECT b.TravelerID, b.TripID, t.Title, d.City, d.Country, 
                                b.BookingDate, b.BStatus, t.PricePerPersonInDollars, t.TStatus
                                FROM Booking b
                                JOIN Trip t ON b.TripID = t.TripID
                                JOIN Destination d ON t.TripID = d.TripID
                                WHERE b.TravelerID = @TravelerID";
                var parameters = new Dictionary<string, object> { { "@TravelerID", _travelerId } };
                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                dgvBookings.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading bookings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadProfile()
        {
            try
            {
                string query = @"SELECT FullName, Email, PhoneNumber, Nationality, Age
                                FROM Traveler WHERE TravelerID = @TravelerID";
                var parameters = new Dictionary<string, object> { { "@TravelerID", _travelerId } };
                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                if (dt.Rows.Count > 0)
                {
                    txtFullName.Text = dt.Rows[0]["FullName"].ToString();
                    txtEmail.Text = dt.Rows[0]["Email"].ToString();
                    txtPhone.Text = dt.Rows[0]["PhoneNumber"].ToString();
                    txtNationality.Text = dt.Rows[0]["Nationality"].ToString();
                    txtAge.Text = dt.Rows[0]["Age"].ToString();
                }

                // Load preferences
                query = @"SELECT Preference FROM Preferences WHERE TravelerID = @TravelerID";
                dt = DatabaseHelper.ExecuteQuery(query, parameters);
                clbPreferences.Items.Clear();
                string[] allPreferences = { "Adventure", "Cultural", "Leisure", "Historical", "Luxury", "Solo", "Group" };
                foreach (string pref in allPreferences)
                {
                    bool isChecked = dt.AsEnumerable().Any(row => row["Preference"].ToString() == pref);
                    clbPreferences.Items.Add(pref, isChecked);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading profile: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SavePreferences()
        {
            try
            {
                // Delete existing preferences
                string query = "DELETE FROM Preferences WHERE TravelerID = @TravelerID";
                var parameters = new Dictionary<string, object> { { "@TravelerID", _travelerId } };
                DatabaseHelper.ExecuteNonQuery(query, parameters);

                // Insert selected preferences
                foreach (object item in clbPreferences.CheckedItems)
                {
                    query = "INSERT INTO Preferences (TravelerID, Preference) VALUES (@TravelerID, @Preference)";
                    parameters = new Dictionary<string, object>
                    {
                        { "@TravelerID", _travelerId },
                        { "@Preference", item.ToString() }
                    };
                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                }
                MessageBox.Show("Preferences updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving preferences: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveProfile()
        {
            try
            {
                // Validate inputs
                if (string.IsNullOrWhiteSpace(txtFullName.Text))
                {
                    MessageBox.Show("Full Name is required.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (string.IsNullOrWhiteSpace(txtEmail.Text))
                {
                    MessageBox.Show("Email is required.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Validate email format (basic check)
                if (!txtEmail.Text.Contains("@") || !txtEmail.Text.Contains("."))
                {
                    MessageBox.Show("Please enter a valid email address.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Validate Phone Number
                if (!string.IsNullOrWhiteSpace(txtPhone.Text))
                {
                    string phonePattern = @"^\+?[0-9\s]*$"; // Allows optional '+' at start, followed by digits and spaces
                    if (!Regex.IsMatch(txtPhone.Text, phonePattern) ||
                        Regex.Matches(txtPhone.Text, @"\+").Count > 1 ||
                        Regex.Matches(txtPhone.Text, @"\d").Count < 6)
                    {
                        MessageBox.Show("Phone number must contain exactly one '+' (optional at start) and at least 6 digits.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                // Validate Age
                if (!string.IsNullOrWhiteSpace(txtAge.Text))
                {
                    if (!int.TryParse(txtAge.Text, out int age) || age < 5 || age > 120)
                    {
                        MessageBox.Show("Age must be a number between 5 and 120.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                }

                // Check for email uniqueness (excluding the current traveler)
                string emailCheckQuery = "SELECT COUNT(*) FROM Traveler WHERE Email = @Email AND TravelerID != @TravelerID";
                var emailCheckParams = new Dictionary<string, object>
                {
                    { "@Email", txtEmail.Text },
                    { "@TravelerID", _travelerId }
                };
                int emailCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(emailCheckQuery, emailCheckParams));
                if (emailCount > 0)
                {
                    MessageBox.Show("This email is already in use by another traveler.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Update traveler details
                string updateQuery = @"
                    UPDATE Traveler 
                    SET FullName = @FullName, Email = @Email, PhoneNumber = @PhoneNumber, 
                        Nationality = @Nationality, Age = @Age 
                    WHERE TravelerID = @TravelerID";
                var parameters = new Dictionary<string, object>
                {
                    { "@TravelerID", _travelerId },
                    { "@FullName", txtFullName.Text },
                    { "@Email", txtEmail.Text },
                    { "@PhoneNumber", string.IsNullOrWhiteSpace(txtPhone.Text) ? (object)DBNull.Value : txtPhone.Text },
                    { "@Nationality", string.IsNullOrWhiteSpace(txtNationality.Text) ? (object)DBNull.Value : txtNationality.Text },
                    { "@Age", string.IsNullOrWhiteSpace(txtAge.Text) ? (object)DBNull.Value : int.Parse(txtAge.Text) }
                };

                int rowsAffected = DatabaseHelper.ExecuteNonQuery(updateQuery, parameters);
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Profile updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No changes were made to the profile.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving profile: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BookTrip()
        {
            if (dgvTrips.SelectedRows.Count > 0)
            {
                string tripId = dgvTrips.SelectedRows[0].Cells["TripID"].Value.ToString();
                frmBooking bookingForm = new frmBooking(tripId, _travelerId);
                if (bookingForm.ShowDialog() == DialogResult.OK)
                {
                    LoadBookings();
                }
            }
            else
            {
                MessageBox.Show("Please select a trip to book.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void CancelBooking()
        {
            if (dgvBookings.SelectedRows.Count > 0)
            {
                string tripId = dgvBookings.SelectedRows[0].Cells["TripID"].Value.ToString();
                string currentStatus = dgvBookings.SelectedRows[0].Cells["BStatus"].Value.ToString();

                if (currentStatus == "Cancelled")
                {
                    MessageBox.Show("Booking is already cancelled.", "Invalid Action", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    // Calculate the number of travelers with Confirmed or Recovered status for this TripID
                    string query = "SELECT COUNT(*) FROM Booking WHERE TripID = @TripID AND (BStatus = 'Confirmed' OR BStatus = 'Recovered')";
                    var parameters = new Dictionary<string, object>
                    {
                        { "@TripID", tripId }
                    };
                    int noOfTravelers = Convert.ToInt32(DatabaseHelper.ExecuteScalar(query, parameters));

                    // Update the booking status to Cancelled
                    query = "UPDATE Booking SET BStatus = 'Cancelled' WHERE TravelerID = @TravelerID AND TripID = @TripID";
                    parameters.Add("@TravelerID", _travelerId);
                    DatabaseHelper.ExecuteNonQuery(query, parameters);

                    // Increase the AvailableCapacity of all assigned services
                    query = @"
                        UPDATE [Service]
                        SET AvailableCapacity = AvailableCapacity + @NoOfTravelers
                        WHERE ServiceID IN (
                            SELECT ServiceID 
                            FROM ServiceAssignment 
                            WHERE TripID = @TripID AND (SAStatus IS NULL OR SAStatus != 'Rejected')
                        )";
                    parameters.Add("@NoOfTravelers", noOfTravelers);
                    DatabaseHelper.ExecuteNonQuery(query, parameters);

                    MessageBox.Show("Booking cancelled successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadBookings();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error cancelling booking: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a booking to cancel.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void RecoverBooking()
        {
            if (dgvBookings.SelectedRows.Count > 0)
            {
                string tripId = dgvBookings.SelectedRows[0].Cells["TripID"].Value.ToString();
                string currentStatus = dgvBookings.SelectedRows[0].Cells["BStatus"].Value.ToString();

                if (currentStatus == "Confirmed" || currentStatus == "Recovered")
                {
                    MessageBox.Show("Booking is already confirmed or recovered.", "Invalid Action", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (currentStatus != "Cancelled")
                {
                    MessageBox.Show("Only cancelled bookings can be recovered.", "Invalid Action", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                try
                {
                    // Calculate the number of travelers with Confirmed or Recovered status for this TripID
                    string query = "SELECT COUNT(*) FROM Booking WHERE TripID = @TripID AND (BStatus = 'Confirmed' OR BStatus = 'Recovered')";
                    var parameters = new Dictionary<string, object>
                    {
                        { "@TripID", tripId }
                    };
                    int noOfTravelers = Convert.ToInt32(DatabaseHelper.ExecuteScalar(query, parameters));
                    noOfTravelers++; // Include the current traveler

                    // Get the available capacity of all assigned services
                    query = @"
                        SELECT s.ServiceID, s.AvailableCapacity
                        FROM [Service] s
                        JOIN ServiceAssignment sa ON s.ServiceID = sa.ServiceID
                        WHERE sa.TripID = @TripID AND (sa.SAStatus IS NULL OR sa.SAStatus != 'Rejected')";
                    DataTable services = DatabaseHelper.ExecuteQuery(query, parameters);

                    bool canRecover = true;
                    foreach (DataRow service in services.Rows)
                    {
                        int availableCapacity = Convert.ToInt32(service["AvailableCapacity"]);
                        if (noOfTravelers > availableCapacity)
                        {
                            canRecover = false;
                            break;
                        }
                    }

                    // Update the booking status to Recovered
                    query = "UPDATE Booking SET BStatus = 'Recovered' WHERE TravelerID = @TravelerID AND TripID = @TripID";
                    parameters.Add("@TravelerID", _travelerId);
                    DatabaseHelper.ExecuteNonQuery(query, parameters);

                    if (canRecover)
                    {
                        // Decrease the AvailableCapacity of all assigned services
                        query = @"
                            UPDATE [Service]
                            SET AvailableCapacity = AvailableCapacity - noOfTravelers
                            WHERE ServiceID IN (
                                SELECT ServiceID 
                                FROM ServiceAssignment 
                                WHERE TripID = @TripID AND (SAStatus IS NULL OR SAStatus != 'Rejected')
                            )";
                        parameters.Remove("@NoOfTravelers"); // Remove previous parameter if exists
                        DatabaseHelper.ExecuteNonQuery(query, parameters);
                    }
                    else
                    {
                        // Reject the ServiceAssignment
                        query = @"
                            UPDATE ServiceAssignment
                            SET SAStatus = 'Rejected'
                            WHERE TripID = @TripID AND (SAStatus IS NULL OR SAStatus != 'Rejected')";
                        DatabaseHelper.ExecuteNonQuery(query, new Dictionary<string, object> { { "@TripID", tripId } });
                    }

                    MessageBox.Show("Booking recovered successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadBookings();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error recovering booking: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a booking to recover.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void AddToWishlist()
        {
            if (dgvTrips.SelectedRows.Count > 0)
            {
                string tripId = dgvTrips.SelectedRows[0].Cells["TripID"].Value.ToString();
                try
                {
                    string query = "INSERT INTO Wishlist (TravelerID, TripID, AddedDate) VALUES (@TravelerID, @TripID, GETDATE())";
                    var parameters = new Dictionary<string, object>
                    {
                        { "@TravelerID", _travelerId },
                        { "@TripID", tripId }
                    };
                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    MessageBox.Show("Trip added to wishlist!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("duplicate key"))
                        MessageBox.Show("This trip is already in your wishlist.", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    else
                        MessageBox.Show($"Error adding to wishlist: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a trip to add to wishlist.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void SubmitReview()
        {
            if (cboReviewTarget.SelectedIndex == -1 || nudRating.Value < 1)
            {
                MessageBox.Show("Please select a review target and rating.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check for existing review
            string checkQuery = cboReviewTarget.SelectedIndex == 0
                ? "SELECT COUNT(*) FROM Review WHERE TravelerID = @TravelerID AND TripID = @TripID"
                : "SELECT COUNT(*) FROM Review WHERE TravelerID = @TravelerID AND ProviderID = @ProviderID";
            var checkParams = new Dictionary<string, object>
            {
                { "@TravelerID", _travelerId },
                { cboReviewTarget.SelectedIndex == 0 ? "@TripID" : "@ProviderID", cboReviewItem.SelectedValue }
            };
            int existingReviewCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(checkQuery, checkParams));
            if (existingReviewCount > 0)
            {
                MessageBox.Show("You have already submitted a review for this " + (cboReviewTarget.SelectedIndex == 0 ? "trip" : "service provider") + ".", "Duplicate Review", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Generate review ID based on row count
                string countQuery = "SELECT COUNT(*) FROM Review";
                int reviewCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(countQuery));
                string reviewId = $"RV{(reviewCount + 1):D3}";

                string query = @"INSERT INTO Review (ReviewID, TravelerID, TripID, ProviderID, Rating, Comment, ReviewDate)
                                VALUES (@ReviewID, @TravelerID, @TripID, @ProviderID, @Rating, @Comment, GETDATE())";
                var parameters = new Dictionary<string, object>
                {
                    { "@ReviewID", reviewId },
                    { "@TravelerID", _travelerId },
                    { "@TripID", cboReviewTarget.SelectedIndex == 0 ? cboReviewItem.SelectedValue : null },
                    { "@ProviderID", cboReviewTarget.SelectedIndex == 1 ? cboReviewItem.SelectedValue : null },
                    { "@Rating", (int)nudRating.Value },
                    { "@Comment", txtComment.Text }
                };
                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("Review submitted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtComment.Clear();
                nudRating.Value = 1;
                cboReviewTarget.SelectedIndex = -1;
                cboReviewItem.DataSource = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error submitting review: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadReviewItems()
        {
            try
            {
                if (cboReviewTarget.SelectedIndex == 0) // Trip
                {
                    string query = @"SELECT t.TripID, t.Title FROM Trip t
                                    JOIN Booking b ON t.TripID = b.TripID
                                    WHERE b.TravelerID = @TravelerID AND (b.BStatus = 'Confirmed' OR b.BStatus = 'Recovered') AND t.TStatus = 'Ended'";
                    var parameters = new Dictionary<string, object> { { "@TravelerID", _travelerId } };
                    DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                    cboReviewItem.DataSource = dt;
                    cboReviewItem.DisplayMember = "Title";
                    cboReviewItem.ValueMember = "TripID";
                }
                else if (cboReviewTarget.SelectedIndex == 1) // Service Provider
                {
                    string query = @"
                        SELECT DISTINCT sp.ProviderID, sp.SPName 
                        FROM ServiceProvider sp
                        JOIN ServiceAssignment sa ON sp.ProviderID = sa.ProviderID
                        JOIN Trip t ON sa.TripID = t.TripID
                        JOIN Booking b ON t.TripID = b.TripID
                        WHERE b.TravelerID = @TravelerID AND (b.BStatus = 'Confirmed' OR b.BStatus = 'Recovered') AND t.TStatus = 'Ended'";
                    var parameters = new Dictionary<string, object> { { "@TravelerID", _travelerId } };
                    DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                    cboReviewItem.DataSource = dt;
                    cboReviewItem.DisplayMember = "SPName";
                    cboReviewItem.ValueMember = "ProviderID";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading review items: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadMyReviews()
        {
            try
            {
                string query = @"
                    SELECT ReviewID, TripID, ProviderID, Rating, Comment, ReviewDate 
                    FROM Review 
                    WHERE TravelerID = @TravelerID";
                var parameters = new Dictionary<string, object> { { "@TravelerID", _travelerId } };
                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                dgvMyReviews.DataSource = dt;

                // Configure columns for better display
                if (dgvMyReviews.Columns.Count > 0)
                {
                    dgvMyReviews.Columns["ReviewID"].HeaderText = "Review ID";
                    dgvMyReviews.Columns["TravelerID"].HeaderText = "Traveler ID";
                    dgvMyReviews.Columns["TripID"].HeaderText = "Trip ID";
                    dgvMyReviews.Columns["ProviderID"].HeaderText = "Provider ID";
                    dgvMyReviews.Columns["Rating"].HeaderText = "Rating";
                    dgvMyReviews.Columns["Comment"].HeaderText = "Comment";
                    dgvMyReviews.Columns["ReviewDate"].HeaderText = "Review Date";

                    // Optional: Adjust column widths
                    dgvMyReviews.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
                }

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("No reviews found.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading reviews: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadTrips();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            BookTrip();
        }

        private void btnWishlist_Click(object sender, EventArgs e)
        {
            AddToWishlist();
        }

        private void btnCancelBooking_Click(object sender, EventArgs e)
        {
            CancelBooking();
        }

        private void btnRecoverBooking_Click(object sender, EventArgs e)
        {
            RecoverBooking();
        }

        private void btnSavePreferences_Click(object sender, EventArgs e)
        {
            SavePreferences();
        }

        private void btnSubmitReview_Click(object sender, EventArgs e)
        {
            SubmitReview();
        }

        private void cboReviewTarget_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboReviewItem.DataSource = null;
            if (cboReviewTarget.SelectedIndex >= 0)
            {
                LoadReviewItems();
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl.SelectedTab == tabBookings)
            {
                LoadBookings();
            }
            else if (tabControl.SelectedTab == tabProfile)
            {
                LoadProfile();
            }
            else if (tabControl.SelectedTab == tabMyReviews)
            {
                LoadMyReviews();
            }
        }

        private void frmTraveler_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Ensuring a smooth operator experience :)
            Application.Exit();
        }

        private void chkMyWishlist_CheckedChanged(object sender, EventArgs e)
        {
            LoadTrips();
        }
    }
}