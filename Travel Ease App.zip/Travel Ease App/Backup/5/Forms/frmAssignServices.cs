﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmAssignServices : Form
    {
        private readonly string _operatorId;
        private ComboBox cboTrip;
        private CheckedListBox clbServices;
        private Button btnSave;
        private Button btnCancel;

        public frmAssignServices(string operatorId)
        {
            _operatorId = operatorId;
            InitializeComponent();
            SetupForm();
        }

        private void SetupForm()
        {
            this.Text = "Assign Services to Trip";
            this.Size = new Size(600, 500); // Increased form size
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = FormStartPosition.CenterParent;

            // Trip selection
            var lblTrip = new Label { Text = "Trip:", Location = new Point(20, 20), AutoSize = true };
            cboTrip = new ComboBox
            {
                Location = new Point(120, 17),
                Size = new Size(400, 23), // Increased width
                DropDownStyle = ComboBoxStyle.DropDownList
            };

            // Services checklist
            var lblServices = new Label { Text = "Services:", Location = new Point(20, 60), AutoSize = true };
            clbServices = new CheckedListBox
            {
                Location = new Point(120, 57),
                Size = new Size(400, 300), // Increased size for better visibility
                CheckOnClick = true
            };

            // Buttons
            btnSave = new Button
            {
                Text = "Save Assignments",
                Location = new Point(120, 370), // Adjusted position
                Size = new Size(120, 40) // Increased button size
            };
            btnSave.Click += BtnSave_Click;

            btnCancel = new Button
            {
                Text = "Cancel",
                Location = new Point(260, 370), // Adjusted position
                Size = new Size(120, 40) // Increased button size
            };
            btnCancel.Click += BtnCancel_Click;

            this.Controls.AddRange(new Control[] { lblTrip, cboTrip, lblServices, clbServices, btnSave, btnCancel });

            // Load data
            LoadTrips();
            cboTrip.SelectedIndexChanged += (s, e) => LoadServices();
        }

        private void LoadTrips()
        {
            string query = $@"SELECT TripID, Title 
                            FROM Trip 
                            WHERE OperatorID = '{_operatorId}' 
                            AND TStatus IN ('Ongoing', 'Open To Register')";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);

            cboTrip.DataSource = dt;
            cboTrip.DisplayMember = "Title";
            cboTrip.ValueMember = "TripID";
            cboTrip.SelectedIndex = -1;
        }

        private void LoadServices()
        {
            clbServices.Items.Clear();
            if (cboTrip.SelectedIndex == -1)
                return;

            string tripId = cboTrip.SelectedValue.ToString();
            string query = $@"SELECT s.ServiceID, s.ProviderID, 
                            sp.SPName + ' - ' + s.SType + ' (Capacity: ' + CAST(s.AvailableCapacity AS VARCHAR) + ')' AS ServiceDescription
                            FROM Service s
                            JOIN ServiceProvider sp ON s.ProviderID = sp.ProviderID
                            WHERE s.AvailableCapacity > 0";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);

            foreach (DataRow row in dt.Rows)
            {
                string serviceId = row["ServiceID"].ToString();
                bool isAssigned = IsAssigned(tripId, serviceId);
                clbServices.Items.Add(new ServiceItem
                {
                    ServiceID = serviceId,
                    ProviderID = row["ProviderID"].ToString(),
                    DisplayText = row["ServiceDescription"].ToString()
                }, isAssigned);
            }
        }

        private bool IsAssigned(string tripId, string serviceId)
        {
            string query = $@"SELECT COUNT(*) 
                            FROM ServiceAssignment 
                            WHERE TripID = '{tripId}' AND ServiceID = '{serviceId}'";
            return Convert.ToInt32(DatabaseHelper.ExecuteScalar(query)) > 0;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            if (!ValidateForm())
                return;

            try
            {
                string tripId = cboTrip.SelectedValue.ToString();

                // Clear existing assignments for the trip
                DatabaseHelper.ExecuteNonQuery(
                    $"DELETE FROM ServiceAssignment WHERE TripID = '{tripId}'");

                // Add new assignments
                foreach (ServiceItem item in clbServices.CheckedItems)
                {
                    DatabaseHelper.ExecuteNonQuery(
                        $@"INSERT INTO ServiceAssignment (TripID, ServiceID, OperatorID, ProviderID, SAStatus)
                        VALUES ('{tripId}', '{item.ServiceID}', '{_operatorId}', '{item.ProviderID}', 'Pending')");
                }

                MessageBox.Show("Services assigned successfully!", "Success",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error assigning services: {ex.Message}", "Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private bool ValidateForm()
        {
            if (cboTrip.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a trip.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboTrip.Focus();
                return false;
            }

            if (clbServices.CheckedItems.Count == 0)
            {
                MessageBox.Show("Please select at least one service.", "Validation Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                clbServices.Focus();
                return false;
            }

            return true;
        }

        private void BtnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        // Helper class for CheckedListBox items
        private class ServiceItem
        {
            public string ServiceID { get; set; }
            public string ProviderID { get; set; }
            public string DisplayText { get; set; }

            public override string ToString() => DisplayText;
        }
    }
}
