﻿using System;
using System.Data;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmOperator : Form
    {
        private readonly string _operatorId;

        public frmOperator(string operatorId)
        {
            _operatorId = operatorId;
            InitializeComponent();
        }

        private void frmOperator_Load(object sender, EventArgs e)
        {
            this.Text = $"Tour Operator Dashboard - ID: {_operatorId}";
            LoadTrips();
            LoadBookings();
            LoadServiceAssignments();
            LoadAnalytics();

            // Wire up event handlers
            btnAddTrip.Click += BtnAddTrip_Click;
            btnEditTrip.Click += BtnEditTrip_Click;
            btnDeleteTrip.Click += BtnDeleteTrip_Click;
        }

        private void LoadTrips()
        {
            string query = $"SELECT * FROM Trip WHERE OperatorID = '{_operatorId}'";
            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            dgvTrips.DataSource = dt;

            // Format columns if needed
            if (dgvTrips.Columns.Contains("PricePerPersonInDollars"))
            {
                dgvTrips.Columns["PricePerPersonInDollars"].DefaultCellStyle.Format = "C2";
            }
        }

        private void LoadBookings()
        {
            string query = $@"SELECT b.TripID, t.Title, b.TravelerID, tr.FullName, b.BookingDate, 
                            b.BStatus, p.AmountInDollars
                            FROM Booking b
                            JOIN Trip t ON b.TripID = t.TripID
                            JOIN Traveler tr ON b.TravelerID = tr.TravelerID
                            LEFT JOIN Payment p ON b.PaymentID = p.PaymentID
                            WHERE t.OperatorID = '{_operatorId}'";

            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            dgvBookings.DataSource = dt;

            // Format columns if needed
            if (dgvBookings.Columns.Contains("AmountInDollars"))
            {
                dgvBookings.Columns["AmountInDollars"].DefaultCellStyle.Format = "C2";
            }
        }

        private void LoadServiceAssignments()
        {
            string query = $@"SELECT sa.TripID, t.Title, sa.ServiceID, s.SType, 
                             sp.SPName as ProviderName, sa.SAStatus
                             FROM ServiceAssignment sa
                             JOIN Trip t ON sa.TripID = t.TripID
                             JOIN Service s ON sa.ServiceID = s.ServiceID AND sa.ProviderID = s.ProviderID
                             JOIN ServiceProvider sp ON sa.ProviderID = sp.ProviderID
                             WHERE t.OperatorID = '{_operatorId}'";

            DataTable dt = DatabaseHelper.ExecuteQuery(query);
            dgvServices.DataSource = dt;
        }

        private void LoadAnalytics()
        {
            // Total Bookings
            string bookingsQuery = $@"SELECT COUNT(*) FROM Booking b
                            JOIN Trip t ON b.TripID = t.TripID
                            WHERE t.OperatorID = '{_operatorId}'";
            int totalBookings = Convert.ToInt32(DatabaseHelper.ExecuteScalar(bookingsQuery));
            lblTotalBookings.Text = $"Total Bookings: {totalBookings}";

            // Total Revenue
            string revenueQuery = $@"SELECT ISNULL(SUM(p.AmountInDollars), 0) 
                           FROM Booking b
                           JOIN Trip t ON b.TripID = t.TripID
                           JOIN Payment p ON b.PaymentID = p.PaymentID
                           WHERE t.OperatorID = '{_operatorId}' 
                           AND p.PStatus = 'Success'";
            decimal totalRevenue = Convert.ToDecimal(DatabaseHelper.ExecuteScalar(revenueQuery));
            lblTotalRevenue.Text = $"Total Revenue: {totalRevenue:C2}";

            // Average Rating - Fixed version
            string ratingQuery = $@"SELECT ISNULL(AVG(CAST(r.Rating AS DECIMAL(3,1)), 0.0)
                          FROM Review r
                          JOIN Trip t ON r.TripID = t.TripID
                          WHERE t.OperatorID = '{_operatorId}'";

            try
            {
                object result = DatabaseHelper.ExecuteScalar(ratingQuery);
                decimal avgRating = Convert.ToDecimal(result);
                lblAvgRating.Text = $"Avg Rating: {avgRating:F1}";
            }
            catch (Exception ex)
            {
                lblAvgRating.Text = "Avg Rating: N/A";
                // Consider logging the error
                Console.WriteLine($"Error calculating average rating: {ex.Message}");
            }

            // Reviews
            string reviewsQuery = $@"SELECT r.TripID, t.Title, r.TravelerID, tr.FullName, 
                           r.Rating, r.Comment, r.ReviewDate
                           FROM Review r
                           JOIN Trip t ON r.TripID = t.TripID
                           JOIN Traveler tr ON r.TravelerID = tr.TravelerID
                           WHERE t.OperatorID = '{_operatorId}'";
            DataTable dt = DatabaseHelper.ExecuteQuery(reviewsQuery);
            dgvReviews.DataSource = dt;
        }

        private void BtnAddTrip_Click(object sender, EventArgs e)
        {
            frmAddEditTrip addForm = new frmAddEditTrip(_operatorId);
            addForm.ShowDialog();
            LoadTrips(); // Refresh the trips list
        }

        private void BtnEditTrip_Click(object sender, EventArgs e)
        {
            if (dgvTrips.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a trip to edit.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string tripId = dgvTrips.SelectedRows[0].Cells["TripID"].Value.ToString();
            frmAddEditTrip editForm = new frmAddEditTrip(_operatorId, tripId);
            editForm.ShowDialog();
            LoadTrips(); // Refresh the trips list
        }

        private void BtnDeleteTrip_Click(object sender, EventArgs e)
        {
            if (dgvTrips.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a trip to delete.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string tripId = dgvTrips.SelectedRows[0].Cells["TripID"].Value.ToString();
            string tripTitle = dgvTrips.SelectedRows[0].Cells["Title"].Value.ToString();

            DialogResult result = MessageBox.Show($"Are you sure you want to delete the trip '{tripTitle}'?",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    // First delete related records to maintain referential integrity
                    string deleteAssignments = $"DELETE FROM ServiceAssignment WHERE TripID = '{tripId}'";
                    DatabaseHelper.ExecuteNonQuery(deleteAssignments);

                    string deleteBookings = $"DELETE FROM Booking WHERE TripID = '{tripId}'";
                    DatabaseHelper.ExecuteNonQuery(deleteBookings);

                    string deleteReviews = $"DELETE FROM Review WHERE TripID = '{tripId}'";
                    DatabaseHelper.ExecuteNonQuery(deleteReviews);

                    // Now delete the trip
                    string deleteTrip = $"DELETE FROM Trip WHERE TripID = '{tripId}'";
                    int rowsAffected = DatabaseHelper.ExecuteNonQuery(deleteTrip);

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Trip deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadTrips(); // Refresh the trips list
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting trip: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dgvServices_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string tripId = dgvServices.Rows[e.RowIndex].Cells["TripID"].Value.ToString();
                string serviceId = dgvServices.Rows[e.RowIndex].Cells["ServiceID"].Value.ToString();

                // Open a form to manage this service assignment
                frmManageServiceAssignment manageForm = new frmManageServiceAssignment(tripId, serviceId);
                manageForm.ShowDialog();
                LoadServiceAssignments(); // Refresh the services list
            }
        }
    }
}