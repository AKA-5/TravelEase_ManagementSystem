﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmBooking : Form
    {
        private readonly string _tripId;
        private readonly string _travelerId;
        private Button _btnConfirm;

        public frmBooking(string tripId, string travelerId)
        {
            _tripId = tripId;
            _travelerId = travelerId;
            InitializeComponent();
            SetupBookingForm();
        }

        private void SetupBookingForm()
        {
            this.Text = $"Book Trip {_tripId}";
            this.Size = new Size(300, 200);

            // Get trip details
            var trip = DatabaseHelper.ExecuteQuery(
                $"SELECT t.Title, d.City, d.Country FROM Trip t " +
                $"JOIN Destination d ON t.TripID = d.TripID WHERE t.TripID = '{_tripId}'").Rows[0];

            // Display controls
            var lblInfo = new Label
            {
                Text = $"{trip["Title"]}\n{trip["City"]}, {trip["Country"]}",
                Dock = DockStyle.Top,
                TextAlign = System.Drawing.ContentAlignment.MiddleCenter
            };

            _btnConfirm = new Button { Text = "Confirm Booking", Dock = DockStyle.Bottom };
            _btnConfirm.Click += (s, e) => ConfirmBooking();

            this.Controls.AddRange(new Control[] { lblInfo, _btnConfirm });
        }

        private void ConfirmBooking()
        {
            try
            {
                // Step 1: Get the number of confirmed travelers (including this booking)
                string travelerCountQuery = @"
                    SELECT COUNT(*) 
                    FROM Booking 
                    WHERE TripID = @TripID AND BStatus = 'Confirmed'";
                var travelerCountParams = new Dictionary<string, object> { { "@TripID", _tripId } };
                int currentTravelerCount = Convert.ToInt32(DatabaseHelper.ExecuteScalar(travelerCountQuery, travelerCountParams));

                // Since this booking is about to be confirmed, increment the count
                int totalTravelerCount = currentTravelerCount + 1;

                // Step 2: Check services assigned to the trip
                string serviceQuery = @"
                    SELECT sa.ServiceID, sa.ProviderID, s.AvailableCapacity 
                    FROM ServiceAssignment sa
                    JOIN [Service] s ON sa.ServiceID = s.ServiceID AND sa.ProviderID = s.ProviderID
                    WHERE sa.TripID = @TripID AND sa.SAStatus = 'Accepted'";
                var serviceParams = new Dictionary<string, object> { { "@TripID", _tripId } };
                DataTable services = DatabaseHelper.ExecuteQuery(serviceQuery, serviceParams);

                foreach (DataRow service in services.Rows)
                {
                    string serviceId = service["ServiceID"].ToString();
                    string providerId = service["ProviderID"].ToString();
                    int availableCapacity = Convert.ToInt32(service["AvailableCapacity"]);

                    // Step 3: If available capacity is less than the total number of travelers, reject the service assignment
                    if (availableCapacity < totalTravelerCount)
                    {
                        string updateStatusQuery = @"
                            UPDATE ServiceAssignment 
                            SET SAStatus = 'Rejected' 
                            WHERE TripID = @TripID AND ServiceID = @ServiceID AND ProviderID = @ProviderID";
                        var updateParams = new Dictionary<string, object>
                        {
                            { "@TripID", _tripId },
                            { "@ServiceID", serviceId },
                            { "@ProviderID", providerId }
                        };
                        DatabaseHelper.ExecuteNonQuery(updateStatusQuery, updateParams);
                    }
                }

                // Step 4: Proceed with the booking regardless of service assignment status
                string bookingQuery = "INSERT INTO Booking (TravelerID, TripID, BStatus) VALUES (@TravelerID, @TripID, @BStatus)";
                var bookingParams = new Dictionary<string, object>
                {
                    { "@TravelerID", _travelerId },
                    { "@TripID", _tripId },
                    { "@BStatus", "Confirmed" }
                };
                DatabaseHelper.ExecuteNonQuery(bookingQuery, bookingParams);

                MessageBox.Show("Booking confirmed!");
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Booking failed: {ex.Message}");
            }
        }

        private void frmBooking_Load(object sender, EventArgs e)
        {

        }
    }
}