﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Xml.Linq;
using Travel_Ease_App.Data;

namespace Travel_Ease_App.Forms
{
    public partial class frmTraveler : Form
    {
        private readonly string _travelerId;

        public frmTraveler(string travelerId)
        {
            _travelerId = travelerId;
            InitializeComponent();
            this.Text = $"Traveler Portal - User: {_travelerId}";
            this.WindowState = FormWindowState.Maximized;
            this.Load += new EventHandler(frmTraveler_Load);
        }

        private void frmTraveler_Load(object sender, EventArgs e)
        {
            LoadTrips();
        }

        private void LoadTrips()
        {
            try
            {
                string query = @"SELECT t.TripID, t.Title, d.City, d.Country, t.StartDate, t.EndDate, 
                        t.PricePerPersonInDollars, t.TripType, t.Capacity, t.TStatus
                        FROM Trip t
                        JOIN Destination d ON t.TripID = d.TripID
                        LEFT JOIN Wishlist w ON t.TripID = w.TripID AND w.TravelerID = @TravelerID
                        WHERE t.TStatus = 'Open To Register'";

                // Apply filters
                var parameters = new Dictionary<string, object>();
                parameters.Add("@TravelerID", _travelerId);

                if (!string.IsNullOrWhiteSpace(txtSearch.Text))
                {
                    query += " AND (d.City LIKE @Search OR d.Country LIKE @Search OR t.Title LIKE @Search)";
                    parameters.Add("@Search", $"%{txtSearch.Text}%");
                }
                if (cboTripType.SelectedIndex > 0)
                {
                    query += " AND t.TripType = @TripType";
                    parameters.Add("@TripType", cboTripType.SelectedItem.ToString());
                }
                if (nudMaxPrice.Value > 0)
                {
                    query += " AND t.PricePerPersonInDollars <= @MaxPrice";
                    parameters.Add("@MaxPrice", nudMaxPrice.Value);
                }
                if (nudMinCapacity.Value > 0)
                {
                    query += " AND t.Capacity >= @MinCapacity";
                    parameters.Add("@MinCapacity", nudMinCapacity.Value);
                }
                if (chkDateFilter.Checked)
                {
                    query += " AND t.StartDate BETWEEN @StartDateFrom AND @StartDateTo";
                    parameters.Add("@StartDateFrom", dtpStartDateFrom.Value);
                    parameters.Add("@StartDateTo", dtpStartDateTo.Value);
                }
                if (chkMyWishlist.Checked)
                {
                    query += " AND w.TripID IS NOT NULL"; // Filter to show only wishlist trips
                }

                DataTable dt = parameters.Count > 0 ? DatabaseHelper.ExecuteQuery(query, parameters) : DatabaseHelper.ExecuteQuery(query);
                dgvTrips.DataSource = dt;

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("No trips found matching your criteria.", "No Results", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading trips: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadBookings()
        {
            try
            {
                string query = @"SELECT b.TravelerID, b.TripID, t.Title, d.City, d.Country, 
                                b.BookingDate, b.BStatus, t.PricePerPersonInDollars
                                FROM Booking b
                                JOIN Trip t ON b.TripID = t.TripID
                                JOIN Destination d ON t.TripID = d.TripID
                                WHERE b.TravelerID = @TravelerID";
                var parameters = new Dictionary<string, object> { { "@TravelerID", _travelerId } };
                dgvBookings.DataSource = DatabaseHelper.ExecuteQuery(query, parameters);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading bookings: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadProfile()
        {
            try
            {
                string query = @"SELECT FullName, Email, PhoneNumber, Nationality, Age
                                FROM Traveler WHERE TravelerID = @TravelerID";
                var parameters = new Dictionary<string, object> { { "@TravelerID", _travelerId } };
                DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                if (dt.Rows.Count > 0)
                {
                    txtFullName.Text = dt.Rows[0]["FullName"].ToString();
                    txtEmail.Text = dt.Rows[0]["Email"].ToString();
                    txtPhone.Text = dt.Rows[0]["PhoneNumber"].ToString();
                    txtNationality.Text = dt.Rows[0]["Nationality"].ToString();
                    txtAge.Text = dt.Rows[0]["Age"].ToString();
                }

                // Load preferences
                query = @"SELECT Preference FROM Preferences WHERE TravelerID = @TravelerID";
                dt = DatabaseHelper.ExecuteQuery(query, parameters);
                clbPreferences.Items.Clear();
                string[] allPreferences = { "Adventure", "Cultural", "Leisure", "Historical", "Luxury", "Solo", "Group" };
                foreach (string pref in allPreferences)
                {
                    bool isChecked = dt.AsEnumerable().Any(row => row["Preference"].ToString() == pref);
                    clbPreferences.Items.Add(pref, isChecked);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading profile: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SavePreferences()
        {
            try
            {
                // Delete existing preferences
                string query = "DELETE FROM Preferences WHERE TravelerID = @TravelerID";
                var parameters = new Dictionary<string, object> { { "@TravelerID", _travelerId } };
                DatabaseHelper.ExecuteNonQuery(query, parameters);

                // Insert selected preferences
                foreach (object item in clbPreferences.CheckedItems)
                {
                    query = "INSERT INTO Preferences (TravelerID, Preference) VALUES (@TravelerID, @Preference)";
                    parameters = new Dictionary<string, object>
                    {
                        { "@TravelerID", _travelerId },
                        { "@Preference", item.ToString() }
                    };
                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                }
                MessageBox.Show("Preferences updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving preferences: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BookTrip()
        {
            if (dgvTrips.SelectedRows.Count > 0)
            {
                string tripId = dgvTrips.SelectedRows[0].Cells["TripID"].Value.ToString();
                frmBooking bookingForm = new frmBooking(tripId, _travelerId);
                if (bookingForm.ShowDialog() == DialogResult.OK)
                {
                    LoadBookings();
                }
            }
            else
            {
                MessageBox.Show("Please select a trip to book.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void CancelBooking()
        {
            if (dgvBookings.SelectedRows.Count > 0)
            {
                string tripId = dgvBookings.SelectedRows[0].Cells["TripID"].Value.ToString();
                try
                {
                    string query = "UPDATE Booking SET BStatus = 'Cancelled' WHERE TravelerID = @TravelerID AND TripID = @TripID";
                    var parameters = new Dictionary<string, object>
                    {
                        { "@TravelerID", _travelerId },
                        { "@TripID", tripId }
                    };
                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    MessageBox.Show("Booking cancelled successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadBookings();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error cancelling booking: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a booking to cancel.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void AddToWishlist()
        {
            if (dgvTrips.SelectedRows.Count > 0)
            {
                string tripId = dgvTrips.SelectedRows[0].Cells["TripID"].Value.ToString();
                try
                {
                    string query = "INSERT INTO Wishlist (TravelerID, TripID, AddedDate) VALUES (@TravelerID, @TripID, GETDATE())";
                    var parameters = new Dictionary<string, object>
                    {
                        { "@TravelerID", _travelerId },
                        { "@TripID", tripId }
                    };
                    DatabaseHelper.ExecuteNonQuery(query, parameters);
                    MessageBox.Show("Trip added to wishlist!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    if (ex.Message.Contains("duplicate key"))
                        MessageBox.Show("This trip is already in your wishlist.", "Duplicate", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    else
                        MessageBox.Show($"Error adding to wishlist: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a trip to add to wishlist.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void SubmitReview()
        {
            if (cboReviewTarget.SelectedIndex == -1 || nudRating.Value < 1)
            {
                MessageBox.Show("Please select a review target and rating.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string reviewId = "RV" + Guid.NewGuid().ToString("N").Substring(0, 8);
                string query = @"INSERT INTO Review (ReviewID, TravelerID, TripID, ProviderID, Rating, Comment, ReviewDate)
                                VALUES (@ReviewID, @TravelerID, @TripID, @ProviderID, @Rating, @Comment, GETDATE())";
                var parameters = new Dictionary<string, object>
                {
                    { "@ReviewID", reviewId },
                    { "@TravelerID", _travelerId },
                    { "@TripID", cboReviewTarget.SelectedIndex == 0 ? cboReviewItem.SelectedValue : null },
                    { "@ProviderID", cboReviewTarget.SelectedIndex == 1 ? cboReviewItem.SelectedValue : null },
                    { "@Rating", (int)nudRating.Value },
                    { "@Comment", txtComment.Text }
                };
                DatabaseHelper.ExecuteNonQuery(query, parameters);
                MessageBox.Show("Review submitted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtComment.Clear();
                nudRating.Value = 1;
                cboReviewTarget.SelectedIndex = -1;
                cboReviewItem.DataSource = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error submitting review: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadReviewItems()
        {
            try
            {
                if (cboReviewTarget.SelectedIndex == 0) // Trip
                {
                    string query = @"SELECT t.TripID, t.Title FROM Trip t
                                    JOIN Booking b ON t.TripID = b.TripID
                                    WHERE b.TravelerID = @TravelerID AND b.BStatus = 'Confirmed'";
                    var parameters = new Dictionary<string, object> { { "@TravelerID", _travelerId } };
                    DataTable dt = DatabaseHelper.ExecuteQuery(query, parameters);
                    cboReviewItem.DataSource = dt;
                    cboReviewItem.DisplayMember = "Title";
                    cboReviewItem.ValueMember = "TripID";
                }
                else if (cboReviewTarget.SelectedIndex == 1) // Service Provider
                {
                    string query = "SELECT ProviderID, SPName FROM ServiceProvider WHERE AccountStatus = 'Active'";
                    DataTable dt = DatabaseHelper.ExecuteQuery(query);
                    cboReviewItem.DataSource = dt;
                    cboReviewItem.DisplayMember = "SPName";
                    cboReviewItem.ValueMember = "ProviderID";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading review items: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            LoadTrips();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            BookTrip();
        }

        private void btnWishlist_Click(object sender, EventArgs e)
        {
            AddToWishlist();
        }

        private void btnCancelBooking_Click(object sender, EventArgs e)
        {
            CancelBooking();
        }

        private void btnSavePreferences_Click(object sender, EventArgs e)
        {
            SavePreferences();
        }

        private void btnSubmitReview_Click(object sender, EventArgs e)
        {
            SubmitReview();
        }

        private void cboReviewTarget_SelectedIndexChanged(object sender, EventArgs e)
        {
            cboReviewItem.DataSource = null;
            if (cboReviewTarget.SelectedIndex >= 0)
            {
                LoadReviewItems();
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl.SelectedTab == tabBookings)
            {
                LoadBookings();
            }
            else if (tabControl.SelectedTab == tabProfile)
            {
                LoadProfile();
            }
        }

        private void frmTraveler_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Ensuring a smooth operator experience :)
            Application.Exit();
        }

        private void chkMyWishlist_CheckedChanged(object sender, EventArgs e)
        {
            LoadTrips();
        }
    }
}