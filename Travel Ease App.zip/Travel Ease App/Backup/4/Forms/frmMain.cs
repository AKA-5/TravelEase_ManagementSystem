﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Travel_Ease_App.Forms;

namespace Travel_Ease_App
{
    public partial class frmMain : Form
    {
        private readonly string _userId;
        private readonly string _role;

        public frmMain(string userId, string role)
        {
            _userId = userId;
            _role = role;
            InitializeComponent();
            this.FormClosing += frmMain_FormClosing; // Added this
            SetupRoleBasedUI();
        }

        private void SetupRoleBasedUI()
        {
            this.Text = $"TravelEase - {_role} Portal";

            var panel = new Panel { Dock = DockStyle.Left, Width = 200, BackColor = Color.LightGray };
            var lblWelcome = new Label { Text = $"Welcome {_userId}", Dock = DockStyle.Top };

            // Common controls
            var btnLogout = new Button { Text = "Logout", Dock = DockStyle.Bottom };
            btnLogout.Click += (s, e) => {
                this.FormClosing -= frmMain_FormClosing;
                this.Close();
                new frmLogin().Show();
            };

            // Role-specific controls
            if (_role == "Traveler")
            {
                var btnTrips = new Button { Text = "My Trips", Top = 50 };
                btnTrips.Click += (s, e) => new frmTraveler(_userId).Show();
                panel.Controls.Add(btnTrips);
            }
            else if (_role == "Operator")
            {
                var btnManage = new Button { Text = "Manage Trips", Top = 50 };
                btnManage.Click += (s, e) => new frmOperator(_userId).Show();
                panel.Controls.Add(btnManage);
            }
            else if (_role == "Admin")
            {
                var btnDashboard = new Button { Text = "Dashboard", Top = 50 };
                btnDashboard.Click += (s, e) => new frmAdmin().Show();
                panel.Controls.Add(btnDashboard);
            }

            else if (_role == "Provider") 
            {
                var btnServices = new Button { Text = "Manage Services", Top = 50 };
                btnServices.Click += (s, e) => new frmServiceProvider(_userId).Show();
                panel.Controls.Add(btnServices);
            }

            panel.Controls.AddRange(new Control[] { lblWelcome, btnLogout });
            this.Controls.Add(panel);
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Close all other forms first
            foreach (Form form in Application.OpenForms)
            {
                if (form != this)
                    form.Close();
            }

            // Full cleanup if this is the last form
            if (Application.OpenForms.Count <= 1)
            {
                Application.Exit();
                Environment.Exit(0);
            }
        }

        private void frmMain_Load(object sender, EventArgs e) { }
    }
}