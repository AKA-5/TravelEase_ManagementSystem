﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Travel_Ease_App.Data
{
    public static class DatabaseHelper
    {
        public static string GetConnectionString() => _connectionString;
        private static string _connectionString = "Data Source=Jazim\\SQLEXPRESS;Initial Catalog=TravelEase;Integrated Security=True;Encrypt=True;" + "TrustServerCertificate=True;";

        public static DataTable ExecuteQuery(string query)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var adapter = new SqlDataAdapter(query, connection);
                var table = new DataTable();
                adapter.Fill(table);
                return table;
            }
        }

        public static DataTable ExecuteQuery(string query, Dictionary<string, object> parameters = null)
        {
            using (var connection = new SqlConnection(_connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                foreach (var param in parameters ?? new Dictionary<string, object>())
                {
                    command.Parameters.AddWithValue(param.Key, param.Value ?? DBNull.Value);
                }

                connection.Open();
                var dataTable = new DataTable();
                dataTable.Load(command.ExecuteReader());
                return dataTable;
            }
        }

        public static int ExecuteNonQuery(string commandText)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(commandText, connection);
                return command.ExecuteNonQuery();
            }
        }

        public static int ExecuteNonQuery(string query, Dictionary<string, object> parameters = null)
        {
            using (var connection = new SqlConnection(_connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                foreach (var param in parameters ?? new Dictionary<string, object>())
                {
                    command.Parameters.AddWithValue(param.Key, param.Value ?? DBNull.Value);
                }

                connection.Open();
                return command.ExecuteNonQuery();
            }
        }

        public static string GetNextTravelerID()
        {
            string query = "SELECT MAX(CAST(SUBSTRING(TravelerID, 3, LEN(TravelerID)) AS INT)) FROM Traveler";
            object result = ExecuteScalar(query);
            int maxID = result != DBNull.Value ? Convert.ToInt32(result) : 0;
            return $"TR{(maxID + 1).ToString("D3")}";
        }

        public static string GetNextOperatorID()
        {
            string query = "SELECT MAX(CAST(SUBSTRING(OperatorID, 3, LEN(OperatorID)) AS INT)) FROM TourOperator";
            object result = ExecuteScalar(query);
            int maxID = result != DBNull.Value ? Convert.ToInt32(result) : 0;
            return $"TO{(maxID + 1).ToString("D3")}";
        }

        public static object ExecuteScalar(string query)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                return command.ExecuteScalar();
            }
        }

        public static object ExecuteScalar(string query, Dictionary<string, object> parameters = null)
        {
            using (SqlConnection connection = new SqlConnection(_connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                if (parameters != null)
                {
                    foreach (var param in parameters)
                    {
                        command.Parameters.AddWithValue(param.Key, param.Value ?? DBNull.Value);
                    }
                }
                connection.Open();
                return command.ExecuteScalar();
            }
        }

        public static bool UpdateLastLogin(string userId, string role)
        {
            try
            {
                string tableName;
                string idColumn;

                switch (role)
                {
                    case "Traveler":
                        tableName = "Traveler";
                        idColumn = "TravelerID";
                        break;
                    case "Operator":
                        tableName = "TourOperator";
                        idColumn = "OperatorID";
                        break;
                    case "Admin":
                        tableName = "Admin";
                        idColumn = "AdminID";
                        break;
                    case "Provider":
                        tableName = "ServiceProvider";
                        idColumn = "ProviderID";
                        break;
                    default:
                        throw new ArgumentException("Invalid role");
                }

                string query = string.Format(@"UPDATE {0} 
                                     SET LastLogin = GETDATE() 
                                     WHERE {1} = @UserId",
                                             tableName, idColumn);

                var parameters = new Dictionary<string, object>();
                parameters.Add("@UserId", userId);

                int rowsAffected = ExecuteNonQuery(query, parameters);
                return rowsAffected > 0;
            }
            catch (Exception ex)
            {
                // Log error if needed
                Console.WriteLine("Error updating last login: " + ex.Message);
                return false;
            }
        }

        // testConnection Method
        public static bool TestConnection()
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Connection error: " + ex.Message);
                return false;
            }
        }
    }
}