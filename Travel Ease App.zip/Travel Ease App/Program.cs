﻿using System;
using System.Windows.Forms;
using Travel_Ease_App.Forms;

namespace Travel_Ease_App
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmSplash()); // Start with splash screen
        }
    }
}