﻿using System;
using System.Threading;
using System.Windows.Forms;
using Travel_Ease_App.Forms;

namespace Travel_Ease_App
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // Ensure single instance and proper cleanup
            bool createdNew;
            var mutex = new Mutex(true, "TravelEaseAppMutex", out createdNew);

            if (!createdNew)
            {
                MessageBox.Show("Application is already running!");
                return;
            }

            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);

                // Create main form
                var mainForm = new frmSplash();

                // Handle termination properly
                Application.ApplicationExit += (sender, e) => {
                    mutex?.Close();
                    mutex?.Dispose();
                };

                Application.Run(mainForm);
            }
            finally
            {
                mutex?.Close();
                mutex?.Dispose();
                Application.Exit();
            }
        }
    }
}