﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Travel_Ease_App.Data
{
    public static class DatabaseHelper
    {
        private static string _connectionString = "Data Source=Jazim\\SQLEXPRESS;Initial Catalog=TravelEase;Integrated Security=True;Encrypt=True;" + "TrustServerCertificate=True;";

        public static DataTable ExecuteQuery(string query)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                var adapter = new SqlDataAdapter(query, connection);
                var table = new DataTable();
                adapter.Fill(table);
                return table;
            }
        }

        public static DataTable ExecuteQuery(string query, Dictionary<string, object> parameters)
        {
            using (var connection = new SqlConnection(_connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                foreach (var param in parameters)
                {
                    command.Parameters.AddWithValue(param.Key, param.Value ?? DBNull.Value);
                }

                connection.Open();
                var dataTable = new DataTable();
                dataTable.Load(command.ExecuteReader());
                return dataTable;
            }
        }
        public static int ExecuteNonQuery(string commandText)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand(commandText, connection);
                return command.ExecuteNonQuery();
            }
        }

        // New overload for parameterized non-query
        public static int ExecuteNonQuery(string query, Dictionary<string, object> parameters)
        {
            using (var connection = new SqlConnection(_connectionString))
            using (var command = new SqlCommand(query, connection))
            {
                foreach (var param in parameters)
                {
                    command.Parameters.AddWithValue(param.Key, param.Value ?? DBNull.Value);
                }

                connection.Open();
                return command.ExecuteNonQuery();
            }
        }
    }
}